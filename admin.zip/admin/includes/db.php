<?php
date_default_timezone_set('Asia/Kolkata');

$con = mysqli_connect("lab-pc","root","","centraldb");

if (mysqli_connect_errno()){
	
	echo "Failed to connect to mysql:" . mysqli_connect_error();
}
?>