<?php 
include 'session.php';

include 'includes/db.php';

	

?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
?>
	  
		    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				
	        	<p>
	        	
	        	<!-- 
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
				 -->
				 
				 
<link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel='stylesheet' type='text/css' />

<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>				 


  <script>
			$(document).ready(function() {
                $('#example').DataTable();
            } );

  </script>
 	 
						
   <h2>View All Website Details Here</h2>
   <div style="overflow-x:auto;">
  <table id="example" class="display" cellspacing="0" width="100%"> 
	
	<thead>
	  
	  <tr>
		<th>S.N</th>
		<th>Name</th>
		<th>Domain Name</th>
		<th>Status</th>
		<th>COD</th>
		<th>Online Payment</th>
		<th>Discount</th>
		<th>Shipping Charges</th>
		<th>Edit</th>
		<!--<th>Delete</th>-->
	</tr>
	
	</thead>
	
 <tbody>
	<?php 
	  include ("includes/db.php");
	  
	  $get_pro = "select * from websites";
	  
	  $run_pro = mysqli_query($con, $get_pro);
	  
	  $i=0;
	  
	  while ($row_pro=mysqli_fetch_array($run_pro))
	  {
	  	$web_id = $row_pro['web_id'];
	  	
	  	$web_name = $row_pro['web_name'];
	  	$web_domain = $row_pro['web_domain'];
	  	$web_status = $row_pro['web_status'];
	  	$web_cod = $row_pro['web_cod'];
	  	$web_payment = $row_pro['web_payment'];
	  	$web_discount = $row_pro['web_discount'];
	  	$web_shipping = $row_pro['web_shipping'];
	  	
	    $i++;
	?>
	
	 <tr>
	 
	 	<td><?php echo $i?></td>
	 	<td><?php echo $web_name?></td>
	 	<td><?php echo $web_domain?></td>
	 	<td><?php echo ($web_status==1 ? "Active" : "Inactive")?></td>
	 	<td><?php echo ($web_cod==1 ? "Yes" : "No")?></td>
	 	<td><?php echo ($web_payment==1 ? "Yes" : "No")?></td>
	 	<td><?php echo  $web_discount?></td>
	 	<td><?php echo ($web_shipping==1 ? "FREE" : "PAID")?></td>
	 	<td><a href="edit_web.php?web_id=<?php echo $web_id;?>">Edit</a></td>
	 	<!--<td><a href="javascript:getConfirmation('<?php echo $web_id;?>')">Delete</a></td>-->
	 
	 	
	 </tr>
	
	 <?php } ?>
	 	</tbody> 
    </table>
  </div>
   <script type="text/javascript">
         <!--
            function getConfirmation(web_id){
               var retVal = confirm("Do you want to continue ?");
               if( retVal == true ){
                 window.location.href  = "delete_web.php?delete_web=" +web_id;
               }
               else{
                 // document.write ("User does not want to continue!");
                  return false;
               }
            }
         //-->
      </script>


					
	            </p>
	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>
