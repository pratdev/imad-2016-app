<?php 
include 'session_admin.php';

include 'includes/db.php';


?>



<?php 

if(!isset($_POST['assignrights'])){
	$_POST['user_name']=0;
	//echo $_POST['user_name']=0;
	$_POST['user_page_status']=0;
	$_POST['web_page_status']=0;
    $_POST['categories_page_status']=0;
	$_POST['package_page_status']=0;
	$_POST['add_order_page_status']=0;
	$_POST['search_page_status']=0;
	$_POST['orders_page_status']=0;
	$_POST['report_page_status']=0;
	
	
	
	
}



if (isset($_POST['assignrights'])){
	
	//getting the text data from the fields
	//$user_name = $_POST['user_name'];
	$user_id = $_POST['user_name'];
	
	$user_page_status = $_POST['user_page_status'];
	$web_page_status = $_POST['web_page_status'];
	$categories_page_status = $_POST['categories_page_status'];
	$package_page_status = $_POST['package_page_status'];
	$add_order_page_status = $_POST['add_order_page_status'];
	$search_page_status = $_POST['search_page_status'];
	$orders_page_status = $_POST['orders_page_status'];
	$report_page_status = $_POST['report_page_status'];
	
	$insert_package = "insert into user_page_permission(user_id,user_page_status,web_page_status,categories_page_status,package_page_status,add_order_page_status,search_page_status,orders_page_status,report_page_status)values
	('$user_id','$user_page_status','$web_page_status','$categories_page_status','$package_page_status','$add_order_page_status','$search_page_status','$orders_page_status','$report_page_status')";
	
	$insert_pack = mysqli_query($con, $insert_package);
	
	if($insert_pack){
	echo "<script>alert('You have successfully assigned rights!')</script>";
		//echo $user_id;
		//echo $user_page_status;
		//echo "<script>window.open('index.php','_self')</script>";
		header("location:index.php");
	}
	
}


?>










<?php include 'template/header.php';
      include 'template/sidebar.php';
?>
	  
		    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				
	        	<p>

<?php 

include ('includes/db.php');

?>


       <title>ASSIGN RIGHTS</title>
      
 <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script> -->
       
	





<form action="assign_rights.php" method="POST" >
     <table align="center" width="795" height="600" border="2" bgcolor="#187eae">

           <tr align="center">
             <td colspan="7"><h2>ASSIGN RIGHTS</h2></td>
           </tr>

		   
		   
		     <tr>
             <td align="left"> USER NAME: </td>
             <td>
             
             <select name="user_name"  required/>
                    <option value=""> USER NAME</option>
					<?php

//class="form-control"
$sql="SELECT * FROM admin";
$result=$con->query($sql);

while($row=mysqli_fetch_array($result)){
	
$user_id=$row['user_id'];
$user_loginname= $row['user_loginname'];

if($row['user_status']!="0"){
 echo"<option value='$user_id'>$user_loginname</option>";
  }   
}?>


                  </select>
             
             </td>
           </tr>
	
           <tr>
             <td align="left">USERPAGE STATUS:</td>

              <td>
              <input type="radio" name="user_page_status" value="1" required/ >Active<br>
  		     <input type="radio" name="user_page_status" value="0" required/>Inactive<br>
             </td>

			 </tr>
           
           <tr>
             <td align="left"> WEBPAGE STATUS: </td>
              <td>
              <input type="radio" name="web_page_status" value="1" required/>Active<br>
  		     <input type="radio" name="web_page_status" value="0" required/>Inactive<br>
             </td>
           </tr>
           
           <tr>
             <td align="left"> CATEGORIESPAGE STATUS: </td>

               <td>
              <input type="radio" name="categories_page_status" value="1" required/>Active<br>
  		     <input type="radio" name="categories_page_status" value="0" required/>Inactive<br>
             </td>

			 </tr>
           
           <tr>
             <td align="left"> PACKAGEPAGE STATUS: </td>
             <td>
              <input type="radio" name="package_page_status" value="1" required/>Active<br>
  		     <input type="radio" name="package_page_status" value="0" required/>Inactive<br>
             </td>           </tr>
           
           <tr>
             <td align="left">MOBILEORDERPAGE Status: </td>
             <td>
              <input type="radio" name="add_order_page_status" value="1" required/>Active<br>
  		     <input type="radio" name="add_order_page_status" value="0" required/>Inactive<br>
             </td>
           </tr>
           
		   
		   
		     <tr>
             <td align="left"> SEARCHORDERPAGE STATUS: </td>

               <td>
              <input type="radio" name="search_page_status" value="1" required/>Active<br>
  		     <input type="radio" name="search_page_status" value="0" required/>Inactive<br>
             </td>

			 </tr>
           
           <tr>
             <td align="left"> ORDERPAGE STATUS: </td>
             <td>
              <input type="radio" name="orders_page_status" value="1" required/>Active<br>
  		     <input type="radio" name="orders_page_status" value="0" required/>Inactive<br>
             </td>           </tr>
           
           <tr>
             <td align="left">REPORTPAGE Status: </td>
             <td>
              <input type="radio" name="report_page_status" value="1" required/>Active<br>
  		     <input type="radio" name="report_page_status" value="0" required/>Inactive<br>
             </td>
           </tr>
		   
		   
		   
		   
           <tr align="center">
             <td colspan="7"><input type="submit" name="assignrights" value="ASSIGN RIGHTS NOW" /></td>
           </tr>
           
           
           
     </table> 

</form>

<?php //echo $_POST['user_id']; ?>




   </p>
	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>





           <tr>
             <td align="left"><?php echo $pagename;   ?>:</td>

             <td>
              <input type="checkbox" name="id[]" id="id" value="<?php echo $id; ?>">
             </td>

			 </tr>
			 
			 
			 
			  <tr>
             <td align="left"><?php echo $pagename;   ?>:</td>
             <td>
             <input type="checkbox" name="id[]" id="id" value="<?php echo $id; ?>">
             </td>
		   </tr>
			 

