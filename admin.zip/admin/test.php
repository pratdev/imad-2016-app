<?php 
		

		include ("includes/db.php");
		
		
		if (isset($_GET['user_pin'])){
			 
			$pin = $_GET['user_pin'];
		
			$pin = mysqli_real_escape_string($con, $pin);
			 
			if (!is_null($pin) and !empty($pin)) {
				 
					//echo $pin ;
					$get_pin = "SELECT * from pincode where pincode='".$pin."'";
					
					$data = array();
					$run_pin = mysqli_query($con,$get_pin);
					if( mysqli_num_rows($run_pin) > 0 ){
						
					$sql_result = mysqli_fetch_assoc($run_pin);
					$data = array(
							'state'    =>    $sql_result['stateid'],
							'cityname'    => $sql_result['cityname']
							)	;
                    
					$data2 =array();
					array_push($data2,array('Location'    =>  $sql_result['Location']));
					while ($row_pin=mysqli_fetch_assoc($run_pin)) {
						//echo $get_pin;
						//$stateid  = $sql_result['stateid'];					
						array_push($data2,array('Location'    =>  $row_pin['Location']));
					
						}
						
					
					array_push($data,$data2);
					
					echo json_encode($data);
					}else {
						$data = array(
								'state'    =>    "0",
								'cityname'    => ""
						)	;
						//array_push($data,$data2);
							
						echo json_encode($data);
					}
				}
			}
?>