<?php 
				
include 'session.php';
include 'includes/db.php';
if(isset($_POST['submit'])){
	
	
}
else{
	$_POST['byorder']="";
	$_POST['bypost']="";
	$_POST['orderstatus']="";
	$_POST['paymentmethod']="";
	$_POST['startdate']="";
	$_POST['enddate']="";
	$_POST['couriercompany']="";
	$_POST['id']="";
	$_POST['webisiteid']="";	
	$_POST['user_id']="";
}
   ?>   



<!DOCTYPE HTML>
<html>
  <head>
    <link href="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.2.2/css/bootstrap-combined.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" media="screen"
     href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
	     
  </head>
<body>

<?php include 'template/header.php';
     
?>
	<title>View Order Details | Genius Admin Panel</title>
	  
  <!-- 
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
--> 
<link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel='stylesheet' type='text/css' />

 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">

<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
	    <script type="text/javascript"
     src="http://tarruda.github.com/bootstrap-datetimepicker/assets/js/bootstrap-datetimepicker.min.js">
    </script>
	  <script>
				$(document).ready(function() {
					$('#example').DataTable();
				} );


			  $( function() {
				$( "#datepicker" ).datepicker();
			  } );
			  
			  
			 $( function() {
				$( "#datepicker2" ).datepicker();
			  } );
		

	  </script>

	  <!--<script type="text/javascript">
			$(document).ready(function(){
		          $( "#target" ).click(function() {
						$("#myModal").modal('show');
					});});
	 </script>-->
 	 
 	 
 	 <?php 
	 include 'template/sidebar.php';
?>
	 <?php/*
	 if(isset($_POST['submit'])) {
        $sql = mysql_query("SELECT * FROM table WHERE name LIKE '%" . $_POST['name'] . "%'
                   OR address LIKE '%" . $_POST['address'] . "%'
                   OR city LIKE '%" . $_POST['city'] . "%'
                   OR state LIKE '%" . $_POST['state'] . "%'
                   OR zip LIKE '%" . $_POST['zip'] . "%'");
    }*/
?>



 	  <div id="page-wrapper" class="gray-bg dashbard-1">
	  
     <!--Search options starts here-->
	 <h1 style="color:green; font-family:arial;" ><b>VIEW REPORT</b></h1>
      
	  <div id="form">
	 <form method="post" action="<?php $_SERVER['PHP_SELF']; ?>" >
		<table  align="left" width="100%" border="1" bgcolor="#187eae">
<tr>
                <td>WEBSITE NAME:</td>
                <td><select name="webisiteid" class="form-control" onchange="showCustomer(this.value)">
				         
						 
	  <option value="" <?php echo($_POST['webisiteid']=="" ? "Selected": "");?>  >ALL</option>

				 <?php
 
 
$sql="SELECT * FROM websites ";
$result=$con->query($sql);

while($row=mysqli_fetch_array($result)){
$web_id=$row['web_id'];
$web_domain= $row['web_domain'];

echo "<option value='$web_id' ".  ($web_id==$_POST['webisiteid'] ? "Selected": "")  ." >".$web_domain."</option>";
}
?>
						</select>
								</td>
								
								<td>ORDER BY:</td>
                <td>
				<select name="byorder" class="form-control">
							<option value="" <?php echo ($_POST['byorder']=="" ? "Selected": "");?>  >byorder</option>
											
							<option value="WO"  <?php echo ($_POST['byorder']=="WO" ? "Selected": "");?>  >WEBSITE</option>
							<option value="MO"  <?php echo ($_POST['byorder']=="MO" ? "Selected": "");?>  >MOBILE</option>
							
						</select>
				</td>
								
								
								
            </tr>
           
            <tr>
                <td>ORDER TYPE:</td>
                <td>
				<select name="bypost" class="form-control">
				            <option value=""  >Bypost</option>
							<option value="PO" <?php echo ($_POST['bypost']=="PO" ? "Selected": "");?>  >PO</option>
							<option value="CR" <?php echo ($_POST['bypost']=="CR" ? "Selected": "");?>  >CR</option>
							
						</select>
				</td>
				
				<td>ACTION:</td>
                <td>
				<select name="orderstatus" class="form-control">
											<option value=""  >orderstatus</option>

							<option value="PENDING"  <?php echo ($_POST['orderstatus']=="PENDING" ? "Selected": "");?> >PENDING</option>
                            <option value="AWAITINGSHIPPING" <?php echo ($_POST['orderstatus']=="AWAITINGSHIPPING" ? "Selected": "");?>  >AWAITING SHIPPING</option>
							 <option value="SHIPPEDORDER" <?php echo ($_POST['orderstatus']=="SHIPPEDORDER" ? "Selected": "");?>  >SHIPPED ORDER</option>
							<option value="CONFIRM" <?php echo ($_POST['orderstatus']=="CONFIRM" ? "Selected": "");?>  >CONFIRM</option>
							<option value="CANCEL"  <?php echo ($_POST['orderstatus']=="CANCEL" ? "Selected": "");?> >CANCEL</option>

					</select>
			</td>
				
            </tr>
           
			 <tr>
                <td>PAYMENT METHOD:</td>
                <td>
				<select name="paymentmethod" class="form-control">
				            <option value=""  >ALL</option>
							<option value="ONLINE" <?php echo ($_POST['paymentmethod']=="ONLINE" ? "Selected": "");?>   >ONLINE</option>
							<option value="COD" <?php echo ($_POST['paymentmethod']=="COD" ? "Selected": "");?>   >COD</option>
							
						</select>
				</td>
				
				<td>COURIER COMPANY:</td>
				<td>
				<select name="couriercompany" class="form-control">
				            <option value=""  >ALL</option>
							<option value="POSTOFFICE" <?php echo ($_POST['couriercompany']=="POSTOFFICE" ? "Selected": "");?>   >POSTOFFICE</option>
							<option value="Delhivery" <?php echo ($_POST['couriercompany']=="Delhivery" ? "Selected": "");?>   >Delhivery</option>
						    <option value="fedex" <?php echo ($_POST['couriercompany']=="fedex" ? "Selected": "");?>   >fedex</option>
							<option value="bluedart" <?php echo ($_POST['couriercompany']=="bluedart" ? "Selected": "");?>   >bluedart</option>

						</select>
				
				</td>
				
            </tr>
			
			<tr>
           <td>FROM:</td>
                <td>
				    <div id="datetimepicker" class="input-append date">
      <input type="text" class="fc-calendar" name="startdate" value="<?php echo $_POST['startdate']?>"  required />"<?php echo $_POST['startdate']?>"</input>
      <span class="add-on">
        <i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
      </span>
    </div>
				</td>
				 <td>TO:</td>
                <td>
				
				<div id="1datetimepicker" class="input-append date">
      <input type="text" name="enddate" value="<?php echo $_POST['enddate']?>" required /  ></input>
      <span class="add-on">
        <i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
      </span>
    </div>
	 
				</td>
				
            </tr>
			
			<tr>
			
             <td>ORDER ID:</td>
                <td><input type="text" name="id" class="form-control" /></td>
            
                <td> TRANSFER USER BY:&nbsp;</td>
                <td>
				
				<select name="user_id" class="form-control">
				         
						 
<option value="" <?php echo($_POST['user_id']=="" ? "Selected": "");?>  >ALL</option>
				 <?php
 
 
$sql="SELECT * FROM admin ";
$result=$con->query($sql);

while($row=mysqli_fetch_array($result)){
$user_id=$row['user_id'];
$user_loginname= $row['user_loginname'];

echo "<option value='$user_id' ".  ($user_id==$_POST['user_id'] ? "Selected": "")  ." >".$user_loginname."</option>";
}
?>
						</select>
				
				
				
			
				
				</td>
            </tr>
			<tr>
			<td>PACKAGE NAME:</td>
			<td>  
			<?php 
		//	if(!isset($_POST['pac_coup_id'])){

?>
			<div id="txtHint"> </div>
<?php		 /*
			}
			else{
				//include'get_offer_pack.php';
			foreach($_POST['pac_coup_id'] as $key => $value){
			echo $key;
echo$value;			
			}
			
				
			}*/
			?>
			
</td>
			<td colspan="4" align="center"><input type="submit" name="submit" value="Search" class="btn btn-success" id="btnSubmit"/></td>
			
			</tr>
			
		
			
			
			
			<?php// echo $_POST['startdate']?>
						<?php// echo $_POST['enddate']?>

        </form>
    </table>
	 
	 </div>
	 
    <!--Search options ends here--> 

       <div class="content-main">

 	<div class="blank">
 	
					
 		

  <h3 style="color:green;font-family:arial">REPORT</h3>
  <br>
 <div style="overflow-x:auto;">
  <table id="example" class="display"  cellspacing="0" width="100%">
 	
 <thead>
	<tr>
	    <th>Serial No.</th>
	    <th>Order Id</th>
	    <th>Website Name</th>
		<th>Order Status</th>
	    <th>Pincode</th>
		<th>Name</th>
		<th>Mobile No.</th>
		<th>Email</th>
		<th>Address</th>
		<th>State</th>
		<th>City</th>
        <th>Locality</th>
		<th>Payment Mode</th>
		<th>Payment Status</th>
		<th>Package Name</th>
		<th>Package Price</th>
		<th>Shipping Price</th>
		<th>Order Type</th>
		<th>Courier Company</th>
		<th>Tracking Code</th>
		<th>Byorder</th>
		<th>Order Date Time</th>
		<th>Transfer By/Final By</th>		
			
		<!--<th>Admin Response</th>
		
	    <th class="select">Command</th>
		
	    <th class="select">Payment Status</th>-->

   </tr>   
</thead>
 		<tbody>
	     
		<?php 
	    //include ("includes/db.php");
	  if(isset($_POST['submit'])){
		  
		  if($_POST['user_id']!=""){
			  
			  
			  
	  $get_pro = "select orderdetails.*,package.*,states.states,admin.user_loginname from orderdetails LEFT JOIN  package ON orderdetails.packageid=package.p_id
                   LEFT JOIN states ON states.stateid = orderdetails.state
				   LEFT JOIN admin ON admin.user_id = orderdetails.user_id				   
				   WHERE orderdetails.web_id LIKE '%" . $_POST['webisiteid'] . "%'
                   AND orderdetails.byorder LIKE '%" . $_POST['byorder'] . "%'
                   AND orderdetails.bypost LIKE '%" . $_POST['bypost'] . "%'
                   AND orderdetails.orderstatus LIKE '%" . $_POST['orderstatus'] . "%'
				   AND orderdetails.paymentmethod LIKE '%" . $_POST['paymentmethod'] . "%' 
                   AND orderdetails.couriercompany LIKE '%" . $_POST['couriercompany'] . "%' 
				   AND orderdetails.OrderDate BETWEEN '". $_POST['startdate'] ."' AND '". $_POST['enddate']. "'
                   AND orderdetails.user_id LIKE '" . $_POST['user_id'] . "' 
				   AND orderdetails.id LIKE '%" . $_POST['id'] . "%'";
				   
					if(isset($_POST['pac_coup_id'])){
					$arraypage=$_POST['pac_coup_id'];
					/*echo $arraypage;
					echo var_export($arraypage);
					$pac_coup_id = implode(",", $_POST['pac_coup_id']);
					echo $pac_coup_id;*/
					if(isset($arraypage)){
					//	$get_pro=$get_pro ." AND";
					$val=0;
					foreach($arraypage as $p_id) {
					//echo $p_id."<br>";


					if($val==0){
					$val=$val+1;
					$get_pro=$get_pro ." AND (orderdetails.packageid = '" . $p_id . "'";

					}
					else{
					$get_pro=$get_pro ." OR orderdetails.packageid = '" . $p_id . "'";
					}
					}
					$get_pro=$get_pro .")";

					}					   

					}

					$get_pro = $get_pro ." order by orderdetails.id desc";
					
	//				echo $get_pro;
				   }
				   

				   else{
					   
					   
					   
					   
				   $get_pro = "select orderdetails.*,package.*,states.states,admin.user_loginname from orderdetails LEFT JOIN  package ON orderdetails.packageid=package.p_id
                   LEFT JOIN states ON states.stateid = orderdetails.state
				   LEFT JOIN admin ON admin.user_id = orderdetails.user_id				   
				   WHERE orderdetails.web_id LIKE '%" . $_POST['webisiteid'] . "%'
                   AND orderdetails.byorder LIKE '%" . $_POST['byorder'] . "%'
                   AND orderdetails.bypost LIKE '%" . $_POST['bypost'] . "%'
                   AND orderdetails.orderstatus LIKE '%" . $_POST['orderstatus'] . "%'
				   AND orderdetails.paymentmethod LIKE '%" . $_POST['paymentmethod'] . "%' 
                   AND orderdetails.couriercompany LIKE '%" . $_POST['couriercompany'] . "%' 
				   AND orderdetails.OrderDate BETWEEN '". $_POST['startdate'] ."' AND '". $_POST['enddate']. "'
				   AND orderdetails.id LIKE '%" . $_POST['id'] . "%'";  
				   
				   
				   
				       if(isset($_POST['pac_coup_id'])){
					   $arraypage=$_POST['pac_coup_id'];
							/*  echo $arraypage;
							echo var_export($arraypage);
							$pac_coup_id = implode(",", $_POST['pac_coup_id']);
							echo $pac_coup_id;*/
					if(isset($arraypage)){
					//	$get_pro=$get_pro ." AND";
					$val=0;
					foreach($arraypage as $p_id) {
					//echo $p_id."<br>";

                    
			        if($val==0){
				 	$val=$val+1;
 					$get_pro=$get_pro ." AND (orderdetails.packageid = '" . $p_id . "'";

			        }
					else{
					$get_pro=$get_pro ." OR orderdetails.packageid = '" . $p_id . "'";
					}
					  }
					  $get_pro=$get_pro .")";
					}					   
					
				   }
				   
					$get_pro = $get_pro ." order by orderdetails.id desc";
				
				 //  echo $get_pro;
					   
				   }
				   
				   
	/*				}

if(empty($_POST['id']))	{				
						
		   $get_pro = "select orderdetails.*,package.*,states.states from orderdetails INNER JOIN  package ON orderdetails.packageid=package.p_id
                   INNER JOIN states ON states.stateid = orderdetails.state WHERE orderdetails.id =$_POST['webisiteid']";
		
		  
}
	*/			   
				   
	  
	  //help for above query
	 // select  package.*, websites.web_domain from package INNER JOIN websites ON package.p_web_id=websites.web_id where websites.web_domain='$web_domain' 
	// echo  $get_pro;
	 // exit();
	  $run_pro = mysqli_query($con, $get_pro);
	 // $row_pro = mysqli_query($con, $get_pro);
	  $i=0;
$num_rows = mysqli_num_rows($run_pro);

echo "<b>"."Total No. of Orders=$num_rows \n"."</b>";

	  while ($row_pro=mysqli_fetch_array($run_pro))
	  {
			
			$web_domain =  $row_pro['web_domain'];	
		    
			$id = $row_pro['id'];

			$prefix = $row_pro['prefix'];
			$order_id = $row_pro['id'];
            $orderstatus = $row_pro['orderstatus'];
			
			$pincode = $row_pro['pin'];

			$name =  $row_pro['name'];
			$number = $row_pro['mobile'];
			$email = $row_pro['email'];
			$address = $row_pro['address'];
			$states =  $row_pro['states'];
			$cityname = $row_pro['city'];
			$SelLocation = $row_pro['locality'];
			$package = $row_pro['p_name'];
			$packagecost = $row_pro['pack_price'];
			$bypost = $row_pro['bypost'];
			$paymentmethod = $row_pro['paymentmethod']; 
			$shippingcharge=$row_pro['shippingcharge'];
			$user_loginname=$row_pro['user_loginname'];
			
			/*
			if($paymentmethod=="ONLINE")
		  {
			  $packagecost=round($packagecost*.95);
		  }
		  else{
			 $packagecost=$packagecost;
		  }*/

            $OrderDate = $row_pro['OrderDate'];
	

		  // $pcode = $row_pro['PostalCode'];--not here on form i.e run time only
		
			



			$bgcolor="";

			if( $orderstatus=="PENDING" || $orderstatus=="NONE")
		  {
				$bgcolor="#DAFF33";
          }else if($orderstatus=="CONFIRM")
		  {
			   $bgcolor="#5AE012"; 
		  }
		  else if($orderstatus=="CANCEL")
		  {
			  $bgcolor="#FF5833";
		  }

	    $i++;
	?>
	
	 <tr style=" background-color:<?php echo $bgcolor;?>">
	    
	 	<td><?php echo $i?></td>
		<td><?php echo $prefix."-".$bypost."-".$order_id;?></td>
		<td><?php echo $web_domain?></td>
		<td><?php echo $orderstatus?></td>
	 	<td><?php echo $pincode?></td>
	 	<td><?php echo $name?></td>
	 	<td><?php echo $number?></td>
	 	<td><?php echo $email?></td>
	 	<td><?php echo $address?></td>
	 	<td><?php echo $states?></td>
		<td><?php echo $cityname?></td>
		<td><?php echo $SelLocation?></td>
		<td><?php echo $paymentmethod?></td>
	    <td><?php echo $row_pro['paymentstatus']?></td>
		<td><?php echo $package?></td>
        <td><?php echo $packagecost?></td>
		<td><?php echo $shippingcharge?></td>
		<td><?php echo $row_pro['bypost']?></td>
        <td><?php echo $row_pro['couriercompany']?></td>
		<td><?php echo $row_pro['trackingcode']?></td>
        <td><?php echo $row_pro['byorder']?></td>
	    <td><?php echo $OrderDate?></td>
	 	<td><?php echo $user_loginname?></td>


	 	<!--<td><a href="edit_order.php?id=<?php// echo $row_pro['id'];?>">Edit</a></td>
		  <td><a href="chek.php?id=<?php// echo $id;?>"><?php //echo "EDIT";?></a></td>
	 	<td><a href="javascript:getConfirmation('<?php //echo $order_id;?>')">Delete</a></td>-->
	 
	 	 </tr>
	
	
	 <?php } 
	  }?>
	
	 </tbody> 
	 
   </table>
</div>
       </div>
     
      
 
    <script type="text/javascript">
      $('#datetimepicker').datetimepicker({
        format: 'yyyy-MM-dd hh:mm:ss',
       
      });
    </script>
	
	
	 
	
    
    <script type="text/javascript">
      $('#1datetimepicker').datetimepicker({
        format: 'yyyy-MM-dd hh:mm:ss',
		
       
      });
    </script>
	<script>
		function showCustomer(id) {
		  var xhttp;    
		  if (id == "") {
			document.getElementById("txtHint").innerHTML = "";
			return;
		  }
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				//var checkedValue = document.querySelector('.messageCheckbox:checked').value;
				
				
			  document.getElementById("txtHint").innerHTML = this.responseText;
			}
		  };
		  xhttp.open("GET", "get_offer_pack.php?id="+id, true);
		  xhttp.send();
		}
		</script>
	   
	  
	  
	  
	  <script type="text/javascript">
   

</script>
	  
	  
     
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>
<?php ?> 
</body>
</html>	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 