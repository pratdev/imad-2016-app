<?php 
include 'session.php';

include 'includes/db.php';


?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
?>
	
	   
 
 
<link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel='stylesheet' type='text/css' />

<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

  <script>
			$(document).ready(function() {
                $('#example').DataTable();
            } );

  </script>
 	 
 	 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 		<div class="blank">
 	 
 	 
 	
 	
  <h2>View All Categories Here</h2>
  <div style="overflow-x:auto;">
  <table id="example" class="display" cellspacing="0" width="100%">
     
	
<thead>
	<tr>
		<th>Serial No.</th>
		<th>Category Title</th>
		<th>Domain Name</th>
		<th>Edit</th>
		<!--<th>Delete</th>-->
	</tr>
</thead>	
		<tbody>
	<?php 
	include("includes/db.php");
	
	$get_cat = "SELECT categories.*, websites.web_domain
                FROM categories INNER JOIN websites ON categories.c_web_id = websites.web_id;";
	
	$run_cat = mysqli_query($con, $get_cat); 
	
	$i = 0;
	
	while ($row_cat=mysqli_fetch_array($run_cat)){
		
		$cat_id = $row_cat['cat_id'];
		
		$cat_title = $row_cat['cat_title'];
		$web_id = $row_cat['web_domain'];
		$i++;
	
	?>
	
	<tr>
		<td><?php echo $i;?></td>
		<td><?php echo $cat_title;?></td>
		<td><?php echo "$web_id";?></td>
		<td><a href="edit_cat.php?cat_id=<?php echo $row_cat['cat_id']; ?>">Edit</a></td>
		<!--<td><a href="javascript:getConfirmation('<?php //echo $cat_id;?>')">Delete</a></td>-->
	
	</tr>
	
	<?php } ?>

</tbody>


</table>



 </table>
</div>
          <script type="text/javascript">
         <!--
            function getConfirmation(cat_id){
               var retVal = confirm("Do you want to continue ?");
               if( retVal == true ){
                 window.location.href  = "delete_cat.php?delete_cat=" +cat_id;
               }
               else{
                 // document.write ("User does not want to continue!");
                  return false;
               }
            }
         //-->
      </script>
<?php include 'template/footer.php';?>


