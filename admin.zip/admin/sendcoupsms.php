











<?php 
				
include 'session.php';
include 'includes/db.php';
if(isset($_POST['submit'])){


$startdate=mysqli_real_escape_string($con,$_POST['startdate']);
$enddate=mysqli_real_escape_string($con,$_POST['enddate']);
$bypost=mysqli_real_escape_string($con,$_POST['bypost']);
$orderstatus=mysqli_real_escape_string($con,$_POST['orderstatus']);
$webisiteid=mysqli_real_escape_string($con,$_POST['webisiteid']);
$coup_id=mysqli_real_escape_string($con,$_POST['coup_id']);
$sendby=mysqli_real_escape_string($con,$_POST['sendby']);


if(isset($_POST['pac_coup_id'])){
$arraypage=$_POST['pac_coup_id'];
//echo var_export($arraypage);
//echo"<br>";
 $pac_coup_id = implode(",", $_POST['pac_coup_id']);
//echo $pac_coup_id;
//echo"<br>";
}
else{
	$pac_coup_id="";
	
}

//echo $coup_id;	
}






else{
	
	$_POST['startdate']="";
	$_POST['enddate']="";
	$_POST['bypost']="";
	$_POST['orderstatus']="";
	$_POST['webisiteid']="";	
	$_POST['coup_id']="";

	
}
   ?>   



<!DOCTYPE HTML>
<html>
  <head>
    <link href="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.2.2/css/bootstrap-combined.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" media="screen"
     href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
	     
  


	 

	 

	 
	 
	 
	 
	 
	 
	 
	 
	 
  </head>
<body>

<?php include 'template/header.php';
     
?>
	<title>View Order Details | Genius Admin Panel</title>
	  
  <!-- 
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
--> 
<link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel='stylesheet' type='text/css' />

 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">

<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
	    <script type="text/javascript"
     src="http://tarruda.github.com/bootstrap-datetimepicker/assets/js/bootstrap-datetimepicker.min.js">
    </script>
	  <script>
				$(document).ready(function() {
					$('#example').DataTable();
				} );


			  $( function() {
				$( "#datepicker" ).datepicker();
			  } );
			  
			  
			 $( function() {
				$( "#datepicker2" ).datepicker();
			  } );
		

	  </script>

	  <!--<script type="text/javascript">
			$(document).ready(function(){
		          $( "#target" ).click(function() {
						$("#myModal").modal('show');
					});});
	 </script>-->
 	 
 	 
 	 <?php 
	 include 'template/sidebar.php';
?>
	 <?php/*
	 if(isset($_POST['submit'])) {
        $sql = mysql_query("SELECT * FROM table WHERE name LIKE '%" . $_POST['name'] . "%'
                   OR address LIKE '%" . $_POST['address'] . "%'
                   OR city LIKE '%" . $_POST['city'] . "%'
                   OR state LIKE '%" . $_POST['state'] . "%'
                   OR zip LIKE '%" . $_POST['zip'] . "%'");
    }*/
?>



 	  <div id="page-wrapper" class="gray-bg dashbard-1">
	  
     <!--Search options starts here-->
	 <h1 style="color:green; font-family:arial;" ><b>SEND COUPON VIA SMS</b></h1>
      
	  <div id="form">
	 <form method="post" action="<?php $_SERVER['PHP_SELF']; ?>" >
		<table  align="left" width="100%" border="1" bgcolor="#187eae">
		
		<tr>
           <td>CHOOSE FROM ORDERDATE:</td>
                <td>
				    <div id="datetimepicker" class="input-append date">
      <input type="text" class="fc-calendar" name="startdate" value="<?php echo $_POST['startdate']?>"  required />"<?php echo $_POST['startdate']?>"</input>
      <span class="add-on">
        <i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
      </span>
    </div>
				
				
				
				</td>
				 <td>CHOOSE ORDERDATE TO:</td>
                <td>
				
				<div id="1datetimepicker" class="input-append date">
      <input type="text" name="enddate" value="<?php echo $_POST['enddate']?>" required /  ></input>
      <span class="add-on">
        <i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
      </span>
    </div>
	 
				
				
				
				</td>
				
				
				
				
				
				
				 
				
				
				 
            </tr>
			
			
			 <tr>
                <td>ORDER TYPE:</td>
                <td>
				<select name="bypost" class="form-control">
				            <option value=""  >Bypost</option>
							<option value="PO" <?php echo ($_POST['bypost']=="PO" ? "Selected": "");?>  >PO</option>
							<option value="CR" <?php echo ($_POST['bypost']=="CR" ? "Selected": "");?>  >CR</option>
							
						</select>
				</td>
				
				<td>ORDER STATUS:</td>
                <td>
				<select name="orderstatus" class="form-control">
											<option value=""  >orderstatus</option>
                           <option value="CONFIRM" <?php echo ($_POST['orderstatus']=="CONFIRM" ? "Selected": "");?>  >CONFIRM</option>
							<option value="CANCEL"  <?php echo ($_POST['orderstatus']=="CANCEL" ? "Selected": "");?> >CANCEL</option>
                            <option value="RECEIVE" <?php echo ($_POST['orderstatus']=="AWAITINGSHIPPING" ? "Selected": "");?>  >AWAITING SHIPPING</option>
							 <option value="RETURN" <?php echo ($_POST['orderstatus']=="SHIPPEDORDER" ? "Selected": "");?>  >SHIPPED ORDER</option>
							

					</select>
			</td>
				
            </tr>
		
		
		
<tr>
                <td>WEBSITE NAME:</td>
                <td><select name="webisiteid" class="form-control" onchange="showCustomer(this.value)">
				         
						 
	  <option value="" <?php echo($_POST['webisiteid']=="" ? "Selected": "");?>  >ALL</option>

				 <?php
 
 
$sql="SELECT * FROM websites ";
$result=$con->query($sql);

while($row=mysqli_fetch_array($result)){
$web_id=$row['web_id'];
$web_domain= $row['web_domain'];

echo "<option value='$web_id' ".  ($web_id==$_POST['webisiteid'] ? "Selected": "")  ." >".$web_domain."</option>";
}
?>
						</select>
								</td>
								
								
								
								
								
								
								
								
								
								<td>COUPON NAME:</td>
                <td><select name="coup_id" class="form-control">
				         
						 
	  <option value=""   >SELECT COUPON</option>

				 <?php
 
 
$sql="SELECT * FROM coupondetails where coup_expiry_date >=CURRENT_DATE()";
$result=$con->query($sql);

while($row=mysqli_fetch_array($result)){
$coup_id=$row['coup_id'];
$coup_name= $row['coup_name'];

echo "<option value='$coup_id'>".$coup_name."</option>";
}
?>
						</select>
								</td>
								
								
							
            </tr>
           
           
           
		
			
			
			
			
			
			
			

			
			<tr>
			<td>PACKAGE NAME:</td>
			<td>  
			<div id="txtHint"> </div>
</td>
		<td>SEND BY:</td>
		<td>
		<select name="sendby" class="form-control" required>
		<option value=""  >SEND BY</option>
		<option value="SMS" >SMS</option>
		<option value="E-MAIL">E-MAIL</option>



		</select>
		</td>
			
			</tr>
			<tr>
			
			<td colspan="4" align="center"><input type="submit" name="submit" value="Send_SMS" class="btn btn-success" /></td>
			
			</tr>
			
			
		
			
			
			<?php// echo $_POST['startdate']?>
						<?php// echo $_POST['enddate']?>
 </form>
    </table>
      
	 
	 </div>
	 
	 
			
			
			
			
			
			
			
	 
	 
	  
    <!--Search options ends here--> 

       <div class="content-main">

 	<div class="blank">
 	
					
 		

  <h3 style="color:green;font-family:arial">VIEW SEND PATTERN</h3>
  <br>
 <div style="overflow-x:auto;">
  <table id="example" class="display"  cellspacing="0" width="100%">
 	
 <thead>
	<tr>
	    <th>Serial No.</th>
	    <th>Order Id</th>
	    <th>Website Name</th>
		<th>Order Status</th>
		<th>Name</th>
		<th>Coupon Code</th>		
		<th>Order Date Time</th>
			
			
		<!--<th>Admin Response</th>
		
	    <th class="select">Command</th>
		
	    <th class="select">Payment Status</th>-->

   </tr>   
</thead>
 		<tbody>
	     
		<?php 
	    //include ("includes/db.php");
	  if(isset($_POST['submit'])){
		  
		  
		  $get_pro= "select orderdetails.*,websites.* from orderdetails LEFT JOIN  websites ON orderdetails.web_id=websites.web_id            			   
				   where orderdetails.web_id LIKE '%" . $_POST['webisiteid'] . "%'
                   AND orderdetails.bypost LIKE '%" . $_POST['bypost'] . "%'
                   AND orderdetails.orderstatus LIKE '%" . $_POST['orderstatus'] . "%'
				   AND orderdetails.OrderDate BETWEEN '". $_POST['startdate'] ."' AND '". $_POST['enddate']. "' group by mobile
				    order by orderdetails.id desc ";  
		  
		  
		  
		  
		  $qwsql="select * from orderdetails orderdetails 
		   where bypost='".$bypost."'
and orderstatus='".$orderstatus."' and web_id='".$webisiteid."' 
and  OrderDate between '".$startdate."' and '".$enddate."'";
//echo $get_pro;
	  $run_pro = mysqli_query($con, $get_pro);

				   
	/*				}

if(empty($_POST['id']))	{				
						
		   $get_pro = "select orderdetails.*,package.*,states.states from orderdetails INNER JOIN  package ON orderdetails.packageid=package.p_id
                   INNER JOIN states ON states.stateid = orderdetails.state WHERE orderdetails.id =$_POST['webisiteid']";
		
		  
}
	*/			   
				   
	  
	  //help for above query
	 // select  package.*, websites.web_domain from package INNER JOIN websites ON package.p_web_id=websites.web_id where websites.web_domain='$web_domain' 
	// echo  $get_pro;
	 // exit();
	 // $run_pro = mysqli_query($con, $get_pro);
	 // $row_pro = mysqli_query($con, $get_pro);
	  $i=0;
$num_rows = mysqli_num_rows($run_pro);

echo "<b>"."Total No. of Orders=$num_rows \n"."</b>";

	  while ($row_pro=mysqli_fetch_array($run_pro))	  
		  {
	$id=$row_pro['id'];
	$name=$row_pro['name'];
	$OrderDate=$row_pro['OrderDate'];
	$bypost=$row_pro['bypost'];
	$orderstatus=$row_pro['orderstatus'];
	$webisiteid=$row_pro['web_id'];
	$coup_code=$row_pro['coupon_code'];
	$prefix=$row_pro['prefix'];
	$web_domain=$row_pro['web_domain'];
	$number=$row_pro['mobile'];
	$send_coup_code_date=$row_pro['send_coup_code_date'];
	$email=$row_pro['email'];
	$packagecost=$row_pro['pack_price'];
	$email=$row_pro['email'];
	$mobile=$row_pro['mobile'];
	$address=$row_pro['address'];
    $web_name=$row_pro['web_name'];
	$orderid=$prefix."-".$bypost."-".$id;
    $byorder=$row_pro['byorder'];
    $shippingcharge=$row_pro['shippingcharge'];
		/*
			if($paymentmethod=="ONLINE")
		  {
			  $packagecost=round($packagecost*.95);
		  }
		  else{
			 $packagecost=$packagecost;
		  }*/

	

		  // $pcode = $row_pro['PostalCode'];--not here on form i.e run time only
		  
		  
		  
		  
        $coupon_code= sprintf('%06X', mt_rand(0, 16777215));

		$date="";
		$today="";
		$sql1="select date(sendsms_date) from sendcouponcodedetails  where orderid='AK-CR-10298' and sendsms_date = (
 SELECT MAX( sendsms_date )
 FROM sendcouponcodedetails )
 LIMIT 1";
	 $results=$con->query($sql1);

     while($row=mysqli_fetch_array($results)){
	
			$sendsms_date=$row['sendsms_date'];
			echo $sendsms_date;
            $date=date('Y-m-d',$sendsms_date);
		    $today=date("Y-m-d");
			echo $date;
			
		}
		
		    echo $date;
			echo $today;
		if($date < $today){
        $sql="insert into sendcouponcodedetails(orderid,coup_id,coup_pac_id,coupon_code,coup_pac_cost,offer_pac_cost,byorder,ordertype,shipping
		,byoffer) values('$orderid','$coup_id','$pac_coup_id','$coupon_code','$packagecost','$packagecost','$byorder','$orderstatus','$shippingcharge','$sendby')";			
			
		}
		else{
		
		
		//$sql="update orderdetails set send_coup_code_date=CURDATE() where id='298'";
		$sql="insert into sendcouponcodedetails(orderid,coup_id,coup_pac_id,coupon_code,coup_pac_cost,offer_pac_cost,byorder,ordertype,shipping
		,byoffer) values('$orderid','$coup_id','$pac_coup_id','$coupon_code','$packagecost','$packagecost','$byorder','$orderstatus','$shippingcharge','$sendby')";	
		  }
		//$sql="update orderdetails set coupon_code='$code' where id='$id' ";
		//$result=$con->query($sql);
		$result = mysqli_query($con, $sql);
		
		//echo $sql;
		echo"<br>";
	//	 echo mysqli_affected_rows($con);
	    //$coup_id=$row_pro['coupon_code'];
	//	echo"send yes";
	//	echo $sendby;
        if(strtolower($sendby)==strtolower("SMS")){	        
            $cat_title="checksms";
			$sellnum="565654654";
			$orderid=$prefix."-".$bypost."-".$id;
			$username = 'youremail@address.com';
			$hash = 'Your API hash';
			$apiKey='7Fok6gPjqoA-vo8T36MkAVdib4COP7YTGyNoRG3IHf';
			$numbers = array($number); 
			//$numbers = array('8004372086','8506805407','9027658633'); 

			$sender = urlencode('GENIUS');
			$date = new DateTime();
			//$message = rawurlencode("Dear ". $name ." Your Order of ". $cat_title  ." has been dispatched by ". $couriercompany  ." and Your TRACKING No: ". $trackingno  ." and for more information you can call on this ". $sellnum  .".");
			$message = rawurlencode("Your order no. "  . $orderid ." of ". $cat_title ." Rs ". $coupon_code ." has been canceled. if you want to order again call ". $sellnum  .".");
			$numbers = implode(',', $numbers);
			$data = array( 'apiKey' => $apiKey, 'numbers' => $numbers, 'test'=>false,  'sender' => $sender, 'message' => $message);
		   try{
			   
			
			$ch = curl_init('http://api.textlocal.in/send/');
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	//    	$response = curl_exec($ch);
			curl_close($ch);
			//echo$response;
			$result = json_decode($response);
			
			
			 }catch (Exception $ex)
			 {
				 echo "<script>alert('Server Error')</script>";
			 }	
		   
				
		  
		   
		   }
		
		
	      else{
			  
			  
	include_once("lib/phpmailer/smtp_config.php");
	include_once("lib/phpmailer/class.phpmailer.php");
	
		$to = $email;
		//$to = ' slimrev1@gmail.com';		
		
		
		$from_name = 'astijivak';
		$subject = 'hi' .$name. 'You have got an offer code ' . date("d M Y, g:i A");
		$message = '';
		$message .= 'Hi,' . "\n" . 'You have got an offer code on ' . "\n" . 'Details are below'. "\n";
		$message .= 'it is valid for today only' . "\n" . 'Terms and Conditions apply' . "\n\n";
		$message .= 'Coupon Code :' . $coupon_code . "\n\n";
		$message .= 'Full Name :' . $name . "\n\n";
		$message .= 'E-mail Id :' . $email . "\n\n";
		$message .= 'Mobile No :' . $mobile . "\n\n";
    	$message .= '-----------------------------------------------------------' . "\n\n";
		//$amount =2;
		$headers = "From: " . $from_name . " <" . $email . ">\n\n";

		$mail = new PHPMailer();
		$mail->IsSMTP();
		
		$mail->Host = MAIL_HOST;
		$mail->SMTPDebug = MAIL_SMTP_DEBUG;
		$mail->SMTPAuth = MAIL_SMTP_AUTH;
		$mail->Port = MAIL_PORT;
		$mail->Username = MAIL_USERNAME;
		$mail->Password = MAIL_PASSWORD;
		$mail->SMTPSecure = MAIL_SMTP_SECURE;

		$mail->SetFrom('noreply@stepupheightincreasers.com',$from_name);

		$mail->Subject = $subject;
		$mail->MsgHTML(nl2br($message));

		if($to != ''){
			$arr_to_emails = explode(",", $to);

			if(count($arr_to_emails))
			{
				foreach($arr_to_emails as $kToEmail => $vToEmail)
				{
					if($vToEmail != '')$mail->AddAddress(trim($vToEmail));
				}
			}
		}
       
		 $mail->Send();
		
		
		  }
	
			  
			  
			  
			  
			  
		
	      	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

			$bgcolor="";

			if( $orderstatus=="PENDING" || $orderstatus=="NONE")
		  {
				$bgcolor="#DAFF33";
          }else if($orderstatus=="CONFIRM")
		  {
			   $bgcolor="#5AE012"; 
		  }
		  else if($orderstatus=="CANCEL")
		  {
			  $bgcolor="#FF5833";
		  }

	    $i++;
	?>
	
	 <tr style=" background-color:<?php echo $bgcolor;?>">
	    
	 	<td><?php echo $i?></td>
		<td><?php echo $prefix."-".$bypost."-".$id;?></td>
		<td><?php echo $webisiteid?></td>
		<td><?php echo $orderstatus?></td>		
	 	<td><?php echo $name?></td>				
	    <td><?php echo $coup_code?></td>
	 	<td><?php echo $OrderDate?></td>
		
		
	 	


	 	<!--<td><a href="edit_order.php?id=<?php// echo $row_pro['id'];?>">Edit</a></td>
		  <td><a href="chek.php?id=<?php// echo $id;?>"><?php //echo "EDIT";?></a></td>
	 	<td><a href="javascript:getConfirmation('<?php //echo $order_id;?>')">Delete</a></td>-->
	 
	 	 </tr>
	
	
	 <?php } 
	  } ?>
	
	 </tbody> 
	 
   </table>
</div>
       </div>
     
      
 
    <script type="text/javascript">
      $('#datetimepicker').datetimepicker({
        format: 'yyyy-MM-dd hh:mm:ss',
       
      });
    </script>
	
	
	 
	
    
    <script type="text/javascript">
      $('#1datetimepicker').datetimepicker({
        format: 'yyyy-MM-dd hh:mm:ss',
		
       
      });
    </script>
	 



		<script>
		function showCustomer(id) {
		  var xhttp;    
		  if (id == "") {
			document.getElementById("txtHint").innerHTML = "";
			return;
		  }
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
			  document.getElementById("txtHint").innerHTML = this.responseText;
			}
		  };
		  xhttp.open("GET", "get_offer_pack.php?id="+id, true);
		  xhttp.send();
		}
		</script>
	 
	  
	  
	  
     
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>
<?php ?> 
</body>
</html>	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 



































<?php /*
	include 'session.php';
	include 'includes/db.php';
	include 'template/header.php';
	include 'template/sidebar.php';
	//echo$sql;
	if(isset($_POST['submit'])){
	$coup_name=mysqli_real_escape_string($con,$_POST['coup_name']);
	$coup_value=mysqli_real_escape_string($con,$_POST['coup_value']);
	$coup_type=mysqli_real_escape_string($con,$_POST['coup_type']);
	$coup_createdate=mysqli_real_escape_string($con,$_POST['coup_createdate']);
	$coup_expirydate=mysqli_real_escape_string($con,$_POST['coup_expirydate']);
	echo"fsdf";
	include 'includes/db.php';
	$sql="select * from coupondetails where coup_name='$coup_name'";
	//echo$sql;
	$result=$con->query($sql);
	
	if($row=$result->fetch_assoc()){
    echo "<script>alert('DUPLICATE COUPON NAME ALREADY EXISTS!')</script>";

	
	}
	else{
	$sql="insert into coupondetails (coup_name, coup_value, coup_type, coup_issue_date,coup_end_date) 
	values('$coup_name','$coup_value','$coup_type','$coup_createdate','$coup_expirydate')";	
	//echo $sql;
	$result=$con->query($sql);	
	echo "<script>alert('You have added coupon successfully!')</script>";
	
		
	}
	
	
	
	
	
	
     }
    else{
	
	$_POST['coup_name']="";
	$_POST['coup_value']="";
	$_POST['coup_type']="";
	$_POST['coup_createdate']="";	
	$_POST['coup_expirydate']="";
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	  
?>
			<!DOCTYPE HTML>
			<html>
			<head>
			<link href="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.2.2/css/bootstrap-combined.min.css" rel="stylesheet">
			<link rel="stylesheet" type="text/css" media="screen"
			href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
			</head>
			<body>
			<?php include 'template/header.php';

			?>
			<title>View Order Details | Genius Admin Panel</title>

			<link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel='stylesheet' type='text/css' />

			<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">

			<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

			<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
			<script type="text/javascript"
			src="http://tarruda.github.com/bootstrap-datetimepicker/assets/js/bootstrap-datetimepicker.min.js">
			</script>
			<script>
			$(document).ready(function() {
			$('#example').DataTable();
			} );


			$( function() {
			$( "#datepicker" ).datepicker();
			} );


			$( function() {
			$( "#datepicker2" ).datepicker();
			} );


			</script>
			<div id="page-wrapper" class="gray-bg dashbard-1">
			<div class="content-main">

			<div class="blank">


			<div class="blank-page">

			<p>

			<title>ADD COUPON</title> 


			<form action="" method="post" > 

			<table align="center" width="795" border="2" bgcolor="#187eae" height="">

			<tr align="center">
			<td colspan="7"><h2>ADD COUPON DETAILS</h2></td>
			</tr>

			<tr>
			<td align="center"><b>COUPON NAME:</b></td>
			<td><input type="text" name="coup_name" size="60" value="<?php ?>"/></td>
			</tr>


			<tr>
			<td align="center"><b>COUPON VALUE:</b></td>
			<td><input type="text" name="coup_value" size="60" value="<?php ?>"/></td>
			</tr>
			<br>
			<br>
			
			<tr>
			<td align="center"><b>COUPON TYPE:</b></td>
			<td>
			<select name="coup_type"  >
			<option value="percentage">Percentage(%)</option>
			<option value="FLAT">FLAT</option>		
			</select>
			</td>
			</tr>
			
			
			<tr>
			<td align="center"><b>COUPON CREATE DATE:</b></td>
			<td>
			<div id="datetimepicker" class="input-append date">
			<input type="text" class="fc-calendar" name="coup_createdate" value=""  required /></input>
			<span class="add-on">
			<i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
			</span>
			</div>
			</td>

			</tr>
			
			
			<tr>
			<td align="center"><b>COUPON EXPIRY DATE:</b></td>
			<td>

			<div id="1datetimepicker" class="input-append date">
			<input type="text" name="coup_expirydate" value="" required /  ></input>
			<span class="add-on">
			<i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
			</span>
			</div>

			</td>

			</tr>

			<tr align="center">

			<td colspan="7"><a href="await_shipped_order.php" class="btn btn-primary">BACK</a>
			<input type="submit" name="submit" class="btn btn-success" value="ADD COUPON"/></td>
			</tr>

			</table>


			</form>

			</p>
			</div>
			</div>


			<script type="text/javascript">
			$('#datetimepicker').datetimepicker({
			format: 'yyyy-MM-dd hh:mm:ss',

			});
			</script>





			<script type="text/javascript">
			$('#1datetimepicker').datetimepicker({
			format: 'yyyy-MM-dd hh:mm:ss',


			});
			</script>

			<?php include 'template/footer.php';?>
			<?php */ ?>
			









 