 <script type="text/javascript">
        function pageLoad() {
            $(document).on("change", 'input[name=RadioButtonList1]', function () {
                $('#Todatetimepicker').data("DateTimePicker").minDate($("#txtdatefrom").val());
                if ($('input[name=RadioButtonList1]:checked').val() == "Date") {
                    var newdate = moment(new Date($("#txtdatefrom").val())).add(30, 'd').format('DD-MMM-YYYY')
                    $('#Todatetimepicker').data("DateTimePicker").maxDate(newdate);
                    $('#Todatetimepicker').data("DateTimePicker").defaultDate(newdate);
                    $("#txtdateto").val(newdate);
                } else {
                    var newdate = moment(new Date()).add(30, 'y').format('DD-MMM-YYYY');
                    $('#Todatetimepicker').data("DateTimePicker").maxDate(newdate);
                }
            });


            $('#fromdatetimepicker').datetimepicker({
                format: 'DD-MMM-YYYY'
            });

            $('#Todatetimepicker').datetimepicker({
                format: 'DD-MMM-YYYY',
                useCurrent: false
            });


            $("#fromdatetimepicker").on("dp.change", function (e) {
                if ($('input[name=RadioButtonList1]:checked').val() == "Date") {
                    $('#Todatetimepicker').data("DateTimePicker").minDate(e.date);
                    var newdate = new Date(moment(e.date).add(30, 'd').format('DD-MMM-YYYY'))
                    $('#Todatetimepicker').data("DateTimePicker").maxDate(newdate);
                    $('#Todatetimepicker').data("DateTimePicker").defaultDate(newdate);
                    $("#txtdateto").val(moment(newdate).format('DD-MMM-YYYY'));
                } else {
                    $('#Todatetimepicker').data("DateTimePicker").minDate(e.date);
                    var newdate = moment(new Date()).add(30, 'y').format('DD-MMM-YYYY');
                    $('#Todatetimepicker').data("DateTimePicker").maxDate(newdate);
                }
            });
            $("#Todatetimepicker").on("dp.change", function (e) {
                //  $('#fromdatetimepicker').data("DateTimePicker").maxDate(e.date);
            });

            $("#Todatetimepicker").on("dp.show", function (e) {
                $(this).data("DateTimePicker").minDate($("#txtdatefrom").val());
                if ($('input[name=RadioButtonList1]:checked').val() == "Date") {
                    var newdate = moment(new Date($("#txtdatefrom").val())).add(30, 'd').format('DD-MMM-YYYY')
                    $('#Todatetimepicker').data("DateTimePicker").maxDate(newdate);
                    $('#Todatetimepicker').data("DateTimePicker").defaultDate(newdate);
                    $("#txtdateto").val(newdate);
                } else {
                    var newdate = moment(new Date()).add(30, 'y').format('DD-MMM-YYYY');
                    $('#Todatetimepicker').data("DateTimePicker").maxDate(newdate);
                }
            });



            $('#Pofromdatetimepicker').datetimepicker({
                format: 'DD-MMM-YYYY'
            });

            $('#PoTodatetimepicker').datetimepicker({
                format: 'DD-MMM-YYYY'
            });


            $('#paymentfromdatetimepicker').datetimepicker({
                format: 'DD-MMM-YYYY'
            });

            $('#paymentTodatetimepicker').datetimepicker({
                format: 'DD-MMM-YYYY'
            });

            $('#MOsReceivedfromdatetimepicker').datetimepicker({
                format: 'DD-MMM-YYYY'
            });

            $('#MOsReceivedtodatetimepicker').datetimepicker({
                format: 'DD-MMM-YYYY'
            });


            $(document).on("change", 'input[name=RadioButtonList2]', function () {
                if ($('input[name=RadioButtonList2]:checked').val() == "Date") {
                    $("#table_datewise").show();
                    $("#table_monthwise").hide();
                } else {
                    $("#table_monthwise").show();
                    $("#table_datewise").hide();
                }
            });

            if ($('input[name=RadioButtonList2]:checked').val() == "Date") {
                $("#table_datewise").show();
                $("#table_monthwise").hide();
            } else {
                $("#table_monthwise").show();
                $("#table_datewise").hide();
            }

            $(document).on("change", 'input[name=RDPayment]', function () {
                if ($('input[name=RDPayment]:checked').val() == "Date") {
                    $("#payment_table_datewise").show();
                    $("#payment_table_monthwise").hide();
                } else {
                    $("#payment_table_monthwise").show();
                    $("#payment_table_datewise").hide();
                }
            });

            if ($('input[name=RDPayment]:checked').val() == "Date") {
                $("#payment_table_datewise").show();
                $("#payment_table_monthwise").hide();
            } else {
                $("#payment_table_monthwise").show();
                $("#payment_table_datewise").hide();
            }


            $(document).on("change", 'input[name=RDMOs]', function () {
                if ($('input[name=RDMOs]:checked').val() == "Date") {
                    $("#moreceived_table_datewise").show();
                    $("#moreceived_table_monthwise").hide();
                } else {
                    $("#moreceived_table_monthwise").show();
                    $("#moreceived_table_datewise").hide();
                }
            });

            if ($('input[name=RDMOs]:checked').val() == "Date") {
                $("#moreceived_table_datewise").show();
                $("#moreceived_table_monthwise").hide();
            } else {
                $("#moreceived_table_monthwise").show();
                $("#moreceived_table_datewise").hide();
            }




            $(document).ready(function () {
                // $(".tab_content").hide();
                //  $(".tab_content:first").show();

                var tabid = $("ul.tabs li.active").attr("rel");
                $("#" + tabid).show();
                /* if in tab mode */
                $("ul.tabs li").click(function () {
                    $(".tab_content").hide();
                    var activeTab = $(this).attr("rel");
                    $("#" + activeTab).fadeIn();

                    $("ul.tabs li").removeClass("active");
                    $(this).addClass("active");

                    $(".tab_drawer_heading").removeClass("d_active");
                    $(".tab_drawer_heading[rel^='" + activeTab + "']").addClass("d_active");

                });

                /* if in drawer mode */
                $(".tab_drawer_heading").click(function () {

                    $(".tab_content").hide();
                    var d_activeTab = $(this).attr("rel");
                    $("#" + d_activeTab).fadeIn();

                    $(".tab_drawer_heading").removeClass("d_active");
                    $(this).addClass("d_active");

                    $("ul.tabs li").removeClass("active");
                    $("ul.tabs li[rel^='" + d_activeTab + "']").addClass("active");
                });

                $('ul.tabs li').last().addClass("tab_last");
            });
        }
    </script>
	
	  <script type="text/javascript">
        var prm = Sys.WebForms.PageRequestManager.getInstance();
        if (prm != null) {
            prm.add_initializeRequest(function (sender, e) {
                if (sender._postBackSettings.panelsToUpdate.join().indexOf("UpdatePanel4") != -1) {

                    $('#form1').validator()(function (e) {
                        if (e.isDefaultPrevented()) {
                            // handle the invalid form...
                            e.set_cancel(true);
                        } else {
                            // everything looks good!
                        }
                    });
                }
            });
        };

    </script>