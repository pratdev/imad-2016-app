<?php 
include 'session.php';
include 'includes/db.php';


?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
      include 'includes/db.php';
		
		$prefix = "";
		$pincode = "";
		$name =  "";
		$number = "";
		$email = "";
		$address =  "";
		$states =  "";
		$stateid = "";
		$cityname = "";
		$SelLocation =  "";
		$package =  "";
		$p_price = "";
		$paymentmethod = "";
		$couriercompany='';
		$bypost='';
		$web_id='';
		$fromdate="";
		$todate="";

		
		?>
		
  <link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel='stylesheet' type='text/css' />

  <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
		
  <link rel="stylesheet" href="css/jquery.datetimepicker.css">
 
  <script src="js/jquery.datetimepicker.js"></script>


	  <script>
		
		$(document).ready(function () {
        $("#datepicker").datetimepicker({
            format: "Y-m-d H:i:s",
            maxDate: 0
        });

        $("#datepicker2").datetimepicker({
            format: "Y-m-d H:i:s",
            maxDate: 0
        });
    });

</script>

 

    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
			
			
			<h1>Delhivery Manifest</h1>
				<br>
				
				
     <div class="col-sm-2">
	  
       <form method="get" action="drecord.php?fromdate=<?php echo $fromdate?>&todate=<?php echo $todate?>">
	   
				<p>Date From:<input type="text" id="datepicker" name="fromdate" value="<?php echo $fromdate?>"><?php echo $fromdate?></input></p>
				<p>Date To:<input type="text" id="datepicker2" name="todate" value="<?php echo $todate?>"><?php echo $todate?></input></p>
				
			  <hr>

			  <input type="submit" id="btnprint" class="btn btn-success" value="GET RECORDS">
	  </form>
	  
	</div>   
	        
	       
	</div>
	
	 </div>
	</div>
	
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>

