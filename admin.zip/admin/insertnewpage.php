<?php 
include 'session_admin.php';
include 'includes/db.php';
if(!isset($_POST['insertnewpage'])){
	$_POST['page_name']="";
	$_POST['file_name']="";
}

if (isset($_POST['insertnewpage'])){
	//getting the text data from the fields
	//$user_name = $_POST['user_name'];
	$page_name = $_POST['page_name'];
	$file_name = $_POST['file_name'];	
	$insert_package = "insert into tbl_page_master(page_name,file_name)values('$page_name','$file_name')";	
	$insert_pack = mysqli_query($con, $insert_package);
	if($insert_pack){
	//echo "<script>alert('You have successfully insert page!')</script>";
   // header("location:insertnewpage.php");
   ?>
   <script type="text/javascript">
alert("You have successfully insert page!");
location="insertnewpage.php";
</script><?php

	                }
	
}

include 'template/header.php';
include 'template/sidebar.php';
?>
	    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">

 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
			<div class="blank-page">				
	        	<p>
<title>INSERT NEW PAGE</title>    
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script> -->
<form action="" method="POST" >
     <table align="center" width="795" height="600" border="2" bgcolor="#187eae">
           <tr align="center">
             <td colspan="7"><h2>ASSIGN RIGHTS</h2></td>
           </tr>
         <tr>
           <td align="left">ENTER PAGENAME:</td>
           <td><input type="text" name="page_name" size="60" placeholder="ENTER PAGENAME" required/></td>
		</tr>
           
         <tr>
           <td align="left"> ENTER FILENAME: </td>
           <td><input type="text" name="file_name" size="60" placeholder="ENTER PAGENAME" required/></td>
         </tr>
      
           <tr align="center">
           <td colspan="7"><input type="submit" name="insertnewpage" value="INSERT NEW PAGE" /></td>
           </tr>        
     </table> 
</form>
   </p>
	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>

