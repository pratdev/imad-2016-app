<?php



include 'includes/db.php';


//$id=$_GET['id'];


if(isset($_POST['webisiteid'])){
	$pid=$_POST['webisiteid'];
	//echo $id;
}
else{
	$pid=$_GET['id'];
}
?>
<table id="example" class="display"  cellspacing="0" width="100%">
 	
 <thead>
	<tr>
	    	    <th></th>
	    
	   
	
			
			
		<!--<th>Admin Response</th>
		
	    <th class="select">Command</th>
		
	    <th class="select">Payment Status</th>-->

   </tr>   
</thead>
 		<tbody>
<?php

$sql="select * from package where p_web_id='$pid'";
$result=$con->query($sql);
$i=0;
while($row=mysqli_fetch_array($result)){
	$p_id=$row['p_id'];
	$p_name=$row['p_name'];
	$p_web_id=$row['p_web_id'];
	$p_price=$row['p_price'];
	$p_status=$row['p_status'];
	$i++;
	
	
	
	
	
	
	
	
	
	



?>

 <tr style=" background-color:<?php echo $bgcolor;?>">
	    
		<td><input type="checkbox" name="pac_coup_id[<?php echo$p_name; ?>]" value="<?php echo $p_id  ?>"  /></td>
		<td><?php echo $p_name     ?> </td>
		
		
<?php  ?>
	 	


	 	<!--<td><a href="edit_order.php?id=<?php// echo $row_pro['id'];?>">Edit</a></td>
		  <td><a href="chek.php?id=<?php// echo $id;?>"><?php //echo "EDIT";?></a></td>
	 	<td><a href="javascript:getConfirmation('<?php //echo $order_id;?>')">Delete</a></td>-->
	 
	 	 </tr>
	
	
<?php  
	  }?>
	
	 </tbody> 
	 
   </table>
   
   


