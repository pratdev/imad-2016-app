<?php 

include 'includes/db.php';
session_start(); 

if(!isset($_SESSION['user_email'])){
	
	echo "<script>window.open('signin.php?not_admin=You are not an Admin!','_self')</script>";
}
else {

?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
?>
	  
		    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				
	        	<p>

<?php 

include ('includes/db.php');

?>


       <title>Add New Package</title>
       
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  
  <link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel='stylesheet' type='text/css' />

	 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">

	<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

	<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>


		  <script>
					$(document).ready(function() {
						$('#example').DataTable();
					} );

	      </script>

<?php 
	
	if(isset($_GET['search'])){
	
	$search_query = $_GET['orderstatus'];
	
	$get_pro = "select * from orderdetail where orderstatus='$search_query'";

	$run_pro = mysqli_query($con, $get_pro); 
	
	while($row_pro=mysqli_fetch_array($run_pro)){
	
		   $order_id = $row_pro['id'];
            $orderstatus = $row_pro['orderstatus'];
			$get_pro = "select gfsaorderdetail.*,package.* from gfsaorderdetail INNER JOIN  package ON gfsaorderdetail.packageid=package.p_id ";

	  //help for above query
	 // select  package.*, websites.web_domain from package INNER JOIN websites ON package.p_web_id=websites.web_id where websites.web_domain='$web_domain' 
	  
	  $run_pro = mysqli_query($con, $get_pro);
	  
	  $i=0;
	  
	  while ($row_pro=mysqli_fetch_array($run_pro))
	  {
			
			$web_domain =  mysqli_real_escape_string($con,$_SERVER['SERVER_NAME']);	
		    
			$id = $row_pro['id'];

			$prefix = $row_pro['prefix'];
			$order_id = $row_pro['id'];
            $orderstatus = $row_pro['orderstatus'];
			
			$pincode = $row_pro['pin'];

			$name =  $row_pro['name'];
			$number = $row_pro['mobile'];
			$email = $row_pro['email'];
			$address = $row_pro['address'];
			$states =  $row_pro['state'];
			$cityname = $row_pro['city'];
			$SelLocation = $row_pro['locality'];
			$package = $row_pro['p_name'];
			$packagecost = $row_pro['p_price'];
			$paymentmethod = $row_pro['paymentmethod']; 
			/*
			if($paymentmethod=="ONLINE")
		  {
			  $packagecost=round($packagecost*.95);
		  }
		  else{
			 $packagecost=$packagecost;
		  }*/

            $OrderDate = $row_pro['OrderDate'];
	

		  // $pcode = $row_pro['PostalCode'];--not here on form i.e run time only
		
			



			$bgcolor="";

			if( $orderstatus=="PENDING" || $orderstatus=="NONE")
		  {
				$bgcolor="#DAFF33";
          }else if($orderstatus=="CONFIRM")
		  {
			   $bgcolor="#5AE012"; 
		  }
		  else if($orderstatus=="CANCEL")
		  {
			  $bgcolor="#FF5833";
		  }

	    $i++;
	
		echo "  <table> <tr>
	    
	 	<td><?php echo $i?></td>
		<td><?php echo $order_id?></td>
		<td><?php echo $web_domain?></td>
		<td><?php echo $orderstatus?></td>
	 	<td><?php echo $pincode?></td>
	 	<td><?php echo $name?></td>
	 	<td><?php echo $number?></td>
	 	<td><?php echo $email?></td>
	 	<td><?php echo $address?></td>
	 	<td><?php echo $states?></td>
		<td><?php echo $cityname?></td>
		<td><?php echo $SelLocation?></td>
		<td><?php echo $package?></td>
        <td><?php echo $packagecost?></td>
		<td><?php echo $paymentmethod?></td>
	    <td><?php echo $OrderDate?></td>
	 	 


	 	 </tr>
	
	
	 <?php } ?></table>
		
		";
	
	}
	}
	?>




	
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>

<?php }?>
