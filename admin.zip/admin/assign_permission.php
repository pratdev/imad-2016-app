<?php 
include 'session.php';

include 'includes/db.php';


?>



<?php 
if (isset($_POST['assignrights'])){	
	//$userid=mysqli_real_escape_string($con,$_POST['user_name']);
	//$id=$_POST['id'];
	$userid=$_POST['user_name'];
$id=$_POST['id'];

$page_id = $_POST['id'];
foreach ($page_id as $id){
	$status=1;
//$sql="select * from tbl_page_permission where page_id='$id' and user_id='$userid'";
/*$result=$con->query($sql);	
if($row=$result->fetch_assoc()){
	
echo"exist";
}	

else{
	echo"notexist";
	
}
	*/
	
	
	
$sql="insert into tbl_page_permission(page_id,user_id,status)values('$id','$userid','$status')";
$result=$con->query($sql);	
//echo $id."<br />";
}
?>
	<script type="text/javascript">
alert("You assigned rights");
location="assign_permission.php";
</script>
<?php

	

	//header("location:assign_permission.php");
}
else{
	$_POST['user_name']=0;
	$_POST['id']=0;
	
	
}
?>

<?php include 'template/header.php';
      include 'template/sidebar.php';
?>
	  
		    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				
	        	<p>

<?php 

include ('includes/db.php');

?>


       <title>ASSIGN RIGHTS</title>
      
 <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script> -->
       
	





<form action="" method="POST" >
     <table align="center" width="795" height="600" border="2" bgcolor="#187eae">

           <tr align="center">
             <td colspan="7"><h2>ASSIGN RIGHTS</h2></td>
           </tr>
		     <tr>
             <td align="left"> USER NAME: </td>
             <td>
             
             <select name="user_name"  required/>
                    <option value=""> USER NAME</option>
					<?php

//class="form-control"
$sql="SELECT * FROM admin";
$result=$con->query($sql);

while($row=mysqli_fetch_array($result)){
	
$user_id=$row['user_id'];
$user_loginname= $row['user_loginname'];

if($row['user_status']!="0"){
 echo"<option value='$user_id'>$user_loginname</option>";
  }   
}?>


                  </select>
             
             </td>
           </tr>
	
	<?php    
	include ('includes/db.php');
	$sql="SELECT * FROM tbl_page_master";
$result=$con->query($sql);

while($row=mysqli_fetch_array($result)){
	$pagename=$row['page_name'];
	//$filename=$row['file_name'];
	$id=$row['id'];

	?>
	
           <tr>
             <td align="left"><?php echo $pagename;   ?>:</td>

             <td>
              <input type="checkbox" name="id[]" id="id" value="<?php echo $id; ?>">
             </td>

			 </tr>
			 
			 

			 
			 
			 
			 
			 
			 
			 
			 
<?php      }   ?>
          
           <tr align="center">
             <td colspan="7"><input type="submit" name="assignrights" value="ASSIGN RIGHTS NOW" /></td>
           </tr>
           
           
           
     </table> 

</form>

<?php //echo $_POST['user_id']; ?>

   </p>
	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>

