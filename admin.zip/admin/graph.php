<?php 
include 'session.php';
include 'includes/db.php';

?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
	  


?>
	  
		 <title>View Graph Genius Admin Panel</title>
		 
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
     
	  <!--  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>-->
	    
		
      <script type="text/javascript" src="https://www.google.com/jsapi"></script>
        
		
		
 
       
 <script type="text/javascript" src="https://www.google.com/jsapi"></script>
        
		
		
 
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
		
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>



	  <script>
             $( function() {
				//$( "#datepicker" ).datepicker();
				$( "#datepicker" ).datepicker({changeMonth:true,changeYear:true,numberOfMonths:[1,1]});
				$( "#datepicker" ).datepicker("option", "dateFormat", "yy-mm-dd");
				  });
			 
			 $( function() {
				//$( "#datepicker2" ).datepicker();
				$( "#datepicker2" ).datepicker({changeMonth:true,changeYear:true,numberOfMonths:[1,1]});
				$( "#datepicker2" ).datepicker("option", "dateFormat", "yy-mm-dd");
			      });
		

	  </script>
	  
	  <script type="text/javascript" src="https://www.google.com/jsapi"></script>
	  
	  
	  
	  
 <script type="text/javascript">
 google.load("visualization", "1", {packages:["corechart"]});
 google.setOnLoadCallback(drawChart);
 function drawChart() 
 
 {

 var data = google.visualization.arrayToDataTable([
 ['orderdate', 'Orders', 'Received','Return','NoStatus'],

 <?php 
    
include 'includes/db.php';	
if(isset($_POST['submit']))
  {
	   
	

	$query = "SELECT count(OrderDate) AS count,COUNT(CASE WHEN rtnrcv='Received' THEN 1 ELSE NULL END) AS Received,COUNT(CASE WHEN rtnrcv='Return' THEN 1 ELSE NULL END) AS 'Return',
		      COUNT(CASE WHEN rtnrcv= '' then 1 ELSE NULL END) as NoStatus,
			  round(((COUNT(CASE WHEN rtnrcv='' THEN 1 ELSE NULL END)/count(OrderDate)) * 100),2)  AS nostat,
			  cast(orderDate as date)  as OrderDate FROM orderdetails where
              orderdetails.web_id LIKE '%" . $_POST['webisiteid'] . "%' AND orderdetails.couriercompany LIKE '%" . $_POST['couriercompany'] . "%' 			 
		      AND	 (OrderDate  BETWEEN CAST('". $_POST['fromdate'] ."' AS DATE) AND CAST('". $_POST['todate'] ."' AS DATE)) GROUP BY CAST( OrderDate as DATE)";
		
		//echo $query;
		/*SELECT count(OrderDate) AS count,COUNT(CASE WHEN rtnrcv='Received' THEN 1 ELSE NULL END) AS Received,COUNT(CASE WHEN rtnrcv='Return' THEN 1 ELSE NULL END) AS 'Return',
		              COUNT(CASE WHEN rtnrcv= '' then 1 ELSE NULL END) as NoStatus,rtnrcvdate FROM orderdetails where rtnrcvdate  BETWEEN '". $_POST['fromdate'] ."' AND '". $_POST['todate']. "' GROUP BY orderdetails.rtnrcvdate ";
					 */
					 
					 
					 // BETWEEN '". $_POST['fromdate'] ."' AND '". $_POST['todate']. "'";
		
		//orderdetails.rtnrcvdate BETWEEN '". $_POST['fromdate'] ."' AND '". $_POST['todate']. "'
		
		//"SELECT count(id) AS count,COUNT(CASE WHEN rtnrcv='Received' THEN 1 ELSE NULL END) AS Received,COUNT(CASE WHEN rtnrcv='Return' THEN 1 ELSE NULL END) AS 'Return'
		    //      ,rtnrcvdate FROM  orderdetails GROUP BY rtnrcvdate";
		
		//SELECT count(id) AS count, rtnrcv 
		    // rtnrcvdate FROM orderdetails GROUP BY rtnrcvdate ";
				//SELECT count(id) AS count, orderstatus FROM orderdetails  GROUP BY orderDate >= '2017-01-30' and orderDate < '2017-03-25'";

					 $exec = mysqli_query($con,$query);
					 
					/*$pro=mysqli_fetch_array($exec); 

					   if(empty($pro["rtnrcvdate"]))
					   {
					   }
					   else
					   {*/
						 while($row = mysqli_fetch_array($exec))
						 {?>

						// echo "['".$row['OrderDate']."',".$row['count'].",".$row['Received'].",".$row['Return'].",".$row['nostat']."],";
						
						  ['<?php echo $row['OrderDate'];?>', <?php echo $row['count'];?>,<?php echo $row['Received'];?>,
						     <?php echo $row['Return'];?>,<?php echo $row['NoStatus'];?>],
					<?php	 }
					  // }
    }
	else{
		$_POST['webisiteid']="";
        $_POST['couriercompany']="";	
        $_POST['fromdate']="";		
		$_POST['todate']="";
	}
 ?>
 ]);

 var options = {
 title: 'Record of all couriers',
 legend:'true',
  seriesType: 'line',
	 series: {0: {type: 'bars',color: '#8ff7f2'},
	           1:{color: 'Green'},
			   2:{color: 'RED'},
			   3:{color: 'Yellow'}
			   }
 
 };

var chart = new google.visualization.ComboChart(document.getElementById('chart_div'));

chart.draw(data, options);

 }
 
 </script>
 
 
 
 <script type="text/javascript">
 google.load("visualization", "1", {packages:["corechart"]});
 google.setOnLoadCallback(drawChart);
 function drawChart() 
 
 {

 var data = google.visualization.arrayToDataTable([
 ['orderdate', 'Orders (%)', 'Received (%)','Return (%)','NoStatus (%)'],

 <?php 
    
include 'includes/db.php';	
if(isset($_POST['submit']))
  {
	   
	

	$query = "SELECT round(((count(OrderDate)/count(OrderDate)) * 100),2)  AS count,
	          COUNT(CASE WHEN rtnrcv='Received' THEN 1 ELSE NULL END) AS Received,COUNT(CASE WHEN rtnrcv='Return' THEN 1 ELSE NULL END) AS 'Return',
		      COUNT(CASE WHEN rtnrcv= '' then 1 ELSE NULL END) as NoStatus,
			  round(((COUNT(CASE WHEN rtnrcv='Received' THEN 1 ELSE NULL END)/count(OrderDate)) * 100),2)  AS Reeceived,
			  round(((COUNT(CASE WHEN rtnrcv='Return' THEN 1 ELSE NULL END)/count(OrderDate)) * 100),2)  AS Reeturn,
			  round(((COUNT(CASE WHEN rtnrcv='' THEN 1 ELSE NULL END)/count(OrderDate)) * 100),2)  AS NoStat,
			  cast(orderDate as date)  as OrderDate FROM orderdetails where
              orderdetails.web_id LIKE '%" . $_POST['webisiteid'] . "%' AND orderdetails.couriercompany LIKE '%" . $_POST['couriercompany'] . "%' 			 
		      AND	 (OrderDate  BETWEEN CAST('". $_POST['fromdate'] ."' AS DATE) AND CAST('". $_POST['todate'] ."' AS DATE)) GROUP BY CAST( OrderDate as DATE)";
		
		//echo $query;
		/*SELECT count(OrderDate) AS count,COUNT(CASE WHEN rtnrcv='Received' THEN 1 ELSE NULL END) AS Received,COUNT(CASE WHEN rtnrcv='Return' THEN 1 ELSE NULL END) AS 'Return',
		              COUNT(CASE WHEN rtnrcv= '' then 1 ELSE NULL END) as NoStatus,rtnrcvdate FROM orderdetails where rtnrcvdate  BETWEEN '". $_POST['fromdate'] ."' AND '". $_POST['todate']. "' GROUP BY orderdetails.rtnrcvdate ";
					 */
					 
					 
					 // BETWEEN '". $_POST['fromdate'] ."' AND '". $_POST['todate']. "'";
		
		//orderdetails.rtnrcvdate BETWEEN '". $_POST['fromdate'] ."' AND '". $_POST['todate']. "'
		
		//"SELECT count(id) AS count,COUNT(CASE WHEN rtnrcv='Received' THEN 1 ELSE NULL END) AS Received,COUNT(CASE WHEN rtnrcv='Return' THEN 1 ELSE NULL END) AS 'Return'
		    //      ,rtnrcvdate FROM  orderdetails GROUP BY rtnrcvdate";
		
		//SELECT count(id) AS count, rtnrcv 
		    // rtnrcvdate FROM orderdetails GROUP BY rtnrcvdate ";
				//SELECT count(id) AS count, orderstatus FROM orderdetails  GROUP BY orderDate >= '2017-01-30' and orderDate < '2017-03-25'";

					 $exec = mysqli_query($con,$query);
					 
					/*$pro=mysqli_fetch_array($exec); 

					   if(empty($pro["rtnrcvdate"]))
					   {
					   }
					   else
					   {*/
						 while($row = mysqli_fetch_array($exec))
						 {?>

						// echo "['".$row['OrderDate']."',".$row['count'].",".$row['Received'].",".$row['Return'].",".$row['nostat']."],";
						
						  ['<?php echo $row['OrderDate'];?>', <?php echo $row['count'];?>   ,<?php echo $row['Reeceived'];?>,
						     <?php echo $row['Reeturn'];?>,<?php echo $row['NoStat'];?>],
					<?php	 }
					  // }
    }
	else{
		$_POST['webisiteid']="";
        $_POST['couriercompany']="";	
        $_POST['fromdate']="";		
		$_POST['todate']="";
	}
 ?>
 ]);

 var options = {
 title: 'Record of all couriers in percentage',
 legend:'true',
  seriesType: 'line',
	 series: {0: {type: 'bars',color: '#8ff7f2'},
	           1:{color: 'Green'},
			   2:{color: 'RED'},
			   3:{color: 'Yellow'}
			   }
 
 };

var chart = new google.visualization.ComboChart(document.getElementById('chart_div2'));

chart.draw(data, options);

 }
 
 </script>
 
 
</head>
<body>
 <h3>Chart</h3>
  
          
		    <form method="post" action="<?php $_SERVER['PHP_SELF']; ?>" >
		   
  From: <input type="text" name="fromdate" id="datepicker" value="<?php echo $_POST['fromdate']?>" required />
				        
				To: <input type="text" name="todate" id="datepicker2" value="<?php echo $_POST['todate']?>"  required /  >
				  
				  <p> WEBSITE NAME:
                <select name="webisiteid" class="form-control">
				         
						 
	  <option value="" <?php echo($_POST['webisiteid']=="" ? "Selected": "");?>  >ALL</option>

				 <?php
							$sql="SELECT * FROM websites ";
							$result=$con->query($sql);

							while($row=mysqli_fetch_array($result)){
							$web_id=$row['web_id'];
							$web_domain= $row['web_domain'];

							echo "<option value='$web_id' ".  ($web_id==$_POST['webisiteid'] ? "Selected": "")  ." >".$web_domain."</option>";
							}
                     ?>
						</select>
						</p>	
                 
				 COURIER COMPANY:
				
				<select name="couriercompany" class="form-control">
				            <option value=""  >ALL</option>
							<option value="POSTOFFICE" <?php echo ($_POST['couriercompany']=="POSTOFFICE" ? "Selected": "");?>   >POSTOFFICE</option>
							<option value="Delhivery" <?php echo ($_POST['couriercompany']=="Delhivery" ? "Selected": "");?>   >Delhivery</option>
						    <option value="fedex" <?php echo ($_POST['couriercompany']=="fedex" ? "Selected": "");?>   >fedex</option>
							<option value="bluedart" <?php echo ($_POST['couriercompany']=="bluedart" ? "Selected": "");?>   >bluedart</option>

						</select>
				
										
				  
			           <input type="submit" class="btn btn-success" name="submit" value="VIEW" />
					   
					   <div id="chart_div"  style='width: 1200px; height: 500px;'></div>
					   <div id="chart_div2"  style='width: 1200px; height: 500px;'></div>
			 </form>
		
			 
			
		
	        
			

	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>
	  <?php ?>