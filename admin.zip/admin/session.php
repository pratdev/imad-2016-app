<?php

@session_start(); 
include'includes/db.php';

if(!isset($_SESSION['user_id'])){
	
	header("location:logout.php?not_admin='You are not an Admin!'");
	//echo "out";
}
else {

if($_SESSION['user_id']=="1"){
	
}
else{
	//$path_parts = pathinfo('/www/htdocs/inc/lib.inc.php');
	//$path_parts['filename']
	if (basename($_SERVER['PHP_SELF'])!='index.php'){
	 $sql="select tbl_page_permission.user_id from tbl_page_permission INNER JOIN  tbl_page_master ON tbl_page_permission.page_id=tbl_page_master.id
					 WHERE tbl_page_permission.user_id= '".$_SESSION['user_id']."'  and tbl_page_master.file_name='".  basename($_SERVER['PHP_SELF']) ."' 
					 AND tbl_page_permission.status=1";
			 $rsmenu=$con->query($sql);
			//echo basename($_SERVER['PHP_SELF']);		
	if(mysqli_num_rows($rsmenu)>0)
	{	}else{
			//session_destroy();
			session_destroy();
			header("location:logout.php?not_admin='You are not an Admin!'");
			//echo "IN";
	}
	}
}}
?>