<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <base href="/">
    <title>Dashboard | Delhivery</title>
    <meta name="description" content="Delhivery - Dashboard">
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <link rel="stylesheet" href="https://cl.delhivery.com/app/vendor.css" />
    <link rel="stylesheet" href="https://cl.delhivery.com/app/app.css" />
	
	<link href="admin/css/print.css" rel="stylesheet" />
	
	
    <!-- freshwidget.css -->
    <!-- <style type="text/css" media="screen, projection">
        @import url(http://assets.freshdesk.com/widget/freshwidget.css);
    </style>  -->
    <!-- freshwidget.css -->
</head>
<body class=''>
    <style>
        *
        {
            font-family: "Open Sans" , "Helvetica Neue" , Helvetica, Arial, sans-serif;
        }
        p
        {
            color: #394263;
            line-height: 1.6;
        }
        table th, table td
        {
            font-size: 11px;
            vertical-align: top;
            position: relative;
            padding-left: 1px;
            padding-right: 1px;
        }
        h1, h2, h3, h4, h5, h6
        {
            color: #808080;
            font-weight: 300;
            margin-bottom: 10px;
            margin-top: 10px;
        }
        td h1
        {
            font-size: 36px;
        }
        td h2
        {
            font-size: 30px;
        }
        td h3
        {
            font-size: 24px;
        }
        td h4
        {
            font-size: 18px;
        }
        td h5
        {
            font-size: 14px;
        }
        td h6
        {
            font-size: 12px;
        }
        b, strong
        {
            font-weight: 600;
        }
        @media print
        {
            table
            {
                page-break-inside: auto;
            }
            tr
            {
                page-break-inside: avoid;
                page-break-after: auto;
            }
        }
    </style>
	<input type="button" class="no-print btn-success" value="Print This Page" onClick="window.print()" />
	<?php 
 include ("includes/db.php");
 		$id = mysqli_real_escape_string($con,$_GET['id']);

  $get_pro = "select orderdetails.*,package.*,states.states from orderdetails INNER JOIN  package ON orderdetails.packageid=package.p_id
                   INNER JOIN states ON states.stateid = orderdetails.state WHERE orderdetails.id in ( ".$id.")";

	  $run_pro = mysqli_query($con, $get_pro);
  while($row_pro=mysqli_fetch_array($run_pro))
	 {
     $prefix=$row_pro['prefix'];
     $OrderDate=$row_pro['OrderDate'];
     $orderid=$row_pro['id'];
     $bypost=$row_pro['bypost'];
     $prefix=$row_pro['prefix'];
     $name=$row_pro['name'];
     $address=$row_pro['address'];
     $city=$row_pro['city'];
     $state=$row_pro['states'];
     $pin=$row_pro['pin'];
     $mobile=$row_pro['mobile'];
     $packagename=$row_pro['p_name'];
     $packageprice=$row_pro['pack_price'];
     $shippingcharge=$row_pro['shippingcharge'];
     $packageprice=$packageprice+$shippingcharge;
	 $trackingcode=$row_pro['trackingcode'];
	 $locality=$row_pro['locality'];
	 $paymentmethod=$row_pro['paymentmethod'];
	 $DestinationServiceArea=$row_pro['DestinationServiceArea'];
	 $DestinationLocation=$row_pro['DestinationLocation'];

//echo $DestinationServiceArea;

?>
	
	
	
    <!-- ngRepeat: package in packages -->
    <table style="width: 345px; margin: 0px auto 15px; background: #fff;" cellpadding="0"
        cellspacing="0" ng-repeat="package in packages" class="ng-scope">
        <tbody>
            <tr>
                <td>
                    <table width="100%" style="border: 1px solid #000000;" cellpadding="5" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="50%" style="border-right: 1px solid #000000; color: #394263; font-size: 11px">
                                    <strong ng-show="!package.cl_logo" class="ng-binding ng-hide">GENIUSSKYSHOP - DFS</strong>
                                </td>
                                <td width="50%" align="center">
                                    <img width="144" style="padding: 5px;" src="https://cl.delhivery.com/assets/images/packing_slip_logo_1.png">
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="100%" style="border-right: 1px solid #000000; border-bottom: 1px solid #000000;
                        border-left: 1px solid #000000;" cellpadding="5" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="50%">
<img style="margin: 10px 2px;" width="144" alt="<?php echo $trackingcode; ?>" src="panel/admin/barcode.php?text=<?php echo $trackingcode; ?>&print=true" >                              
</td>
                                <td width="50%" align="right">
                                    <h5 class="ng-binding" style="width: 100%;">
                                        <?php echo $pin;?></h5>
                                    <span style="position: absolute; bottom: 0; word-wrap: break-word; max-width: 200px;
                                        right: 1px; font-weight: bold; font-size: 24px;" class="ng-binding"><?php echo $DestinationServiceArea."/".$DestinationLocation;?></span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="100%" style="border-right: 1px solid #000000; border-bottom: 1px solid #000000;
                        border-left: 1px solid #000000;" cellpadding="5" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="70%" style="border-right: 1px solid #000000;">
                                    <p style="font-weight: bold; margin: 0">
                                        Shipping Address:</p>
                                    <p style="font-size: 10px; font-weight: bold; margin: 0; font-size: 14px" class="ng-binding">
                                        <?php echo $name;?></p>
                                    <p style="margin: 0; font-size: 9px;">
                                        <b class="ng-binding">Phone:Phone: <?php echo $mobile;?></b></p>
                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                        Landmark - <?php echo $address;?>
                                        <?php echo $locality;?></p>
                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                       <?php echo $city;?> (<?php echo $state;?>)</p>
                                    <p style="margin: 0; font-size: 9px;">
                                        <strong class="ng-binding">PIN: <?php echo $pin;?></strong></p>
                                </td>
                                <td width="30%" align="center" style="vertical-align: middle;">
                                    <h5>
                                        <strong class="ng-binding"><?php 
										if($paymentmethod=='ONLINE')
										{
											echo "PREPAID";
										}
										else
										{
											echo $paymentmethod;
										}
										 ?></strong></h5>
                                    <h4 ng-show="package.pt == 'COD'" class="">
                                        <strong class="ng-binding">₹&nbsp;<?php
										if($paymentmethod=='ONLINE')
										{
											echo "0";
										}
										else
										{
											echo $packageprice;
										}
										
										?></strong></h4>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="100%" style="border-right: 1px solid #000000; border-bottom: 1px solid #000000;
                        border-left: 1px solid #000000;" cellpadding="5" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="60%" style="border-right: 1px solid #000000;">
                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                        Seller: GENIUS SKY SHOP </p>
                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                        Address:  BAIPUR SIKANDRA AGRA UTTAR PRADESH PIN­282007</p>
                                </td>
                                <td width="40%">
                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                        TIN: 09600118851</p>
                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                        CST: 09600118851C</p>
                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                        Invoice No:  <?php echo $prefix."-".$bypost."-".$orderid;?></p>
                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                        Dt. : <?php echo $OrderDate;?></p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="100%" style="border-right: 1px solid #000000; border-bottom: 1px solid #000000;
                        border-left: 1px solid #000000;" cellpadding="0" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="60%" style="border-right: 1px solid #000000;">
                                    <table width="100%" cellpadding="5" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;">
                                                        Product</p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td width="40%">
                                    <table width="100%" cellpadding="5" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td width="50%" align="center" style="border-right: 1px solid #000000;">
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;">
                                                        Price</p>
                                                </td>
                                                <td width="50%" align="center">
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;">
                                                        Total</p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="100%" style="border-right: 1px solid #000000; border-bottom: 1px solid #000000;
                        border-left: 1px solid #000000;" cellpadding="0" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="60%" style="border-right: 1px solid #000000;">
                                    <table width="100%" cellpadding="5" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td style="height: 70px; vertical-align: middle;">
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                                      <?php echo $packagename;?></p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td width="40%">
                                    <table width="100%" cellpadding="5" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td width="50%" align="center" style="border-right: 1px solid #000000; height: 70px;
                                                    vertical-align: middle;">
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                                        ₹&nbsp;<?php echo $packageprice;?></p>
                                                </td>
                                                <td width="50%" align="center" style="height: 70px; vertical-align: middle;">
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                                        ₹&nbsp;<?php echo $packageprice;?></p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="100%" style="border-right: 1px solid #000000; border-bottom: 1px solid #000000;
                        border-left: 1px solid #000000;" cellpadding="0" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="60%" style="border-right: 1px solid #000000;">
                                    <table width="100%" cellpadding="5" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;">
                                                        <strong>Total</strong></p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td width="40%">
                                    <table width="100%" cellpadding="5" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td width="50%" align="center" style="border-right: 1px solid #000000;">
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;">
                                                        <strong class="ng-binding">₹&nbsp;<?php echo $packageprice;?></strong></p>
                                                </td>
                                                <td width="50%" align="center">
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;">
                                                        <strong class="ng-binding">₹&nbsp;<?php echo $packageprice;?></strong></p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="100%" style="border-right: 1px solid #000000; border-bottom: 1px solid #000000;
                        border-left: 1px solid #000000;" cellpadding="5" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="">
<img style="margin: 10px 0px;" alt="<?php

  $get_pr = "insert into invoice(order_id) SELECT * FROM( SELECT $orderid) AS tmp WHERE NOT EXISTS ( SELECT order_id from invoice where order_id='$orderid'
                 ) LIMIT 1";
       
	 
	  $run_pr = mysqli_query($con, $get_pr);
 
	  
	  
	  $get_pri = "Select * from invoice where order_id='$orderid'";

	  $run_pri = mysqli_query($con, $get_pri);
  while($row_pri=mysqli_fetch_array($run_pri))
	  {
	
	$invoice=$row_pri['invoice_no'];
	$prefix=$row_pri['prefix'];
	  
	  echo $prefix."-".$invoice;

	  ?>" src="panel/admin/barcode.php?text=<?php echo $prefix."-".$invoice;}?>&print=true" />
                                </td>
                                <td width="" align="left">
                                    <p style="line-height: 9pt; font-size: 9px; margin: 5px 0 0px;">
                                        <span class="ng-binding">Return Address:  H­43,Laxmi , Nagar,Behind Sikandra, Hospital, Sikandra,</span>
                                        <span ng-show="4" class="ng-binding">- Agra</span> <span ng-show="Utter Pradesh"
                                            class="ng-binding">- Utter Pradesh</span> <span ng-show="282007" class="ng-binding">
                                                - 282007</span></p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
	<?php  } ?>
    <!-- end ngRepeat: package in packages -->
   
	
    <!-- end ngRepeat: package in packages -->
</body>
</html>
