<?php 
include 'session.php';

include 'includes/db.php';

?>

<?php include 'template/header.php';
      include 'template/sidebar.php';
?>
<!DOCTYPE>

<html>
   <head>
       <title>This is Admin Panel</title>
	   
	<link rel="stylesheet" href="styles/style.css" media="all" />
    </head>
<body>
       
	   <div class="main_wrapper">
	   
	   <div id="header"><h2 style="text-align: center; text-color:black;">Welcome <?php echo $_SESSION['user_name'];?></h2></div>
	   
	   
	   <div>

		<h2 style="color:white; text-align:center;"><?php echo @$_GET['logged_in']; ?></h2>

      </div>
      </div>
      
      <?php include 'template/footer.php';?>
<?php ?>


