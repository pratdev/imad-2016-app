<?php 
include 'session.php';

include 'includes/db.php';


?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
?>
	  
		    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				
	        	<p>

<?php 

include ('includes/db.php');

?>


       <title>Add New Category</title>
       
  
       





<form action="" method="post" ">


       <table align="center" width="795" height="600" border="2" bgcolor="#187eae">

           <tr align="center">
             <td colspan="7"><h2>Add New Category Here</h2></td>
           </tr>

           
            <tr>
             <td align="right">Category Title:</td>
             <td><input type="text" name="cat_title" required/> </td>
           </tr>

             <tr>
             <td align="right"> Website Name: </td>
             <td>
             
             <select name="c_web_id" required />
                <option>Select Website</option>
                
                <?php 
                
                $get_cats = "select * from websites";
                
                $run_cats = mysqli_query($con,$get_cats);
                
                   while ($row_cats=mysqli_fetch_array($run_cats)) 
                   {
                	 
                	$web_id  = $row_cats['web_id'];
                	$web_domain = $row_cats['web_domain'];
                
                	echo "<option value='$web_id'>$web_domain</option>";	 
                  }
                   ?>
                
             </select>
             
             </td>
           </tr>
           
           <tr align="center">
             <td colspan="7"><input type="submit" name="add_cat" value="Add Category" /></td>
           </tr>
         
        </table>   

</form>



<?php 
include("includes/db.php"); 

	if(isset($_POST['add_cat'])){
	
	$cat_title = $_POST['cat_title'];
	$web_id = $_POST['c_web_id'];
	
	$insert_cat = "insert into categories (cat_title,c_web_id) values ('$cat_title','$web_id')";

	$run_cat = mysqli_query($con, $insert_cat); 
	
	if($run_cat){
	
	echo "<script>alert('New Category has been added!')</script>";
	echo "<script>window.open('index.php?view_cat','_self')</script>";
	}
	}

?>
          </p>
	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>
