<?php
include 'includes/db.php';
$pincode=282007;
$number=8954638646;
$duplicatevalue=0;
$sql="select * from orderdetails where pin='$pincode' and mobile='$number'";
			$result=$con->query($sql);
			while($row=mysqli_fetch_array($result)){
				$name=$row['name'];
				$duplicatevalue++;
				echo $name;
			}
			echo $duplicatevalue;
			if($duplicatevalue>=2){
				echo"entert";
			}
			?>