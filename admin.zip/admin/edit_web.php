<?php 
include 'session.php';
include 'includes/db.php';


?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
      include 'includes/db.php';
?>

    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				
	        	<p>

<?php 



if(isset($_GET['web_id'])){

	$get_id = $_GET['web_id']; 
	
	$get_pro = "select * from websites where web_id='$get_id'";
	
	$run_pro = mysqli_query($con, $get_pro); 
	
	$i = 0;
	
	$row_pro=mysqli_fetch_array($run_pro);
		
		$web_id = $row_pro['web_id'];
	  	
	  	$web_name = $row_pro['web_name'];
	  	$web_domain = $row_pro['web_domain'];
	  	$web_status = $row_pro['web_status'];
	  	$web_cod = $row_pro['web_cod'];
	  	$web_payment = $row_pro['web_payment'];
	  	$web_discount = $row_pro['web_discount'];
	  	$web_shipping = $row_pro['web_shipping'];
		
		
}
?>
<html>
	<head>
		<title>Update Website Details</title> 
		

	</head>
	
<body bgcolor="skyblue">


	<form action="" method="post" enctype="multipart/form-data"> 
		
		<table align="center" width="795" border="2" bgcolor="#187eae">
			
			<tr align="center">
				<td colspan="7"><h2>Edit & Update Website Details</h2></td>
			</tr>
			
			<tr>
				<td align="right"><b>Website Name:</b></td>
				<td><input type="text" name="web_name" size="60" value="<?php echo $web_name;?>"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>Website Domain:</b></td>
				<td><input type="text" name="web_domain" size="60" readonly value="<?php echo $web_domain;?>"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>Website Status:</b></td>
				<td><input type="radio" name="web_status" value="1" <?php echo ($web_status==1 ? "checked":"");?> />Active<br>
				    <input type="radio" name="web_status" value="0" <?php echo ($web_status==0 ? "checked":"");?> />Inactive</td>
			</tr>
			
			<tr>
				<td align="right"><b>Cash On Delivery:</b></td>
				<td><input type="radio" name="web_cod" value="1" <?php echo ($web_cod==1 ? "checked":"");?> />Yes<br>
				    <input type="radio" name="web_cod" value="0" <?php echo ($web_cod==0 ? "checked":"");?> />No</td>
			</tr>
			
			<tr>
				<td align="right"><b>Online Payment:</b></td>
				<td><input type="radio" name="web_payment" value="1" <?php echo ($web_payment==1 ? "checked":"");?> />Yes<br>
				    <input type="radio" name="web_payment" value="0" <?php echo ($web_payment==0 ? "checked":"");?> />No</td>
			</tr>
			
			<tr>
				<td align="right"><b>Discount Percent:</b></td>
				<td><input type="text" name="web_discount" size="60" value="<?php echo $web_discount;?>"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>Shipping Charges(Free/Paid):</b></td>
				<td><input type="radio" name="web_shipping" value="1" <?php echo ($web_shipping==1 ? "checked":"");?> />FREE<br>
				    <input type="radio" name="web_shipping" value="0" <?php echo ($web_shipping==0 ? "checked":"");?> />Paid
			    </td>
			</tr>
		
			<tr align="center">
				<td colspan="7"><input type="submit" name="update_website" value="Update website details"/></td>
			</tr>
	
		</table>
	
	
	</form>


</body> 
</html>
<?php



	if(isset($_POST['update_website'])){
	
		//getting the text data from the fields
		$update_id = $web_id;
		
		$web_name = $_POST['web_name'];
		$web_domain = $_POST['web_domain'];
		$web_status = $_POST['web_status'];
		$web_cod = $_POST['web_cod'];
		$web_payment = $_POST['web_payment'];
		$web_discount = $_POST['web_discount'];
		$web_shipping = $_POST['web_shipping'];
		
		
		
	
		 $update_web = "update websites set web_name='$web_name',web_status='$web_status',web_cod='$web_cod',web_payment='$web_payment',
		 web_discount='$web_discount', web_shipping='$web_shipping' where web_id='$update_id'";
		 
		 $run_web = mysqli_query($con, $update_web);
		 
		 if($run_web){
		 
		 echo "<script>alert('Website Detail has been updated!')</script>";
		 
		 echo "<script>window.open('view_web.php','_self')</script>";
		 
		 }
		
	}
?>


<?php include 'template/footer.php';?>










