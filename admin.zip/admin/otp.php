<?php 
session_start();

?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Minimal an Admin Panel Category Flat Bootstrap Responsive Website Template | Signin :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<script src="js/jquery.min.js"> </script>
<script src="js/bootstrap.min.js"> </script>
</head>
<body>
	<div class="login">
		<h1><a href="index.php">Genius Import Export </a></h1>
		<div class="login-bottom">
		<h2 style="color:red; text-align:center;"><?php echo @$_GET['not_admin']; ?></h2>

		<h2 style="color:red; text-align:center;"><?php echo @$_GET['logged_out']; ?></h2>
			
			<h2 style="text-align:center;" >Web Master Login</h2>
	         <h3 style="text-align:center;">Admin Login</h3>
	         
			<form method="post" action="otp.php">
			<div class="col-md-6">
				
				<div class="login-mail">
					<input type="password" name="password" placeholder="Password" required="">
					<i class="fa fa-lock"></i>
				</div>
				
			
			</div>
			<div class="col-md-6 login-do">
				<label class="hvr-shutter-in-horizontal login-sub">
					<input type="submit" name="login" onClick=generateOTP() value="Login">
			  </label>
					
			</div>
			
			<div class="clearfix"> </div>
			</form>
		</div>
	</div>
		<!---->
<?php 

include("includes/db.php"); 





session_set_cookie_params(360);











function generateOTP($length = 6, $chars = '1234567890')
{
	$chars_length = (strlen($chars) - 1);
	$string = $chars{rand(0, $chars_length)};
	for ($i = 1; $i < $length; $i = strlen($string))
	{
		$r = $chars{rand(0, $chars_length)};
		if ($r != $string{$i - 1}) $string .=  $r;
	}
	return $string;
}



// Account details
$username = urlencode('tomwarne115@gmail.com');
$hash = urlencode('7Fok6gPjqoA-vo8T36MkAVdib4COP7YTGyNoRG3IHf');

// Message details
$numbers = urlencode(+918954638646);
$sender = urlencode('DEGNYT');
$message = rawurlencode(' is One Time Password for username. This OTP is valid for 6 minutes.OTP generated on: date&time');

// Prepare data for POST request
$data = 'username=' . $username . '&hash=' . $hash . '&numbers=' . $numbers . "&sender=" . $sender . "&message=" . $message;

// Send the GET request with cURL
$ch = curl_init('http://api.textlocal.in/send/?' . $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

// Process your response here
echo $response;




		if ($_SESSION['login']==$ozotp){
					echo('<html>
							<body><h2>You\'ve been successfully verified your One-Time Password</h2></body>
							</html>');
				}
				 
				else { echo('<html>
						<body><h2>Wrong Password!</h2></body>
						</html>');
				}


?>


<?php  
include'template/footer.php';
?>