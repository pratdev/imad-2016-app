<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Order - Genius Import Export</title>

<!-- Bootstrap -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/mycss.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/print.css" media="print" />

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
   
</head>

<body>
	<input type="button" class="no-print btn-success" value="Print This Page" onClick="window.print()" />

<?php 
 include ("includes/db.php");
 		$id = mysqli_real_escape_string($con,$_GET['id']);

  //$get_pro = "select orderdetails.*,package.*,states.states from orderdetails INNER JOIN  package ON orderdetails.packageid=package.p_id
          //       INNER JOIN states ON states.stateid = orderdetails.state WHERE orderdetails.id= '".$id."'";
			   
				   
				   $get_pro = "select orderdetails.*,package.*,states.states,categories.cat_title from orderdetails INNER JOIN  package ON orderdetails.packageid=package.p_id
                 INNER JOIN states ON states.stateid = orderdetails.state 
				   LEFT OUTER JOIN categories ON categories.cat_id = orderdetails.p_cat_id WHERE orderdetails.id in ( ".$id.")";

	  $run_pro = mysqli_query($con, $get_pro);
  while($row_pro=mysqli_fetch_array($run_pro))
	  {
	$orderid=$row_pro['id'];	  
	$prefix=$row_pro['prefix'];
	$OrderDate=$row_pro['OrderDate'];
	$bypost=$row_pro['bypost'];
	$prefix=$row_pro['prefix'];
	$name=$row_pro['name'];
	$address=$row_pro['address'];
	$city=$row_pro['city'];
	$state=$row_pro['states'];
	$pin=$row_pro['pin'];
	$mobile=$row_pro['mobile'];
	$packagename=$row_pro['p_name'];
	$packageprice=$row_pro['pack_price'];
	$shippingcharge=$row_pro['shippingcharge'];
	$packageprice=$packageprice+$shippingcharge;
	$trackingcode=$row_pro['trackingcode'];
	$locality=$row_pro['locality'];
	$paymentmethod=$row_pro['paymentmethod'];
	$DestinationServiceArea=$row_pro['DestinationServiceArea'];
	$DestinationLocation=$row_pro['DestinationLocation'];
	$cat_title=$row_pro['cat_title'];
	  


//echo $trackingcode;


?>




<div class="container">
<div class="main-layout">
<div style="overflow-x:auto;">
  <table width="100%">
    
    <tr>
      <td class="company-name-order2 text-center">GENIUSSKYSHOP-DFS</td>
      <td  class="company-name1-order2 text-center">BLUE DART</td>
      
    </tr>
    
<!-- section2 -->     
<tr>
<td class="border-right-none"><!----------Place Bar Code Here-----------------------> <img alt="<?php echo $trackingcode; ?>" src="barcode.php?text=<?php echo $trackingcode; ?>&print=true" /></td>
      <td class="border-left-none ">
      <div class="dartcod">Dart Apex (<?php 
						if($paymentmethod=='ONLINE')
										{
											echo "PREPAID";
										}
										else
										{
											echo $paymentmethod;
										}
	  ?>)</div>
      <div class="awb"><strong>awb no#</strong> <?php echo $trackingcode; ?></div>
      <div class="awb">ActWgt: 0.3Kg</div>
      <div class="pack-dimnsion-order2">Packing Dimension : 15x10x8 (CM)</div>
      </td>
</tr>
<!-- section2 ends -->     
<!-- section3 -->     
<tr>
<td>
  
<div class="ship-text-order2">
<h1>Shipping Address:</h1>
<div class="ship-text-username-order2"><?php echo $name;?></div>
<div class="ship-text-phone-order2">Phone: <?php echo $mobile;?></div>

<div class="ship-text-address-order2">Landmark -<?php echo $locality;?>,
<br><?php echo $address;?>
<br><?php echo $city;?>
<br><?php echo $state;?>,
</div>

<div>Designation: <span class="designation-text-order2"><?php echo $DestinationServiceArea;?>/<?php echo $DestinationLocation;?></span></div>
<div>Pin Code: <?php echo $pin;?> <span class="india-text-order2">India</span></div>
<div></div>


</div>




 </td>
<td class="vertical-align-order2">
<div class="cod-order2"><?php 
						if($paymentmethod=='ONLINE')
										{
											echo "PREPAID";
										}
										else
										{
											echo $paymentmethod;
										}
?></div>
<div class="cod-order2">collect :</div>
<div class="price-order2"><strong>Rs</strong>  <?php 
					if($paymentmethod=='ONLINE')
										{
											echo "0";
										}
										else
										{
											echo $packageprice;
										}
?></div></td>
</tr>
<!-- section3 ends -->

<!-- section4 starts-->   
<tr>
    <td>
    
<div class="seller-text-order2">
<div class="seller-text-heading-order2">Seller : GENIUSSKYSHOP</div>
<div>Address :  BAIPUR SIKANDRA AGRA UTTAR PRADESH
<br>
PIN-282007</div>
</div></td>

    <td class="invoice-details-order2">invoice no : <?php echo $prefix."-".$bypost."-".$orderid;?><br>
    invoice date :<?php echo $OrderDate;?><br>
    tin no : 09600118851<br>
    cst no : 09600118851C</td>
    
    
    </tr>
    
<!-- section4 ends--> 




<!-- section5 starts-->   
<tr>
    <td class="no-padding">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td class="border-right product-heading-order2" width="26%">Product</td>
      <td class="no-border product-heading-order2">Description</td>
    </tr>
  </tbody>
</table>

</td>
    <td class="no-padding">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      
      <td class="border-right product-heading-order2 text-center" width="49%">Price</td>
      <td class="no-border product-heading-order2 text-center">Total</td>
    </tr>
  </tbody>
</table>

    
    </td>
    
    
    </tr>
    
<!-- section5 ends-->   

<!-- section6 starts-->   
<tr>
    <td class="no-padding">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td class="border-right "><?php echo $cat_title;?></td>
      <td class="no-border"><?php echo $packagename;?> (Healthcare)</td>
    </tr>
  </tbody>
</table>
    

</td>
    <td class="no-padding">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td class="border-right text-center"><?php echo $packageprice;?></td>
      <td class="no-border text-center"><?php echo $packageprice;?></td>
    </tr>
  </tbody>
</table>

    
    </td>
    
    
    </tr>
    
<!-- section6 ends--> 

<!-- section7 starts-->   
<tr>
    <td class="text-center product-finaltotal-order2 border-right-none">
Total
</td>
    <td class=" product-heading-order2 text-center border-left-none"><strong>Rs</strong> <?php echo $packageprice;?></td>
    </tr>
    <!-- section7 ends--> 
    
    <!-- section8 starts-->   
<tr>
    <td class="text-center border-right-none">
<!----------Place Bar Code Here-----------------------><span class="bottom-text-order2">Return Address :  H­43,Laxmi , Nagar,Behind Sikandra, Hospital, Sikandra,Agra ­ Agra ­ Uttar Pradesh ­ 282007</span>
</td>
    <td class=" border-left-none"></td>
    </tr>
    <!-- section8 ends-->    
</table>
</div>
</div>
</div>
<?php  } ?>




<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.2.min.js"></script>

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.js"></script>
</body>
</html>
