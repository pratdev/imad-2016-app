<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>VPP - Genius Import Export</title>

<!-- Bootstrap -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/mycss.css" rel="stylesheet">
 <link rel="stylesheet" type="text/css" href="css/print.css" media="print" />

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
   
</head>

<body >
<input type="button" class="no-print btn-success" value="Print This Page" onClick="window.print()" />
<div class="container">

<div class="page">
	<div class="subpage">
<?php 
 include ("includes/db.php");
 		$id = mysqli_real_escape_string($con,$_GET['id']);

  $get_pro = "select orderdetails.*,package.*,states.states from orderdetails INNER JOIN  package ON orderdetails.packageid=package.p_id
                   INNER JOIN states ON states.stateid = orderdetails.state WHERE orderdetails.id in ( ".$id.")";

	  $run_pro = mysqli_query($con, $get_pro);
	  $i=0;
  while($row_pro=mysqli_fetch_array($run_pro))
	  {
		$orderid=$row_pro['id'];	
		$prefix=$row_pro['prefix'];
		$OrderDate=$row_pro['OrderDate'];
		$bypost=$row_pro['bypost'];
		$prefix=$row_pro['prefix'];
		$name=$row_pro['name'];
		$address=$row_pro['address'];
		$city=$row_pro['city'];
		$state=$row_pro['states'];
		$pin=$row_pro['pin'];
		$mobile=$row_pro['mobile'];
		$packagename=$row_pro['p_name'];
		$packageprice=$row_pro['pack_price'];
		
		$packagepocharge=$row_pro['p_pocharge'];
		
		$shippingcharge=$row_pro['shippingcharge'];
		$packageprice=$packageprice;
		$trackingcode=$row_pro['trackingcode'];
		$locality=$row_pro['locality'];
		$paymentmethod=$row_pro['paymentmethod'];
		$DestinationServiceArea=$row_pro['DestinationServiceArea'];
		$DestinationLocation=$row_pro['DestinationLocation'];
        $packagename=$row_pro['p_name'];
	  


//echo $DestinationServiceArea;


if ($i%3==0 && $i>0)
{
?>
	</div>
</div>

<div class="page">
	<div class="subpage1">

	
<?php  } ?>	

<div class="main-layout-vpp">
<div class="heading-page-vpp"> 
<div class="row">
<div class="col-xs-6"><img  src="barcode.php?size=40&text=<?php echo $prefix."-".$bypost."-".$orderid;?>&print=true" /></div> 
 <div class="col-xs-6">         <?php        if($paymentmethod=="COD"){?>
                                                V.P.P Rs <?php 
													
														echo $packageprice+$packagepocharge;
													
										?>/- only (INSURED)<?php }else{
														echo "SPEEDPOST";
													}	?></div></div></div>
<div class="date-back">
<div class="row">
<div class="col-xs-6"><div class="to-vpp">TO</div></div>
<div class="col-xs-6"><div class="date-vpp">Date: <?php echo  $_GET['prntdate'] ?></div></div>

</div>
</div>

<div class="address-vpp">
<div class="row">
<div class="col-xs-6">
<div>
<?php echo $name;?>  
<br><?php echo $address;?>,
<?php echo $locality;?>, <?php echo $city;?>,<?php echo $state;?>.
<br><span>Pin -<?php echo $pin;?></span>   Ph - <?php echo $mobile;?>
</div>
</div>
<div class="col-xs-6">
<div align="center" >
<img  src="barcode.php?size=40&text=<?php echo $trackingcode;?>&print=true" />
</div>
</div>
</div>
</div>
<div class="order-detail-vpp">
<div class="row">
<div class="col-xs-4">Order No.: <?php echo $prefix."-".$bypost."-".$orderid;?></div>
<div class="col-xs-4">Product Name:  <?php echo $packagename;?></div>
<div class="col-xs-4">Product Price:  Rs<?php echo $packageprice+$packagepocharge;?>/- only</div>
</div>
</div>
<div class="company-name-vpp">= Genius Import Export =</div>
<div align="center" class="company-address-vpp"> Shop no-6, Kailash Turn Sikandra Agra,­ Uttar Pradesh  Pin-282007, Ph.: 09758526055, 9897304484</div>
</div>
<br>
<br>
<?php   $i++; } ?>

	</div>
</div>
</div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.2.min.js"></script>

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.js"></script>

</body>
</html>
