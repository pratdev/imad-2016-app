<?php 
include 'session.php';

include 'includes/db.php';
	
	
	
	

?>
<?php include 'template/header.php';
     
?>
	<title>View User Details | Genius Admin Panel</title>
	  
  <!-- 
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
--> 
<link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel='stylesheet' type='text/css' />

<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>


  <script>
			$(document).ready(function() {
                $('#example').DataTable();
            } );

  </script>
 	 
 	 
 	 <?php  include 'template/sidebar.php';?>
 	 
 	  <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 	<div class="blank">
 	
 	

  <h2>View All User Details Here</h2>
  <div style="overflow-x:auto;">
  <table id="example" class="display" cellspacing="0" width="100%">
 	
 <thead>
	<tr>
		<th>S.N</th>
		<th>Login Name</th>
		<th>Full Name</th>
		<th>Password</th>
		<th>Email</th>
		<th>Mobile No.</th>
		<th>Address</th>
		<th>User Status</th>
		<th>Edit</th>
	</tr>
 </thead>
 		<tbody>
	<?php 
	  include ("includes/db.php");
	  
	  $get_pro = "select * from admin where user_id!=1";
	  
	  $run_pro = mysqli_query($con, $get_pro);
	  
	  $i=0;
	  
	  while ($row_pro=mysqli_fetch_array($run_pro))
	  {
	  	$user_id = $row_pro['user_id'];
	  	
	  	$user_lname = $row_pro['user_loginname'];
	  	$user_fname = $row_pro['user_fullname'];
	  	$user_pass = $row_pro['user_pass'];
	  	$user_email = $row_pro['user_email'];
	  	$user_mob = $row_pro['user_mobile'];
	  	$user_add = $row_pro['user_address'];
	  	$user_status = $row_pro['user_status'];
	  	
	    $i++;
	?>
	
	 <tr>
	 
	 	<td><?php echo $i?></td>
	 	<td><?php echo $user_lname?></td>
	 	<td><?php echo $user_fname?></td>
	 	<td><?php echo $user_pass?></td>
	 	<td><?php echo $user_email?></td>
	 	<td><?php echo $user_mob?></td>
	 	<td><?php echo $user_add?></td>
	 	<td><?php echo ($user_status==1 ? "Active" : "Inactive")?></td>
	 	
	 	<td><a href="edit_user.php?user_id=<?php echo $row_pro['user_id'];?>">Edit</a></td>
	 
	 	 </tr>
	
	
	 <?php } ?>
	 
	 </tbody> 
	 
   </table>
</div>
       </div>
       
       <script type="text/javascript">
         <!--
            function getConfirmation(user_id){
               var retVal = confirm("Do you want to continue ?");
               if( retVal == true ){
                 window.location.href  = "delete_user.php?delete_user=" +user_id;
               }
               else{
                 // document.write ("User does not want to continue!");
                  return false;
               }
            }
         //-->
      </script>
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>
