<?php 
include 'session.php';

include 'includes/db.php';

	
	
	
	
	?>
		<?php 

include ('includes/db.php');

$user_lname = "";
$user_fname =  "";
$user_pass = "";
$user_email =  "";
$user_mob =  "";
$user_add = "";
$user_status =  "";

?>

<?php 

if (isset($_POST['add_user'])){
	
	//getting the text data from the fields
	//$id=$_POST['id'];
//echo $id;
$arraypage = $_POST['test'];
$newarraypage = $_POST['testu'];

 // echo var_dump($arraypage);
 // echo"<br>";
 // echo var_dump($newarraypage);

	
	
	$user_lname = mysqli_real_escape_string($con,$_POST['user_loginname']);
	$user_fname = mysqli_real_escape_string($con,$_POST['user_fullname']);
	$user_pass = mysqli_real_escape_string($con,$_POST['user_pass']);
	$user_email = mysqli_real_escape_string($con,$_POST['user_email']);
	$user_mob = mysqli_real_escape_string($con,$_POST['user_mobile	']);
	$user_add = mysqli_real_escape_string($con,$_POST['user_address']);
	$user_status = mysqli_real_escape_string($con,$_POST['user_status']);
	$check=mysqli_query($con,"select * from admin where user_loginname='$user_lname'");	
	$checkrows=mysqli_num_rows($check);

	if($checkrows>0) {
		
		echo "<h1 style='color:red; text-align:center;'>User Already Exists</h1>";
		
	} else {
	
	
	$insert_user = "insert into admin (user_loginname,user_fullname,user_pass,user_email,user_mobile,user_address,user_status) values
	('$user_lname','$user_fname','$user_pass','$user_email','$user_mob','$user_add','$user_status')";
	
	$insert_u = mysqli_query($con, $insert_user);
	
	if($insert_u){
		$sql="";
		
		//mysqli_insert_id($conn)
		$userid = mysqli_insert_id($con);
		
		
		
		$userid = mysqli_insert_id($con);
		//$arraypage = $_POST['test'];
		
		foreach($arraypage as $key => $value)
		{  
		 // echo $key.' - '. $value . '<br />';
			
			 $sql= $sql . " insert into tbl_page_permission(page_id,user_id,status) values('$key','$userid','$value'); ";		
		}
		// echo $sql;
			
		//$userid = mysqli_insert_id($con);
		$newarraypage = $_POST['testu'];


		foreach($newarraypage as $newkey => $newvalue)
		{ 
			$sql= $sql . " insert into user_web_permission(web_user_id,user_id,web_page_status) values('$newkey','$userid','$newvalue'); ";		
		}
		
		
		if ($sql!="")
		{
			$result= mysqli_multi_query($con, $sql);
			//$result=$con->query($sql);
		}
		
		//echo "<script>alert('User has been added!')</script>";
		//echo "<script>window.open('view_user.php','_self')</script>";
		header('location:view_user.php');
	}
	
	}
}


?>
	
	
	
	


<?php include 'template/header.php';
      include 'template/sidebar.php';
?>
	  
		    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				
	        	<p>
	        	
	        
			
			
			
			
			
			
			
			
                    
                    <form action="add_user.php" method="post" enctype="multipart/form-data">

     <table align="center" width="795" height="600" border="2" bgcolor="#187eae">

           <tr align="center">
             <td colspan="7"><h2>Add New User Here</h2></td>
           </tr>

           <tr>
             <td align="right">User Login Name:</td>
             <td><input type="text" name="user_loginname" size="60" value="<?php echo $user_lname;?>" required/></td>
           </tr>
           
           <tr>
             <td align="right">User Full Name:</td>
             <td><input type="text" name="user_fullname" value="<?php echo $user_fname;?>" size="60" required/></td>
           </tr>
           
           <tr>
             <td align="right">User Password:</td>
             <td><input type="text" name="user_pass" value="<?php echo $user_pass;?>" size="60" required/></td>
           </tr>
           
           <tr>
             <td align="right">User Email:</td>
             <td><input type="email" name="user_email" value="<?php echo $user_email;?>" size="60" required/></td>
           </tr>
           
           <tr>
             <td align="right">User Mobile:</td>
             <td><input type="text" name="user_mobile	" size="60" value="<?php echo $user_mob;?>" required/></td>
           </tr>
           
           <tr>
             <td align="right">User Address:</td>
             <td><textarea name="user_address" cols="20" rows="5" /><?php echo $user_add;?></textarea></td>
           </tr>
           
		  
		   
		   
           <tr>
             <td align="right">User Status:</td>
             <td>
             
             <input type="radio" name="user_status" value="1" <?php echo ($user_status==1 ? "checked":"");?>>Active<br>
  		     <input type="radio" name="user_status" value="0" <?php echo ($user_status==0 ? "checked":"");?>>Inactive<br>
             </td>
           </tr>
           
		   
		   
		    <tr align="center">
				<td colspan="7"><strong> User Website Permission</strong></td>
			</tr>
		   </tr>
		   <?php
		   $sql="select * from websites";
		   
		 //  $result=$con->query($sql);
		 $result= mysqli_query($con, $sql);
           while($row=mysqli_fetch_array($result)){
		   $web_name =$row['web_name'];
           $web_id =$row['web_id'];

           
		   
		   ?>
		   
		   
		   
		   
		   <tr>
        <td align="left"><?php echo $web_name; ?>: </td>
        <td>
        <input type="radio" name="testu[<?php echo$web_id; ?>]" value="1" required/>Active<br>
  		<input type="radio" name="testu[<?php echo$web_id; ?>]" value="0" checked required/>Inactive<br>
        </td>
    </tr>
		   
		   <?php  } ?> 
		   
		   
			<tr align="center">
				<td colspan="7"><strong> Page permission</strong></td>
			</tr>
		
		   
		   <?php    

	$sql="SELECT main_menu_master.menu_name , tbl_page_master.* FROM tbl_page_master inner JOIN main_menu_master ON main_menu_master.menu_id=tbl_page_master.menu_id
	 order by main_menu_master.menu_id ;";
	
	//$result=$con->query($sql);
			 $result= mysqli_query($con, $sql);

$menu_id ='';
$oldmenu_id='';
while($row=mysqli_fetch_array($result)){
	$pagename=$row['page_name'];
	//$filename=$row['file_name'];
	$id=$row['id'];
$menu_id =$row['menu_id'];
	if ($menu_id!=$oldmenu_id)
	{
		 $oldmenu_id =$row['menu_id'];
	?>
	</tr>
		<tr align="center">
		<td colspan="7"><?php echo $row['menu_name']; ?></td>
	</tr>
	<?php }
		if ($oldmenu_id=='')
		{
			 $oldmenu_id =$row['menu_id'];
		}
	?>
	
	<tr>
        <td align="left"><?php echo $pagename; ?>: </td>
        <td>
        <input type="radio" name="test[<?php echo$id; ?>]" value="1" required/>Active<br>
  		<input type="radio" name="test[<?php echo$id; ?>]" value="0" checked required/>Inactive<br>
        </td>
    </tr>
	 
<?php   }   ?>
		   
		   
		   
		   
           
           
           
           <tr align="center">
             <td colspan="7"><input type="submit" name="add_user" value="Add User Now" /></td>
           </tr>
           
           
           
     </table> 

</form>
	        		
	            </p>
	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>
