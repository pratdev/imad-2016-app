<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Invoice - Genius Import Export</title>

<!-- Bootstrap -->
<link href="css/bootstrap.css"  rel="stylesheet" type="text/css">
<link href="css/mycss.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" type="text/css" href="css/print.css" media="print" />


<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
   
</head>

<body style="font-size: 25px;">
<input type="button" class="no-print btn-success" value="Print This Page" onClick="window.print()" />
<?php 
 include ("includes/db.php");
 		$id = mysqli_real_escape_string($con,$_GET['id']);

  $get_pro = "select orderdetails.*,package.*,states.states from orderdetails INNER JOIN  package ON orderdetails.packageid=package.p_id
                   INNER JOIN states ON states.stateid = orderdetails.state WHERE orderdetails.id in ( ".$id.")";

	  $run_pro = mysqli_query($con, $get_pro);
  while($row_pro=mysqli_fetch_array($run_pro))
	  {
	$orderid=$row_pro['id'];	  
	$prefix=$row_pro['prefix'];
	$OrderDate=$row_pro['OrderDate'];
	$bypost=$row_pro['bypost'];
	$prefix=$row_pro['prefix'];
	$name=$row_pro['name'];
	$address=$row_pro['address'];
	$city=$row_pro['city'];
	$state=$row_pro['states'];
	$pin=$row_pro['pin'];
	$mobile=$row_pro['mobile'];
	$packagename=$row_pro['p_name'];
	$packageprice=$row_pro['pack_price'];
	$shippingcharge=$row_pro['shippingcharge'];
	$packageprice=$packageprice+$shippingcharge;
	$trackingcode=$row_pro['trackingcode'];
	$locality=$row_pro['locality'];
	  


//echo $_POST['packageprice'];


?>

	

<div class="container">


    <div class="page">
        <div class="subpage">

<div class="heading-page text-center">invoice</div>
<div class="row">
<div class="col-xs-6">
<div class="company-name-invoice">GENIUS IMPORT EXPORT
<br>H-53, Triveni Nagar Rangoli Colony Nh-2 Sikandra
<br>Agra, Uttar Pradesh PIN-282007</div></div>
<div class="col-xs-6" >
<div class="top-details-invoice">

<span class="top-details-invoice-padding"><img  width="215" height="55" alt="<?php echo $prefix."-".$bypost."-".$orderid;?>" src="barcode.php?text=<?php echo $prefix."-".$bypost."-".$orderid;?>&print=false" /></span>
<h4 align="center"> <b><?php echo $prefix."-".$bypost."-".$orderid;?></b></h4>
<br>

<span><strong>invoice #</strong></span><span class="top-details-invoice-padding"><?php echo $prefix."-".$bypost."-".$orderid;?></span><br>
<span><strong>date</strong></span><span class="top-details-invoice-padding"><?php echo $_GET['prntdate'];?></span><br>
<span><strong>tin no.</strong></span><span class="top-details-invoice-padding">09600119311</span><br>
</div>
</div>
</div>
<div class="row">
<div class="col-xs-7"></div>
<div class="col-xs-5"><span class="awb-invoice">AWB no:</span><span class="awb-invoice1"><?php echo $trackingcode; ?></span></div>
</div>

<div class="row">
<div class="col-xs-7">
<div class="billingdetail-invoice">Billing Detail</div>
<div><?php echo $name;?></div>
</div>
<div class="col-xs-5">
<div class="billingdetail-invoice">shipping to-</div>
<div><?php echo $name;?></div>
</div>
</div>

<div class="row">
<div class="col-xs-6">
<div class="address-text-invoice">
Landmark-<?php echo$address;?>
<br><?php echo$locality;?>
<br><?php echo $city;?>
<br><?php echo $state;?></div>

<div class="pin-invoice">Pin- <?php echo $pin;?> </div>

</div>
<div class="col-xs-6">
<div class="address-text-invoice1">Landmark - <?php echo $address;?>
<br><?php echo$locality;?>

<br><?php echo $city;?> 
<br><?php echo $state;?></div>
<div class="phone-invoice">Ph- <?php echo $mobile;?> </div>

</div>
</div>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr class="headings-invoice">
      <td class="text-center">S.NO.</td>
      <td class="text-center" width="52%">Description</td>
      <td class="text-center">Unit Price</td>
      <td class="text-center" width="13%">Total</td>
    </tr>
    <tr style="height:230px; vertical-align:top;">
      <td>1</td>
      <td><?php echo $packagename;?></td>
      <td  class="no-border text-right"><?php echo $packageprice;?></td>
      <td class="text-right"><?php echo $packageprice;?></td>
    </tr>
    <tr>
      <td class="no-border">&nbsp;</td>
      <td class="no-border">&nbsp;</td>
      <td class="border-top everything-invoice">Everything included in this cost</td>
      <td class="text-right"><?php echo $packageprice;?></td>
    </tr>
    <tr>
      <td class="no-border">&nbsp;</td>
      <td class="no-border">&nbsp;</td>
      <td class="no-border text-right everything-invoice">Total Due</td>
      <td><?php echo $packageprice;?></td>
    </tr>
  </tbody>
</table>

<div class="footer-text">
Make all cheques payable to
<br>If you have any questions concerning this invoice, <strong>E-mail - okaindia@gmail.com</strong></div>
<div align="center"><!----------Place for Bar Code Here-----------------------></div>
</div>    
    </div>

</div>






<?php  } ?>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.2.min.js"></script>

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.js"></script>
</body>
</html>


