<?php 
include 'session.php';
include 'includes/db.php';

?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
?>
	  
		    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				
	        	<p>
	        	
	        			<?php 

include ('includes/db.php');


$website_name = "";
$website_domain = "";
$website_status = "";
$website_cod = "";
$website_payment = "";
$website_discount = "";
$website_shipping = "";


?>

<?php 

if (isset($_POST['add_web'])){
	
	//getting the text data from the fields
	//$website_id = $_POST['web_id'];
	
	$website_name = $_POST['web_name'];
	$website_domain = $_POST['web_domain'];
	$website_status = $_POST['web_status'];
	$website_cod = $_POST['web_cod'];
	$website_payment = $_POST['web_payment'];
	$website_discount = $_POST['web_discount'];
	$website_shipping = $_POST['web_shipping'];
	
	$check=mysqli_query($con,"select * from websites where web_domain='$website_domain'");
	
	$checkrows=mysqli_num_rows($check);
	
	if($checkrows>0) {
	
		echo "<h1 style='color:red; text-align:center;'>Website Already Exists</h1>";
	
	} else {
	
	
	$insert_web = "insert into websites (web_name,web_domain,web_status,web_cod,web_payment,web_discount,web_shipping) values
	              ('$website_name','$website_domain','$website_status','$website_cod','$website_payment','$website_discount','$website_shipping')";
	
	$insert_w = mysqli_query($con, $insert_web);
	
	if($insert_w){
		echo "<script>alert('Website details has been added!')</script>";
		echo "<script>window.open('add_web.php','_self')</script>";
	}
	}
}


?>


<form action="add_web.php" method="post" enctype="multipart/form-data">

     <table align="center" width="795" height="600" border="2" bgcolor="#187eae">

           <tr align="center">
             <td colspan="7"><h2>Add Website Details Here</h2></td>
           </tr>

           <tr>
             <td align="right">Website Name:</td>
             <td><input type="text" name="web_name" size="60" value="<?php echo $website_name;?>"required/></td>
           </tr>
           
           <tr>
             <td align="right">Website Domain Name:</td>
             <td><input type="text" name="web_domain" size="60" value="<?php echo $website_domain;?>" required/></td>
           </tr>
           
           <tr>
             <td align="right">Website Status:</td>
             <td><input type="radio" name="web_status" value="1" <?php echo ($website_status==1 ? "checked":"");?> >Active<br>
  		         <input type="radio" name="web_status" value="0" <?php echo ($website_status==0 ? "checked":"");?> >Passive<br></td>
           </tr>
           
           <tr>
             <td align="right">Cash On Delivery:</td>
             <td><input type="radio" name="web_cod" value="1" <?php echo ($website_cod==1 ? "checked":"");?> >Yes<br>
  		         <input type="radio" name="web_cod" value="0" <?php echo ($website_cod==0 ? "checked":"");?> >No<br></td>
           </tr>
           
           <tr>
             <td align="right">Online Payment:</td>
             <td><input type="radio" name="web_payment" value="1" <?php echo ($website_payment==1 ? "checked":"");?> >Yes<br>
  		         <input type="radio" name="web_payment" value="0" <?php echo ($website_payment==0 ? "checked":"");?> >No<br></td>
           </tr>
           
           <tr>
             <td align="right">Discount:</td>
             <td><input type="text" name="web_discount" size="60" value="<?php echo $website_discount;?>" required/></td>
           </tr>
           
           <tr>
             <td align="right">Shipping:</td>
             <td>
             <input type="radio" name="web_shipping" value="1" <?php echo ($website_payment==1 ? "checked":"");?> >FREE<br>
  		     <input type="radio" name="web_shipping" value="0" <?php echo ($website_payment==0 ? "checked":"");?> >PAID<br>
             </td>
           </tr>
           
           
           
           
           <tr align="center">
             <td colspan="7"><input type="submit" name="add_web" value="Add Website Details Now" /></td>
           </tr>
           
           
           
     </table> 

</form>
	        		
	            </p>
	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>
<?php ?>