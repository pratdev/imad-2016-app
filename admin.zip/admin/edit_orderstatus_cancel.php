<?php 
 include ("includes/db.php");
 //$ddlprint=$_POST['ddlprint'];
 //echo $ddlprint;
		echo $_GET['orderstatus'];
		if(isset($_GET['newid'])){
 		$id = mysqli_real_escape_string($con,$_GET['newid']);
		$sql="";		  
	    $sql= $sql . " update orderdetails set orderstatus='".$_GET['orderstatus']."' where id in ( ".$id.")";		
		if ($sql!="")
		{
			$result= mysqli_multi_query($con, $sql);	
		}	
	//header("location:cancel_order.php");	
		
        }		
		
		
		
		
		
		
		
		
		
		
		
 

//echo $DestinationServiceArea;


?>