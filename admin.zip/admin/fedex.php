<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Order - Genius Import Export</title>

<!-- Bootstrap -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/mycss.css" rel="stylesheet">
<link href="css/print.css" rel="stylesheet">


<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
   
</head>

<body>
<input type="button" class="no-print btn-success" value="Print This Page" onClick="window.print()" />
	<?php 
 include ("includes/db.php");
 		$id = mysqli_real_escape_string($con,$_GET['id']);

  $get_pro = "select orderdetails.*,package.*,categories.cat_title,states.states from orderdetails INNER JOIN  package ON orderdetails.packageid=package.p_id
                 INNER JOIN categories ON categories.cat_id = orderdetails.p_cat_id INNER JOIN states ON states.stateid = orderdetails.state WHERE orderdetails.id in ( ".$id.")";

	  $run_pro = mysqli_query($con, $get_pro);
  while($row_pro=mysqli_fetch_array($run_pro))
	 {
     $prefix=$row_pro['prefix'];
     $OrderDate=$row_pro['OrderDate'];
     $orderid=$row_pro['id'];
     $bypost=$row_pro['bypost'];
     $prefix=$row_pro['prefix'];
     $name=$row_pro['name'];
     $address=$row_pro['address'];
     $city=$row_pro['city'];
     $state=$row_pro['states'];
     $pin=$row_pro['pin'];
     $mobile=$row_pro['mobile'];
	 $cat_title=$row_pro['cat_title'];
     $packagename=$row_pro['p_name'];
     $packageprice=$row_pro['pack_price'];
     $shippingcharge=$row_pro['shippingcharge'];
     //$packageprice=$packageprice+$shippingcharge;
	 $trackingcode=$row_pro['trackingcode'];
	 
	 $AirportId=$row_pro['AirportId'];
	 $UrsaPrefixCode=$row_pro['UrsaPrefixCode'];
	 $UrsaSuffixCode=$row_pro['UrsaSuffixCode'];
	 $StandAstraDescription=$row_pro['StandAstraDescription'];
	 $PriorAstraDescription=$row_pro['PriorAstraDescription'];
	 $FormId=$row_pro['FormId'];
	 $priorformid=$row_pro['priorformid'];
	 
	 $locality=$row_pro['locality'];
	 $paymentmethod=$row_pro['paymentmethod'];
	 $DestinationServiceArea=$row_pro['DestinationServiceArea'];
	 $DestinationLocation=$row_pro['DestinationLocation'];
     $ProvinceCode=$row_pro['ProvinceCode'];
//echo $DestinationServiceArea;
      $ttl="";
	  $totalamt=$packageprice+$shippingcharge;
?>
	
<div class="container">
<div class="main-layout-vpp">

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td width="40%" class="no-border" style="vertical-align:top;"><div class="logo-order3"><img src="images/logo-gie.jpg"><!----------Place for LOGO Here-----------------------></div></td>
<td class="no-border" width="30%"><div class="companyaddress-order3">
anupam saxena
<br>genius import export
<br>h-53 triveni nagar
<br>rangoli colony, nh-2 sikandra
<br>agra, up 282007</div>
<div class="phone-order3">Mob. 9536948375</div>
<div class="undelivered-order3">If undelivered return to this address</div>  

</td>
      <td class="border-left invoice-details-order3"><div>invoice no : <?php echo $prefix."-".$bypost."-".$orderid;?><br>
    invoice date : <?php echo  $_GET['prntdate'];?><br>
    tin no : 09600119311<br>
    cst no : 09600119311c</div></td>
    </tr>
  </tbody>
</table>


</div>






<div class="clear"></div>

<div class="main-layout-vpp">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td class="no-border"><div class="order-detail-order3">
<span>Order No: <?php echo $prefix."-".$bypost."-".$orderid;?></span><span class="shipdate-order3">Ship date :<?php echo  $_GET['prntdate'];?></span>
</div>

<div class="order-detail-order3">
<span>Description :</span><span class="healthcare">(HealthCare)</span>
</div>

<div class="order-detail-order3">
<span class="shipto">ship to :</span><span class="mobtext">Mob.</span><span class="mobno"> <?php echo $mobile;?></span>
</div>

<div class="order-detail-order3">
<span class="shipto-name"><?php echo $name;?></span>
</div>

<div class="address-order3">
<?php echo$address;?>
<br><?php echo$locality;?>
<br><?php echo $city;?>
<br><?php echo $state;?>
</div></td>

<td class="no-border" style="vertical-align:top;"><div class="order-detailright-order3">
<span class="shipto">FedEx </span><span class="cod-order3"> 
<?php if($paymentmethod=='ONLINE')
										{
											echo "PREPAID";
										}
										else
										{
											echo "COD";
										}  ?>
</span><span class="actwt-order3">ActWgt: 0.4 kg</span>
</div>

<div class="order-detailright-order3">
<span class="shipto">TRK# </span><span class="cod-order3"> <?php echo $StandAstraDescription;?></span><span class="formid-order3">Form Id:</span><span class="formid-number"> <?php echo $FormId;?></span>
<?php echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";
echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";
echo "&nbsp";echo "&nbsp";?>
<span class="formid-number"> <strong><?php echo $ProvinceCode;?>-IN</strong></span>
</div>

<div>
<span class="shipto">STANDARD OVERNIGHT</span><span class="overnight-text-order3"> <?php echo $UrsaPrefixCode;?></span><span class="overnight-text-order3"><?php echo $UrsaSuffixCode;?></span>
</div>

<div class="order-detailright-order3">
<div><img style="margin: 10px 2px;" width="550" height="130" src="barcode.php?size=100&text=<?php echo $StandAstraDescription; ?>&print=false" ></div>
</div></td>
    </tr>
  </tbody>
</table>


<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td class="no-border"><div class="order-detail-order3">
<span class="shipto">Postal Code : </span><span><?php echo $pin; ?></span><span class="mobtext">India</span>
</div></td>
      <td class="no-border"><div class="bill-detailright-order3">
<span class="bill-text-order3">Bill T/C : Sender</span><span class="bill-text-order3"> Bill D/T: Recipient</span><span class="bill-fedextext-order3">Fedex Meter</span><span class="bill-fedexnumber-order3">109325345</span>
</div></td>
    </tr>
  </tbody>
</table>







</div>



<div class="clear"></div>

<div class="main-layout-vpp">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
  
    <tr>
      <td class="no-border"><div class="order-detailright-order3">
	   <?php if($paymentmethod!='ONLINE')
										{ ?>
<span class="trk-order3">TRK# </span><span class="cod-order3"><?php echo $PriorAstraDescription;?></span><span class="formid1-order3">Form Id:</span><span class="formid-number"> <?php echo $priorformid;?></span>
                                        <?php } ?>
</div>

<div>
     <?php if($paymentmethod!='ONLINE')
										{ ?>
<span class="trk-order3">FedEx </span><span class="cod-return"> cod return</span><span class="priority"> PRIORITY OVERNIGHT</span>
										<?php } ?>
</div>
<div class="barcode-order3">
<?php if($paymentmethod!='ONLINE')
										{ ?>
<img style="margin: 10px 2px;" width="450" height="130" src="barcode.php?size=100&text=<?php echo $PriorAstraDescription; ?>&print=false" >
									<?php } ?>
</div>


</td>
										

   <?php echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp"; ?>

      <td class="no-border">
	  
      <div class="cod-order1"><?php if($paymentmethod=='ONLINE')
										{
											echo "PREPAID";
										}
										else
										{
											echo "COD CASH";
										} ?>
	  </div>
      <div><span class="collect-order3">collect :</span><span class="collect-amount">Rs 
	  <?php if($paymentmethod=='ONLINE')
										{
											echo "0.00";
										}
										else
										{
								           echo $totalamt;
								//echo (($packageprice + round($packageprice*.0500)));
                     					}			?>
	  </span></div>

      
      </td>
    </tr>
  </tbody>
</table>




</div>
									
<div class="clear"></div>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr class="headings-order3">
      <td class="text-center">category</td>
      <td class="text-center">description</td>
      <td >price</td>
      <td class="text-center">amount</td>
    </tr>
    <tr>
      <td><?php echo $cat_title;?></p></td>
      <td><?php echo $packagename;?><span class="healthcare">(HealthCare)</span></td>
      <td><?php echo round($price= $totalamt/(100+5)*100,2); ?>
	  </td>
      <td><strong>Rs</strong> <?php echo round($price= $totalamt/(100+5)*100,2); ?> </td>
    </tr>
    <tr>
      <td class="border-leftbottom">&nbsp;</td>
      <td class="border-bottom">&nbsp;</td>
      <td class="totalamount-details border-bottom" width="38%">subtotal
      <br>5% tax
      <br>Shipping & Handling Including Grand Total</td>
      <td class="border-rightbottom"><strong>Rs</strong> <?php 
	  echo round($price= $totalamt/(100+5)*100,2);
	  //echo $packageprice; ?>
      <br><strong>Rs</strong> <?php 
	  echo round($tax= $totalamt-($totalamt/(100+5)*100),2);
	      // echo round($packageprice*.0500); ?>
      <br><strong>Rs</strong> <?php echo $ttl=($price+$tax);
	     //echo (($packageprice + round($packageprice*.0500))); ?></td>
    </tr>
  </tbody>
</table>
<div class="footer-text-order3 text-center">All Prices are inclusive of taxes
<br>Subject to the FedEx conditions of carriage, which limit the liability of FedEx for loss, delay or damage to consignments. Visit www.fedex.com/in to view the Fedex
<br>Condition of Carriage</div>




</div>


<?php  } ?>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.2.min.js"></script>

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.js"></script>
</body>
</html>
