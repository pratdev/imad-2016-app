<?php
// Copyright 2009, FedEx Corporation. All rights reserved.
// Version 12.0.0

require_once('fedex-common.php');

//The WSDL is not included with the sample code.
//Please include and reference in $path_to_wsdl variable.
$path_to_wsdl = "ShipService_v19.wsdl";

// PDF label files. Change to file-extension .png for creating a PNG label (e.g. shiplabel.png)
define('SHIP_LABEL', 'shiplabel.pdf');  
define('COD_LABEL', 'codlabel.pdf'); 
//echo phpinfo();

ini_set("soap.wsdl_cache_enabled", "0");

$client = new SoapClient($path_to_wsdl, array('trace' => 1)); // Refer to http://us3.php.net/manual/en/ref.soap.php for more information

$request['WebAuthenticationDetail'] = array(
	'ParentCredential' => array(
		'Key' => getProperty('parentkey'), 
		'Password' => getProperty('parentpassword')
	),
	'UserCredential' => array(
		'Key' => getProperty('key'), 
		'Password' => getProperty('password')
	)
);

$request['ClientDetail'] = array(
	'AccountNumber' => getProperty('shipaccount'), 
	'MeterNumber' => getProperty('meter')
);
$request['TransactionDetail'] = array('CustomerTransactionId' => 'AK-CR-1000');
$request['Version'] = array(
	'ServiceId' => 'ship', 
	'Major' => '19', 
	'Intermediate' => '0', 
	'Minor' => '0'
);
$request['RequestedShipment'] = array(
	'ShipTimestamp' => date('c'),
	'DropoffType' => 'REGULAR_PICKUP', // valid values REGULAR_PICKUP, REQUEST_COURIER, DROP_BOX, BUSINESS_SERVICE_CENTER and STATION
	'ServiceType' => 'STANDARD_OVERNIGHT', // valid values STANDARD_OVERNIGHT, PRIORITY_OVERNIGHT, FEDEX_EXPRESS_SAVER
	'PackagingType' => 'YOUR_PACKAGING', // valid values FEDEX_BOX, FEDEX_PAK, FEDEX_TUBE, YOUR_PACKAGING, ...
	'Shipper' => addShipper(),
	'Recipient' => addRecipient(),
	'ShippingChargesPayment' => addShippingChargesPayment(),
	'SpecialServicesRequested' => addSpecialServices1(), //Used for Intra-India shipping - cannot use with PRIORITY_OVERNIGHT
	'CustomsClearanceDetail' => addCustomClearanceDetail(),                                                                                                      
	'LabelSpecification' => addLabelSpecification(),
	'CustomerSpecifiedDetail' => array('MaskedData'=> '604501202'), 
	'PackageCount' => 1,                                       
	'RequestedPackageLineItems' => array(
		'0' => addPackageLineItem1()
	)
);

 

try{
	if(setEndpoint('changeEndpoint')){
		$newLocation = $client->__setLocation(setEndpoint('endpoint'));
	}
	
	$response = $client->processShipment($request); // FedEx web service invocation

    if ($response->HighestSeverity != 'FAILURE' && $response->HighestSeverity != 'ERROR'){
        printSuccess($client, $response);

        // Create PNG or PDF labels
        // Set LabelSpecification.ImageType to 'PNG' for generating a PNG labels
        $fp = fopen(SHIP_LABEL, 'wb');   
        fwrite($fp, ($response->CompletedShipmentDetail->CompletedPackageDetails->Label->Parts->Image));
        fclose($fp);
        echo 'Label <a href="./'.SHIP_LABEL.'">'.SHIP_LABEL.'</a> was generated.';           
        
        $fp = fopen(COD_LABEL, 'wb');   
        fwrite($fp, ($response->CompletedShipmentDetail->AssociatedShipments->Label->Parts->Image));
        fclose($fp);
        echo 'Label <a href="./'.COD_LABEL.'">'.COD_LABEL.'</a> was generated.';   
    }else{
        printError($client, $response);
    }
	
	writeToLog($client);    // Write to log file
} catch (SoapFault $exception) {
   printFault($exception, $client);
}



function addShipper(){
	$shipper = array(
		'Contact' => array(
			'PersonName' => 'Anupam Saxena',
			'CompanyName' => 'GENIUSIMPORTEXPORT',
			'PhoneNumber' => '0562-23456245'
		),
		'Address' => array(
			'StreetLines' => 'H-53 Triveni Nagar, Rangoli Colony, NH-2, Sikandra, Agra, UP - 282007',
			'City' => 'Agra',
			'StateOrProvinceCode' => 'UP',
			'PostalCode' => '282007',
			'CountryCode' => 'IN',
			'CountryName' => 'INDIA'
		)
	);
	return $shipper;
}
function addRecipient(){
	$recipient = array(
		'Contact' => array(
			'PersonName' => 'Ram',
			'CompanyName' => '',
			'PhoneNumber' => '8004372086'
		),
		'Address' => array(
			'StreetLines' => 'Vijay Nagar ',
			'City' => 'Agra',
			'StateOrProvinceCode' => 'UP',
			'PostalCode' => '282002',
			'CountryCode' => 'IN',
			'CountryName' => 'INDIA',
			'Residential' => true
		)
	);
	return $recipient;	                                    
}
function addShippingChargesPayment(){
	$shippingChargesPayment = array(
		'PaymentType' => 'SENDER',
        'Payor' => array(
			'ResponsibleParty' => array(
				'AccountNumber' => getProperty('billaccount'),
				'Contact' => null,
				'Address' => array('CountryCode' => 'IN')
			)
		)
	);
	return $shippingChargesPayment;
}
function addLabelSpecification(){
	$labelSpecification = array(
		'LabelFormatType' => 'COMMON2D', // valid values COMMON2D, LABEL_DATA_ONLY
		'ImageType' => 'PDF',  // valid values DPL, EPL2, PDF, ZPLII and PNG
		'LabelStockType' => 'PAPER_8.5X11_TOP_HALF_LABEL'
	);
	return $labelSpecification;
}
function addSpecialServices1(){
	$specialServices = array(
		'SpecialServiceTypes' => 'COD',
		'CodDetail' => array(
			'CodCollectionAmount' => array(
				'Currency' => 'INR', 
				'Amount' => 100
			),
			'CollectionType' => 'CASH',// ANY, GUARANTEED_FUNDS
			'FinancialInstitutionContactAndAddress' => array(
				'Contact' => array(
					'PersonName' => 'Anupam Saxena',
					'CompanyName' => 'GENIUSIMPORTEXPORT',
					'PhoneNumber' => '0562-23456245'
				),
				'Address' => array(
					'StreetLines' => 'H-53 Triveni Nagar, Rangoli Colony, NH-2, Sikandra, Agra, UP - 282007',
					'City' => 'Agra',
					'StateOrProvinceCode' => 'UP',
					'PostalCode' => '282007',
					'CountryCode' => 'IN',
					'CountryName' => 'INDIA'
				)
			),
			'RemitToName' => 'Remitter'
		)
	);
	return $specialServices; 
}
function addCustomClearanceDetail(){
	$customerClearanceDetail = array(
		'DutiesPayment' => array(
			'PaymentType' => 'SENDER', // valid values RECIPIENT, SENDER and THIRD_PARTY
			'Payor' => array(
				'ResponsibleParty' => array(
					'AccountNumber' => getProperty('dutyaccount'),
					'Contact' => null,
					'Address' => array(
						'CountryCode' => 'IN'
					)
				)
			)
		),
		'DocumentContent' => 'NON_DOCUMENTS',                                                                                            
		'CustomsValue' => array(
			'Currency' => 'INR', 
			'Amount' => 100.0
		),
		'CommercialInvoice' => array(
			'Purpose' => 'SOLD',
			'CustomerReferences' => array(
				'CustomerReferenceType' => 'CUSTOMER_REFERENCE',
				'Value' => '1234'
			)
		),
		'Commodities' => array(
			'NumberOfPieces' => 1,
			'Description' => 'Books',
			'CountryOfManufacture' => 'IN',
			'Weight' => array(
				'Units' => 'KG', 
				'Value' => .4
			),
			'Quantity' => 1,
			'QuantityUnits' => 'EA',
			'UnitPrice' => array(
				'Currency' => 'INR', 
				'Amount' => 100.000000
			),
			'CustomsValue' => array(
				'Currency' => 'INR', 
				'Amount' => 100.000000
			)
		)
	);
	return $customerClearanceDetail;
}
function addPackageLineItem1(){
	$packageLineItem = array(
		'SequenceNumber'=>1,
		'GroupPackageCount'=>1,
		'InsuredValue' => array(
			'Amount' => 100.00, 
			'Currency' => 'INR'
		),
		'Weight' => array(
			'Value' => .4,
			'Units' => 'KG'
		),
		'Dimensions' => array(
			'Length' => 20,
			'Width' => 10,
			'Height' => 10,
			'Units' => 'CM'
		),
		'CustomerReferences' => array(
			'CustomerReferenceType' => 'INVOICE_NUMBER', // valid values CUSTOMER_REFERENCE, INVOICE_NUMBER, P_O_NUMBER and SHIPMENT_INTEGRITY
			'Value' => 'GR4567892'
		)
	);
	return $packageLineItem;
}
?>