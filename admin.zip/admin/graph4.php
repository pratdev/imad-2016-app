<?php 
include 'session.php';
include 'includes/db.php';

?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
	  


?>
	  
		 <title>View Graph Genius Admin Panel</title>
		 
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
     
	    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	    
		 <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
		
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>



	  <script>
				

			  $( function() {
				//$( "#datepicker" ).datepicker();
				$( "#datepicker" ).datepicker({changeMonth:true,changeYear:true,numberOfMonths:[1,1]});
				$( "#datepicker" ).datepicker("option", "dateFormat", "dd-mm-yy");
				  });
			 
			 $( function() {
				//$( "#datepicker2" ).datepicker();
				$( "#datepicker2" ).datepicker({changeMonth:true,changeYear:true,numberOfMonths:[1,1]});
				$( "#datepicker2" ).datepicker("option", "dateFormat", "dd-mm-yy");
			      });
		

	  </script>
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	
   <div class="blank-page">
   
<?php 
include ('includes/db.php');
?>
 
		
		

         <script>  
		 
		 
		 google.charts.load('current', {packages: ['corechart', 'line']});
google.charts.setOnLoadCallback(drawLogScales);

function drawLogScales() {
      var data = new google.visualization.DataTable();
	  
      data.addColumn('string', 'X');
      data.addColumn('number', 'Dogs');
      data.addColumn('number', 'Cats');

      data.addRows([
	  
        ['jan', 2, 0],    ['feb', 10, 5],   ['march', 23, 15],  ['april', 17, 9],   ['may', 18, 10]
        
        ]);

      var options = {
        hAxis: {
          title: 'Time',
          logScale: true
        },
 series: {0: {type: 'bars'}},
        vAxis: {
          title: 'Popularity',
          logScale: false
        },
        colors: ['#a52714', '#097138']
      };

      var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
      chart.draw(data, options);
    }
    </script>
	        
			
			<form method="post" action="<?php $_SERVER['PHP_SELF']; ?>" >
			From: <input type="text" name="fromdate" id="datepicker" value="<?php echo $_POST['fromdate']?>" required /  >
			To: <input type="text" name="todate" id="datepicker2" value="<?php echo $_POST['todate']?>" required /  >
			 <input type="submit" class="btn btn-success" name="submit" value="VIEW" />
			 </form>
			<!--
			From: <input type="text" id="datepicker"> 
			To: <input type="text" id="datepicker2">
			<input type="submit" class="btn btn-success" name="submit" value="VIEW" />-->
			
	   <div id="chart_div"  style='width: 900px; height: 500px;'></div>
       


	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>
	 