<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <base href="/">
    <title>Dashboard | Delhivery</title>
    <meta name="description" content="Delhivery - Dashboard">
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <link rel="stylesheet" href="https://cl.delhivery.com/app/vendor.css" />
    <link rel="stylesheet" href="https://cl.delhivery.com/app/app.css" />
	
	<link href="admin/css/print.css" rel="stylesheet" />
	
	
    <!-- freshwidget.css -->
    <!-- <style type="text/css" media="screen, projection">
        @import url(http://assets.freshdesk.com/widget/freshwidget.css);
    </style>  -->
    <!-- freshwidget.css -->
</head>
<body class=''>
    <style>
        *
        {
            font-family: "Open Sans" , "Helvetica Neue" , Helvetica, Arial, sans-serif;
        }
        p
        {
            color: #394263;
            line-height: 1.6;
        }
        table th, table td
        {
            font-size: 11px;
            vertical-align: top;
            position: relative;
            padding-left: 1px;
            padding-right: 1px;
        }
        h1, h2, h3, h4, h5, h6
        {
            color: #808080;
            font-weight: 300;
            margin-bottom: 10px;
            margin-top: 10px;
        }
        td h1
        {
            font-size: 36px;
        }
        td h2
        {
            font-size: 30px;
        }
        td h3
        {
            font-size: 24px;
        }
        td h4
        {
            font-size: 18px;
        }
        td h5
        {
            font-size: 14px;
        }
        td h6
        {
            font-size: 12px;
        }
        b, strong
        {
            font-weight: 600;
        }
        @media print
        {
            table
            {
                page-break-inside: auto;
            }
            tr
            {
                page-break-inside: avoid;
                page-break-after: auto;
            }
        }
    </style>
	<input type="button" class="no-print btn-success" value="Print This Page" onClick="window.print()" />
	<?php 
 include ("includes/db.php");
 		$id = mysqli_real_escape_string($con,$_GET['id']);

  $get_pro = "select orderdetails.*,package.*,states.states from orderdetails INNER JOIN  package ON orderdetails.packageid=package.p_id
                   INNER JOIN states ON states.stateid = orderdetails.state WHERE orderdetails.id in ( ".$id.")";

	  $run_pro = mysqli_query($con, $get_pro);
  while($row_pro=mysqli_fetch_array($run_pro))
	 {
     $prefix=$row_pro['prefix'];
     $OrderDate=$row_pro['OrderDate'];
     $orderid=$row_pro['id'];
     $bypost=$row_pro['bypost'];
     $prefix=$row_pro['prefix'];
     $name=$row_pro['name'];
     $address=$row_pro['address'];
     $city=$row_pro['city'];
     $state=$row_pro['states'];
     $pin=$row_pro['pin'];
     $mobile=$row_pro['mobile'];
     $packagename=$row_pro['p_name'];
     $packageprice=$row_pro['pack_price'];
     $shippingcharge=$row_pro['shippingcharge'];
     $packageprice=$packageprice+$shippingcharge;
	 $trackingcode=$row_pro['trackingcode'];
	 $locality=$row_pro['locality'];
	 $paymentmethod=$row_pro['paymentmethod'];
	 $DestinationServiceArea=$row_pro['DestinationServiceArea'];
	 $DestinationLocation=$row_pro['DestinationLocation'];

	 


//echo $DestinationServiceArea;


?>
	
	
	
    <!-- ngRepeat: package in packages -->
    <table style="width: 345px; margin: 0px auto 15px; background: #fff;" cellpadding="0"
        cellspacing="0" ng-repeat="package in packages" class="ng-scope">
        <tbody>
            <tr>
                <td>
                    <table width="100%" style="border: 1px solid #000000;" cellpadding="5" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="50%" style="border-right: 1px solid #000000; color: #394263; font-size: 11px">
                                    <strong ng-show="!package.cl_logo" class="ng-binding ng-hide">GENIUSSKYSHOP</strong>
                                </td>
                                <td width="50%" align="center">
                                   <h3> BLUE DART</h3>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="100%" style="border-right: 1px solid #000000; border-bottom: 1px solid #000000;
                        border-left: 1px solid #000000;" cellpadding="5" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="50%">
<img style="margin: 10px 2px;" width="144" alt="<?php echo $trackingcode; ?>" src="admin/barcode.php?text=<?php echo $trackingcode; ?>&print=true" >                              
</td>
                                 <td class="border-left-none ">
      <div class="dartcod">DART APEX (<?php 
						if($paymentmethod=='ONLINE')
										{
											echo "PREPAID";
										}
										else
										{
											echo $paymentmethod;
										}
	  ?>)</div>
      <div class="awb"><strong>AWB NO#</strong> <?php echo $trackingcode; ?></div>
      <div class="awb">ActWgt: 0.3Kg</div>
      <div class="pack-dimnsion-order2">Packing Dimension : 15x10x8(CM)</div>
      </td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="100%" style="border-right: 1px solid #000000; border-bottom: 1px solid #000000;
                        border-left: 1px solid #000000;" cellpadding="5" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="70%" style="border-right: 1px solid #000000;">
                                    <p style="font-weight: bold; margin: 0">
                                        Shipping Address:</p>
                                    <p style="font-size: 10px; font-weight: bold; margin: 0; font-size: 14px" class="ng-binding">
                                        <?php echo $name;?></p>
                                    <p style="margin: 0; font-size: 9px;">
                                        <b class="ng-binding">Phone:Phone: <?php echo $mobile;?></b></p>
                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                        Landmark - <?php echo $address;?>
                                        <?php echo $locality;?></p>
                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                       <?php echo $city;?> (<?php echo $state;?>)</p>
                                    <p style="margin: 0; font-size: 9px;">
                                        <strong class="ng-binding">PIN: <?php echo $pin;?></strong></p>
<div>Destination: <span class="designation-text-order2"><?php echo $DestinationServiceArea;?> / <?php echo $DestinationLocation;?></span></div>
<div>Pin Code: <?php echo $pin;?> <span class="india-text-order2">India</span></div>										
										
                                </td>
                                <td width="30%" align="center" style="vertical-align: middle;">
                                    <h5>
                                        <strong class="ng-binding"><?php 
										if($paymentmethod=='ONLINE')
										{
											echo "PREPAID";
										}
										else
										{
											echo $paymentmethod." "."CASH";
										}
										 ?></strong></h5>
										
                                    <h4 ng-show="package.pt == 'COD'" class="">
									<div class="cod-order2">COLLECT:</div>
                                        <strong class="ng-binding">Rs&nbsp;<?php
										if($paymentmethod=='ONLINE')
										{
											echo "0";
										}
										else
										{
											echo $packageprice;
										}
										
										?></strong></h4>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="100%" style="border-right: 1px solid #000000; border-bottom: 1px solid #000000;
                        border-left: 1px solid #000000;" cellpadding="5" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="60%" style="border-right: 1px solid #000000;">
                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                        Seller: GENIUS SKY SHOP </p>
                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                        Address:  BAIPUR SIKANDRA AGRA UTTAR PRADESH PIN­282007</p>
                                </td>
                                <td width="40%">
                                    INVOICE NO : <?php echo $prefix."-".$bypost."-".$orderid;?><br>
                                    INVOICE DATE :<?php echo $OrderDate;?><br>
                                    TIN NO : 09600118851<br>
                                    CST NO : 09600118851C</td>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="100%" style="border-right: 1px solid #000000; border-bottom: 1px solid #000000;
                        border-left: 1px solid #000000;" cellpadding="0" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="60%" style="border-right: 1px solid #000000;">
                                    <table width="100%" cellpadding="5" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;">
                                                        Product</p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td width="40%">
                                    <table width="100%" cellpadding="5" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td width="50%" align="center" style="border-right: 1px solid #000000;">
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;">
                                                        Price</p>
                                                </td>
                                                <td width="50%" align="center">
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;">
                                                        Total</p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="100%" style="border-right: 1px solid #000000; border-bottom: 1px solid #000000;
                        border-left: 1px solid #000000;" cellpadding="0" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="60%" style="border-right: 1px solid #000000;">
                                    <table width="100%" cellpadding="5" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td style="height: 70px; vertical-align: middle;">
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                                      <?php echo $packagename;?></p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td width="40%">
                                    <table width="100%" cellpadding="5" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td width="50%" align="center" style="border-right: 1px solid #000000; height: 70px;
                                                    vertical-align: middle;">
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                                        ₹&nbsp;<?php echo $packageprice;?></p>
                                                </td>
                                                <td width="50%" align="center" style="height: 70px; vertical-align: middle;">
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;" class="ng-binding">
                                                        ₹&nbsp;<?php echo $packageprice;?></p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="100%" style="border-right: 1px solid #000000; border-bottom: 1px solid #000000;
                        border-left: 1px solid #000000;" cellpadding="0" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="60%" style="border-right: 1px solid #000000;">
                                    <table width="100%" cellpadding="5" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;">
                                                        <strong>Total</strong></p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td width="40%">
                                    <table width="100%" cellpadding="5" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td width="50%" align="center" style="border-right: 1px solid #000000;">
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;">
                                                        <strong class="ng-binding">₹&nbsp;<?php echo $packageprice;?></strong></p>
                                                </td>
                                                <td width="50%" align="center">
                                                    <p style="margin: 0; line-height: 9pt; font-size: 9px;">
                                                        <strong class="ng-binding">₹&nbsp;<?php echo $packageprice;?></strong></p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="100%" style="border-right: 1px solid #000000; border-bottom: 1px solid #000000;
                        border-left: 1px solid #000000;" cellpadding="5" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="">
<img style="margin: 10px 0px;" alt="<?php echo $prefix."-".$bypost."-".$orderid;?>" src="admin/barcode.php?text=<?php echo $prefix."-".$bypost."-".$orderid;?>&print=true" />
                                </td>
                                <td width="" align="left">
                                    <p style="line-height: 9pt; font-size: 9px; margin: 5px 0 0px;">
                                        <span class="ng-binding">Return Address:  H­43,Laxmi , Nagar,Behind Sikandra, Hospital, Sikandra,</span>
                                        <span ng-show="4" class="ng-binding">- Agra</span> <span ng-show="Utter Pradesh"
                                            class="ng-binding">- Utter Pradesh</span> <span ng-show="282007" class="ng-binding">
                                                - 282007</span></p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
	<?php  } ?>
    <!-- end ngRepeat: package in packages -->
   
	
    <!-- end ngRepeat: package in packages -->
</body>
</html>
