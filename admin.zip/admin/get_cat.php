<?php 
//include 'session_admin.php';

include 'includes/db.php';

?>   
   <option>Select a Category</option>
                
				
				<?php 
                  include ('includes/db.php');
	  
	   if (isset($_GET['web_id'])){
		   
                $web_id = $_GET['web_id'];
				
				$web_id = mysqli_real_escape_string($con, $web_id);
               
			if (!is_null($web_id) and !empty($web_id)) {
               
				  //echo $web_id ;
                $get_cats = "SELECT * from categories where c_web_id='$web_id'";
                         
                
                $run_cats = mysqli_query($con,$get_cats);
                
                   while ($row_cats=mysqli_fetch_array($run_cats)) {
                	 
                	$cat_id  = $row_cats['cat_id'];
                	$cat_title = $row_cats['cat_title'];
                
                	echo "<option value='$cat_id'>$cat_title</option>";
                
                	 
                }
			  }
				  }
                
                ?>
                
                
          