
<?php 
include 'session.php';
include 'includes/db.php';


?>
<?php include 'template/header.php';
     
?>
	<title>View Order Details | Genius Admin Panel</title>
	  
  <!-- 
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
--> 
<link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel='stylesheet' type='text/css' />

 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">

<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
	    
	  <script>
			$(document).ready(function() {
					$('#example').DataTable();
				} );

	  </script>

	  <!--<script type="text/javascript">
			$(document).ready(function(){
		          $( "#target" ).click(function() {
						$("#myModal").modal('show');
					});});
	 </script>-->
 	 
 	 
 	 <?php 
	 include 'template/sidebar.php';
?>
	 <?php/*
	 if(isset($_POST['submit'])) {
        $sql = mysql_query("SELECT * FROM table WHERE name LIKE '%" . $_POST['name'] . "%'
                   OR address LIKE '%" . $_POST['address'] . "%'
                   OR city LIKE '%" . $_POST['city'] . "%'
                   OR state LIKE '%" . $_POST['state'] . "%'
                   OR zip LIKE '%" . $_POST['zip'] . "%'");
    }*/
?>
<?php
if(isset($_POST['submit'])){
	
	
}
else{
		$_POST['byorder']="";
        $_POST['bypost']="";
		$_POST['orderstatus']="";
	     $_POST['paymentmethod']="";
		 $_POST['startdate']="";
		 $_POST['enddate']="";
		 $_POST['couriercompany']="";
		 $_POST['id']="";
		 $_POST['webisiteid']="";
		  $_POST['pin']="";

}
   ?>   


 	  <div id="page-wrapper" class="gray-bg dashbard-1">
	  
     <!--Search options starts here-->
	 <h1 style="color:green; font-family:arial;" ><b>Search Order</b></h1>
      <br>
	  <div id="form">
	 
        <form method="post" action="<?php $_SERVER['PHP_SELF']; ?>">
		<table  align="left" width="100%" border="1" bgcolor="#187eae" >

			
			 <tr>
			
             <td>Pincode:</td>
                <td><input type="text" name="pin" /></td>
				
			 <td>Mobile:</td>
                <td><input type="text" name="mobile" /></td>	
            
            </tr>
			
			<tr>
			
             <td>TRACKING NUMBER:</td>
                <td><input type="text" name="trackingcode" /></td>
				
			 <td>NAME:</td>
                <td><input type="text" name="name" /></td>	
			</tr>
			
            <tr>
			
             <td>City Name:</td>
                <td><input type="text" name="city" /></td>
			
			<td>ORDERTYPE:</td>
                <td>
				<select name="bypost">
				            <option value=""  >Bypost</option>
							<option value="PO" <?php echo ($_POST['bypost']=="PO" ? "Selected": "");?>  >PO</option>
							<option value="CR" <?php echo ($_POST['bypost']=="CR" ? "Selected": "");?>  >CR</option>
							
						</select>
				</td>
			
            </tr>
			
			<tr>
			
             <td>ORDER NUMBER/ID:</td>
                <td><input type="text" name="id" /></td>
            
			
                <td>&nbsp;</td>
                <td><input type="submit" name="submit" value="Search" class="btn btn-success"/></td>
            </tr>
			<?php// echo $_POST['startdate']?>
						<?php// echo $_POST['enddate']?>

        </form>
    </table>
	 
	 </div>
	 
    <!--Search options ends here--> 

       <div class="content-main">

 	<div class="blank">
 	
					
 		

  <h2 style="color:green;font-family:arial">Orders Details</h2>
  <br>
 <div style="overflow-x:auto;">
  <table id="example" class="display"  cellspacing="0" width="100%">
 	
 <thead>
	<tr>
	    <th>Serial No.</th>
	    <th>Order Id</th>
		<th>Name</th>
	    <th>Website Name</th>
		<th>Order Status</th>
		<th>Tracking Code</th>
	    <th>Pincode</th>
		<th>Mobile No.</th>
		<th>City</th>
		<th>Email</th>
		<th>Address</th>
		<th>State</th>	
        <th>Locality</th>
		<th>Payment Mode</th>
		<th>Payment Status</th>
		<th>Package Name</th>
		<th>Package Price</th>
		<th>SHIPPING PRICE</th>
		<th>ORDER TYPE</th>
		<th>COURIER COMPANY</th>
		<th>BYORDER</th>
		<th>Order Date Time</th>
				
			
		<!--<th>Admin Response</th>
		
	    <th class="select">Command</th>
		
	    <th class="select">Payment Status</th>-->

   </tr>   
</thead>
 		<tbody>
	     
		<?php 
	    include ("includes/db.php");
	  if(isset($_POST['submit'])){
		  
		  
	  $get_pro = "select orderdetails.*,package.*,states.states from orderdetails INNER JOIN  package ON orderdetails.packageid=package.p_id
                   INNER JOIN states ON states.stateid = orderdetails.state WHERE orderdetails.city LIKE '%" . $_POST['city'] . "%'
				   AND orderdetails.bypost LIKE '%" . $_POST['bypost'] . "%'
				   AND orderdetails.pin LIKE '%" . $_POST['pin'] . "%'
				   AND orderdetails.mobile LIKE '%" . $_POST['mobile'] . "%'
				   AND orderdetails.name LIKE '%" . $_POST['name'] . "%'
				   AND orderdetails.trackingcode LIKE '%" . $_POST['trackingcode'] . "%' 
				   AND orderdetails.id LIKE '%" . $_POST['id'] . "%' ORDER BY ID DESC";
	/*				

if(empty($_POST['id']))	{				
						
		   $get_pro = "select orderdetails.*,package.*,states.states from orderdetails INNER JOIN  package ON orderdetails.packageid=package.p_id
                   INNER JOIN states ON states.stateid = orderdetails.state WHERE orderdetails.id =$_POST['webisiteid']";
		
		  
}
	*/			   
				   
	  
	  //help for above query
	 // select  package.*, websites.web_domain from package INNER JOIN websites ON package.p_web_id=websites.web_id where websites.web_domain='$web_domain' 
	// echo  $get_pro;
	 // exit();
	  $run_pro = mysqli_query($con, $get_pro);
	 // $row_pro = mysqli_query($con, $get_pro);
	  $i=0;

	  while ($row_pro=mysqli_fetch_array($run_pro))
	  {
			
			$web_domain =  $row_pro['web_domain'];	
		    
			$id = $row_pro['id'];

			$prefix = $row_pro['prefix'];
			$order_id = $row_pro['id'];
            $orderstatus = $row_pro['orderstatus'];
			
			$pincode = $row_pro['pin'];

			$name =  $row_pro['name'];
			
			$number = $row_pro['mobile'];
			$email = $row_pro['email'];
			
			$address = $row_pro['address'];
			$states =  $row_pro['states'];
			$cityname = $row_pro['city'];
			
			$SelLocation = $row_pro['locality'];
			
			$package = $row_pro['p_name'];
			$packagecost = $row_pro['pack_price'];
			$bypost = $row_pro['bypost'];
			$paymentmethod = $row_pro['paymentmethod']; 
			$shippingcharge=$row_pro['shippingcharge'];
			
			$trackingcode=$row_pro['trackingcode'];
			
			/*
			if($paymentmethod=="ONLINE")
		  {
			  $packagecost=round($packagecost*.95);
		  }
		  else{
			 $packagecost=$packagecost;
		  }*/

            $OrderDate = $row_pro['OrderDate'];
	

		  // $pcode = $row_pro['PostalCode'];--not here on form i.e run time only
		
			



			$bgcolor="";

			if( $orderstatus=="PENDING" || $orderstatus=="NONE")
		  {
				$bgcolor="#DAFF33";
          }else if($orderstatus=="CONFIRM")
		  {
			   $bgcolor="#5AE012"; 
		  }
		  else if($orderstatus=="CANCEL")
		  {
			  $bgcolor="#FF5833";
		  }

	    $i++;
	?>
	
	 <tr style=" background-color:<?php echo $bgcolor;?>">
	    
	 	<td><?php echo $i?></td>
		<td><?php echo $prefix."-".$bypost."-".$order_id;?></td>
		<td><?php echo $name?></td>
		<td><?php echo $web_domain?></td>
		<td><?php echo $orderstatus?></td>
		<td><?php echo $trackingcode?></td>
	 	<td><?php echo $pincode?></td>
	 	<td><?php echo $number?></td>
		<td><?php echo $cityname?></td>
	 	<td><?php echo $email?></td>
	 	<td><?php echo $address?></td>
	 	<td><?php echo $states?></td>	
		<td><?php echo $SelLocation?></td>
		<td><?php echo $paymentmethod?></td>
	    <td><?php echo $row_pro['paymentstatus']?></td>
		<td><?php echo $package?></td>
        <td><?php echo $packagecost?></td>
		<td><?php echo $shippingcharge?></td>
		<td><?php echo $row_pro['bypost']?></td>
        <td><?php echo $row_pro['couriercompany']?></td>
        <td><?php echo $row_pro['byorder']?></td>
	    <td><?php echo $OrderDate?></td>
	 	


	 	<!--<td><a href="edit_order.php?id=<?php// echo $row_pro['id'];?>">Edit</a></td>
		  <td><a href="chek.php?id=<?php// echo $id;?>"><?php //echo "EDIT";?></a></td>
	 	<td><a href="javascript:getConfirmation('<?php //echo $order_id;?>')">Delete</a></td>-->
	 
	 	 </tr>
	
	
	 <?php } 
	  }?>
	
	 </tbody> 
	 
   </table>
</div>
       </div>
     
 
	  
     
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>
<?php ?> 
