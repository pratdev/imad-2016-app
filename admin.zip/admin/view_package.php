<?php 
include 'session.php';

include 'includes/db.php';


?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
?>
	
	   <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
<link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel='stylesheet' type='text/css' />

<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>


  <script>
			$(document).ready(function() {
                $('#example').DataTable();
            } );

  </script>
 	 
 	 
 	<div class="asked">
 	
  <h2>View All Package's Here</h2>
    <table id="example" class="display" cellspacing="0" width="100%">
     
	
	 
	 <thead>
            <tr>
				<th>S.N</th>
				<th>Package Name</th>
				<th>Domain Name</th>
				<th>Package Category</th>
				<th>Package Price</th>
				<th>Shipping Price</th>
				<th>Package Status</th>
				<th>Edit</th>
				<!--<th>Delete</th>-->
			</tr>
        </thead>
       
	<tbody>
	
	<?php 
	  include ("includes/db.php");
	 
	  $get_pro = "SELECT package.*, websites.web_domain, categories.*
                  FROM package INNER JOIN websites ON package.p_web_id = websites.web_id left JOIN categories ON package.p_cat_id = categories.cat_id;";
	  
	  /*This query will also do same work as above query
	   * SELECT package.p_name, websites.web_domain, categories.cat_title, package.p_price, package.p_shipping, package.p_status
                  FROM package INNER JOIN websites ON package.p_web_id = websites.web_id INNER JOIN categories ON package.p_cat_id = categories.cat_id*/
	  
	  $run_pro = mysqli_query($con, $get_pro);
	  
	  $i=0;
	  
	  while ($row_pro=mysqli_fetch_array($run_pro))
	  {
	  	$p_id = $row_pro['p_id'];
	  	
				$package_name = $row_pro['p_name'];
				$package_web_id = $row_pro['p_web_id'];
				$package_cat_id = $row_pro['p_cat_id'];
				$package_price = $row_pro['p_price'];
				$package_shipping = $row_pro['p_shipping'];
				$package_status = $row_pro['p_status'];
	  	
	    $i++;
	?>
	
	 <tr>
	 
	 	<td><?php echo $i?></td>
	 	<td><?php echo $package_name?></td>
	 	<td><?php echo $row_pro['web_domain']?></td>
	 	<td><?php echo $row_pro['cat_title']?></td>
	 	<td><?php echo $package_price?></td>
	 	<td><?php echo $package_shipping?></td>
	 	<td><?php echo ($package_status==1 ? "Active" : "Inactive");?></td>
	 	
	 	<td><a href="edit_pack.php?p_id=<?php echo $row_pro['p_id'];?>">Edit</a></td>
	 	<!--<td><a href="javascript:getConfirmation('<?php echo $p_id;?>')">Delete</a></td>-->
	 	
	 </tr>
	 
	 <?php } ?>
	  </tbody> 
    </table>

          <script type="text/javascript">
         //<!--
            function getConfirmation(p_id){
               var retVal = confirm("Do you want to continue ?");
               if( retVal == true ){
                 window.location.href  = "delete_pack.php?delete_pack=" +p_id;
               }
               else{
                 // document.write ("User does not want to continue!");
                  return false;
               }
            }
         //-->
      </script>
      
<?php include 'template/footer.php';?>
