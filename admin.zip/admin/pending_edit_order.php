<?php 
include 'session.php';

include 'includes/db.php';


?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
      include 'includes/db.php';
	  
?>

    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				
	        	<p>
<?php
$oldpaymentmethod="";
$oldpackageid="";
if(isset($_GET['id'])){

	$id = $_GET['id']; 
	
	
	//$get_pro = "select * from orderdetails where id='$id'";
	
	 
	// $get_pro = "select orderdetails.*,states.states from orderdetails INNER JOIN  states ON  orderdetails.state=states.stateid where id='$get_id'";
                //   INNER JOIN states ON states.stateid = orderdetails.state ORDER BY id DESC";
	 
	 // $get_pro = "select orderdetails.*,package.*,states.states from orderdetails INNER JOIN  package ON orderdetails.packageid=package.p_id
                //   INNER JOIN states ON states.stateid = orderdetails.state ORDER BY id DESC";
	//$sql="SELECT * FROM orderdetails where id=$id";
	$sql="SELECT orderdetails.*,categories.cat_title,websites.sellnum FROM orderdetails INNER JOIN categories ON categories.cat_id = orderdetails.p_cat_id 
	INNER JOIN websites ON websites.web_id = orderdetails.web_id  where id=$id";
$result=$con->query($sql);
if($row=mysqli_fetch_array($result)){
	
	
//	$run_pro = mysqli_query($con, $get_pro);
	
	$i = 0;
	
	//if($row_pro=mysqli_fetch_array($run_pro)){
		//$id=$get_id;
	//$id=$row_pro['packageid'];
	        $cat_title=$row['cat_title'];
			$sellnum=$row['sellnum'];
            $oldpackageid=$row['packageid'];
		    $prefix = $row['prefix'];
			$orderstatus = $row['orderstatus'];
			$pincode = $row['pin'];
			$name =  $row['name'];
			$number = $row['mobile'];
			$email = $row['email'];
			$address = $row['address'];
			$states =  $row['state'];
			$cityname = $row['city'];
			$SelLocation = $row['locality'];
			$paymentmethod=$row['paymentmethod'];
			$oldpaymentmethod=$row['paymentmethod'];
	  	    $web_id=$row['web_id'];
	  	    $web_domain=$row['web_domain'];
			$oldpackageprice=$row['pack_price'];
			$shippingcharge=$row['shippingcharge'];
			$bypost=$row['bypost'];
		    $paymentstatus=$row['paymentstatus'];                         
           // $size=$row['size'];
            $user_id=$row['user_id'];
			$couriercompany = $row['couriercompany'];

	}		
	
		
		
}
?>
<?php 

	if(isset($_POST['update_admin'])){
	
		//getting the text data from the fields

		$update_id = $id;
		
		
		
		
		$orderstatus = mysqli_real_escape_string($con,$_POST['orderstatus']);
		
	
	
	
	  //  $size= mysqli_real_escape_string($con,$_POST['size']);		
		$pincode = mysqli_real_escape_string($con,$_POST['pin']);
		$name = mysqli_real_escape_string($con,$_POST['name']);
		$number = mysqli_real_escape_string($con,$_POST['mobile']);
		$email = mysqli_real_escape_string($con,$_POST['email']);
		$address = mysqli_real_escape_string($con,$_POST['address']);
		$states = mysqli_real_escape_string($con,$_POST['stateid']);
		$locality = mysqli_real_escape_string($con,$_POST['locality']);
		
		//$bypost = mysqli_real_escape_string($con,$_POST['bypost']);
		
		//$packageid = mysqli_real_escape_string($con,$_POST['packageid']);
       // $web_domain=mysqli_real_escape_string($con,$_POST['web_domain']);
	   // $newpaymentmethod=mysqli_real_escape_string($con,$_POST['oldpaymentmethod']);
	    $city=mysqli_real_escape_string($con,$_POST['city']);
       
		$sql="SELECT * FROM tbl_postalcode WHERE PostalCode='$pincode'";
				$result2=$con->query($sql);


				if($result2->num_rows){

				$row=$result2->fetch_assoc();
				$bypost="CR";
				if(strcasecmp($row['couriercompany'], "Delhivery")==0){
				$couriercompany="Delhivery";	
				
				}
				elseif(strcasecmp($row['couriercompany'], "bluedart")==0){
				$couriercompany="bluedart";
				
				}
				elseif(strcasecmp($row['couriercompany'], "fedex")==0){
				$couriercompany="fedex";
				
				}
				}
				
				else{

				$couriercompany="POSTOFFICE";	
				$bypost="PO";
				}
		
		
		
		
		
			if($paymentmethod=="COD"){
		$packageid = mysqli_real_escape_string($con,$_POST['packageid']);
		}
	/*if ($paymentmethod!="COD")
		{
			
			if($oldpackageid!=$packageid )
			{
				exit();
			}
		}*/
			
			
		
if($paymentmethod=="COD"){
	if($packageid!=$oldpackageid){
	$sql="SELECT * FROM package where p_id=$packageid";
$result=$con->query($sql);

if($row=mysqli_fetch_array($result)){
	$packagecost=$row['p_price'];
	$shippingcharge=$row['p_shipping'];
}

	}
else{
	$packageid=$oldpackageid;
	$packagecost=$oldpackageprice;
	
}	

	
	if(strtolower($orderstatus)==strtolower("AWAITINGSHIPPING") || strtolower($orderstatus)==strtolower("CANCEL")){
		$user_id=$_SESSION['user_id'];
	}


	$sql = "update orderdetails set orderstatus='$orderstatus',pin='$pincode',name='$name',mobile='$number',email='$email',address='$address',city='$city',
		          state='$states',locality='$locality',packageid='$packageid',pack_price='$packagecost',shippingcharge='$shippingcharge',user_id='$user_id',
				  cnfmcncldate= now(),couriercompany='$couriercompany' where id='$update_id'";
   $result=$con->query($sql);

}
		
	
   else{
	   
	   if(strtolower($orderstatus)==strtolower("CANCEL") && strtolower($paymentstatus)== strtolower("DONE")){
		   ?>
	<script type="text/javascript">
    alert("You can not CANCEL order because paymentstatus is DONE");
    location="";
    </script>
    <?php
	exit();		   
		   
	   }
	   
	   
	   elseif(strtolower($orderstatus)!=strtolower("CANCEL")){
	   if(strtolower($paymentmethod)==strtolower("ONLINE") && strtolower($paymentstatus)!=strtolower("DONE")){
		   			?>
	<script type="text/javascript">
    alert("Your paymentstatus is not DONE in ONLINE mode so You can not change orderstatus");
    location="";
    </script>
    <?php
	exit();		   
	   }
	  
	   }
	   elseif(strtolower($orderstatus)==strtolower("AWAITINGSHIPPING")){
		   
		   
		   
	   }
	 
	
	 
	   $sql = "update orderdetails set orderstatus='$orderstatus',pin='$pincode',name='$name',mobile='$number',email='$email',address='$address',city='$city',
		         state='$states',locality='$locality',user_id='$user_id',couriercompany='$couriercompany',cnfmcncldate= now() where id='$update_id'";
//$sql = "update orderdetails set orderstatus='$orderstatus',pin='$pincode',name='$name',mobile='$number',email='$email',address='$address',city='$city'
		               //      ,state='$states',locality='$locality', where id='$update_id'";   
	$result=$con->query($sql);
	 
   }

		 
		 if($result){
			
            if(strtolower($orderstatus)==strtolower("CANCEL")){
            $package_sms_price=($packagecost + $shippingcharge);
			$orderid=$prefix."-".$bypost."-".$id;
			$username = 'youremail@address.com';
			$hash = 'Your API hash';
			$apiKey='7Fok6gPjqoA-vo8T36MkAVdib4COP7YTGyNoRG3IHf';
			$numbers = array($number); 
			$sender = urlencode('GENIUS');
			$date = new DateTime();
			//$message = rawurlencode("Dear ". $name ." Your Order of ". $cat_title  ." has been dispatched by ". $couriercompany  ." and Your TRACKING No: ". $trackingno  ." and for more information you can call on this ". $sellnum  .".");
			$message = rawurlencode("Your order no. "  . $orderid ." of ". $cat_title ." Rs ". $package_sms_price ." has been canceled. if you want to order again call ". $sellnum  .".");
			$numbers = implode(',', $numbers);
			$data = array( 'apiKey' => $apiKey, 'numbers' => $numbers, 'test'=>false,  'sender' => $sender, 'message' => $message);
		   try{
			   
			
			$ch = curl_init('http://api.textlocal.in/send/');
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$response = curl_exec($ch);
			curl_close($ch);
			//echo$response;
			$result = json_decode($response);
			
			
			 }catch (Exception $ex)
			 {
				 echo "<script>alert('Server Error')</script>";
			 }
			}
			
			
			 
			 
		 
	     echo "<script>alert('Admin Response has been updated!')</script>";
		 
		 echo "<script>window.open('view_order.php','_self')</script>";
		 // header("Location:view_order.php");
		 }
		
	}


?>

		<title>Update Admin Response Details</title> 
		

	
	



	<form action="" method="post" enctype="multipart/form-data"> 
		
		<table align="center" width="795" border="2" bgcolor="#187eae">
			
			<tr align="center">
				<td colspan="7"><h2>Edit & Update Admin Response</h2></td>
			</tr>
			
			<tr>
			    <td align="right"><b><h4>OrderID:</h4></b></td>
				<td><h4><?php echo $prefix."-".$bypost."-".$id; ?></h4></td>

			</tr>
			
				
			<tr>
				<td align="right"><b>WEBSITE NAME:</b></td>
				<td><h4><?php echo $web_domain;?></h4></td>
			</tr>
			
			
			
			<tr>
				<td align="right"><b>CUSTOMER NAME:</b></td>
				<td><input type="text" name="name" size="60" value="<?php echo $name;?>"/></td>
			</tr>

            <tr>
				<td align="right"><b>PHONE NUMBER:</b></td>
				<td><input type="text" name="mobile" size="60" value="<?php echo $number;?>"/></td>
			</tr>

			<tr>
				<td align="right"><b>E-Mail ID:</b></td>
				<td><input type="text" name="email" size="60" value="<?php echo $email;?>"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>ADDRESS:</b></td>
				<td><textarea name="address" rows="2" cols="20"><?php echo $address;?></textarea></td>
			</tr>
			
			<tr>
				<td align="right"><b>PINCODE:</b></td>
				<td><input type="text" name="pin" size="60" value="<?php echo $pincode;?>"/></td>
			</tr>

			<tr>
				<td align="right"><b>STATE:</b></td>
				<td>
				
				
				
				<select name="stateid">
<?php
 
$sql="SELECT * FROM states";
$result=$con->query($sql);
while($row=mysqli_fetch_array($result)){
$statename=$row['states'];
$stateid=$row['stateid'];
echo "<option value='".$stateid."' ".  ($stateid==$states ? "Selected": "")  ."  >".$statename."</option>";
}
?>

</select>			
</td>
</tr>
			
			<tr>
				<td align="right"><b>CITY:</b></td>
				<td><input type="text" name="city" size="60" value="<?php echo $cityname;?>"/></td>
			</tr>

			<tr>
				<td align="right"><b>LOCATION:</b></td>
				<td><input type="text" name="locality" size="60" value="<?php echo $SelLocation;?>"/></td>
			</tr>

			<tr>
				<td align="right"><b> PAYMENT METHOD:</b></td>
				<td><?php echo $oldpaymentmethod;?></td>
				
			</tr>
			
			<tr>
				<td align="right"><b> PAYMENT STATUS:</b></td>
				<td><?php echo $paymentstatus;?></td>
			</tr>
			
			
				<tr>
				<td align="right"><b>PACKAGE NAME</b></td>
				<td>
				
				
				<select name="packageid" <?php echo ($oldpaymentmethod=="ONLINE"? "disabled" : ""); ?> >
<?php
 
$sql="SELECT * FROM package where p_status=1 and p_web_id='$web_id'";
$result=$con->query($sql);
while($row=mysqli_fetch_array($result)){
$packagename=$row['p_name'];
$packageid= $row['p_id'];
$packagecost=$row['p_price'];
echo "<option data-price=".$row['p_price']." data-shipping=".$row['p_shipping']." value='".$packageid."' ".  ($packageid==$oldpackageid ? "Selected": "")  ."  >".$packagename."</option>";
}
?>

	  
				</select>		
				</td>
			</tr>
			
			
				<tr>
				<td align="right"><b> PACKAGE PRICE:</b></td>
				<td name="newprice"><h4 data-newprice=""><?php echo $oldpackageprice;?></h4></td>
			</tr>
			
			
			<tr>
				<td align="right"><b>SHIIPPING CHARGE:</b></td>
				<td><h4 data-shipping=""><?php echo $shippingcharge;?></h4></td>
			</tr>
			<tr>
				<td align="right"><b>TOTAL PRICE:</b></td>
				<td><h4 data-total=""><?php echo ($oldpackageprice+$shippingcharge);?></h4></td>
			</tr>
			
			<tr>
				<td align="right"><b>COURIER COMPANY:</b></td>
				<td><h4><?php echo $couriercompany;?></h4></td>
			</tr>
			
			
			
			<tr>
				<td align="right"><b>ORDER STATUS:</b></td>
				<td>
					
					  <input type="hidden" name="id" value="<?php echo $_GET["id"]; ?>">
						<select name="orderstatus">
							<option value="PENDING" <?php echo ($orderstatus=="PENDING" ? "Selected": "");?> >PENDING</option>
							<option value="CANCEL" <?php echo ($orderstatus=="CANCEL" ? "Selected": "");?>>CANCEL</option>
							<option value="AWAITINGSHIPPING" <?php echo ($orderstatus=="AWAITINGSHIPPING" ? "Selected": "");?>>AWAITING SHIPPING</option>
						
						
						
						
						</select>

				</td>
			</tr>
			
			
			<tr align="center">
			    
			    <td colspan="7"><a href="view_order.php" class="btn btn-primary">BACK</a>
				<?php if(strtolower($oldpaymentmethod)==strtolower("ONLINE") && strtolower($paymentstatus)!=strtolower("DONE")){  ?>
				     <a href="edit_paymentmethod.php?id=<?php echo $id;?>" class="btn btn-primary">Change COD</a>
				<?php } ?>
				    <input type="submit" name="update_admin" class="btn btn-success" value="Update Admin Details"/></td>
			</tr>
		
		</table>
	
	
	</form>
	
</p>
</div>
</div>


<script>

	$(document).ready(function() {
		
		$('select[name=packageid]').change(function(){
			//alert();					
			var shipping =$(this).find("option:selected").data("shipping")
			var price =$(this).find("option:selected").data("price")
			$('h4[name=newprice]').val(price);
			$('h4[data-newprice]').text(price);
			$('h4[data-shipping]').text(shipping);
			$('h4[data-total]').text(Number(price)+Number(shipping));
			
		});
		
	} );

</script>

<?php include 'template/footer.php';?>
<?php ?>










 