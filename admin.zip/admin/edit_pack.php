<?php 
include 'session.php';

include 'includes/db.php';

?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
      include 'includes/db.php';
?>

    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				
	        	<p>
	        	
<?php 


if(isset($_GET['p_id'])){

	$get_id = $_GET['p_id']; 
	
	$get_pro = "select package.*,websites.web_domain from package INNER JOIN websites ON 
	                   package.p_web_id = websites.web_id where p_id='$get_id'";
	
	$run_pro = mysqli_query($con, $get_pro); 
	
	$i = 0;
	
	$row_pro=mysqli_fetch_array($run_pro);
		
		$p_id = $row_pro['p_id'];
	  	
		$package_name = $row_pro['p_name'];
		$package_web_id = $row_pro['p_web_id'];
		$package_cat_id = $row_pro['p_cat_id'];
		$package_price = $row_pro['p_price'];
		$package_pocharge = $row_pro['p_pocharge'];
		$package_shipping = $row_pro['p_shipping'];
		$package_status = $row_pro['p_status'];
		
}


 if(isset($_POST['update_package'])){

	//getting the text data from the fields

	$update_id = $p_id;
	
	$package_name = $_POST['p_name'];
	$package_web_id = $_POST['p_web_id'];
	$package_cat_id = $_POST['p_cat_id'];
	$package_price = $_POST['p_price'];
	$package_pocharge = $_POST['p_pocharge'];
	$package_shipping = $_POST['p_shipping'];
	$package_status = $_POST['p_status'];




	$update_pack = "update package set p_name='$package_name',p_cat_id='$package_cat_id',p_price='$package_price',p_pocharge='$package_pocharge',
					p_shipping='$package_shipping',p_status='$package_status' where p_id='$update_id'";

	$run_pack = mysqli_query($con, $update_pack);

	if($run_pack){
			
		echo "<script>alert('Package Details has been updated!')</script>";
			
		echo "<script>window.open('view_package.php','_self')</script>";
			
	}

}

?>

		<title>Update Website Details</title> 
		


	<form action="" method="post" enctype="multipart/form-data"> 
		
		<table align="center" width="795" border="2" bgcolor="#187eae">
			
			<tr align="center">
				<td colspan="7"><h2>Edit & Update Package Details</h2></td>
			</tr>
			
			<tr>
				<td align="right"><b>Package NAME:</b></td>
				<td><input type="text" name="p_name" size="60" value="<?php echo $package_name;?>"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>Website Name: </b></td>
				<td><input type="text" name="p_web_id" size="60" value="<?php echo $row_pro['web_domain'];?>" readonly /></td>
			</tr>
			<!--
			 <tr>
             <td align="right">Website Name: </td>
             <td>
             
             <select name="p_web_id" required />
             
             <?php/*
				 $get_cats = "select * from websites";
					
				$run_cats = mysqli_query($con,$get_cats);
					
				while ($row_cats=mysqli_fetch_array($run_cats))
				{
						
					$web_id = $row_cats['web_id'];
					$web_domain = $row_cats['web_domain'];
				
               
               echo "<option value='".$web_id."' ".  ($web_id==$package_web_id ? "Selected": "")  ."  >".$web_domain."</option>";
				}
                */
				?>
				
				</select>
				</td>
			</tr>

			-->
			
			  <tr>
             <td align="right"> Package Category: </td>
             <td>
             
             <select name="p_cat_id" required />
               <!-- <option>Select a Category</option> -->
				
					<?php
				 $get_cats = "select * from categories where c_web_id='$package_web_id'";
					
				$run_cats = mysqli_query($con,$get_cats);
					
				while ($row_cats=mysqli_fetch_array($run_cats))
				{
						
					$cat_id = $row_cats['cat_id'];
					$cat_title = $row_cats['cat_title'];
				
               echo "<option value='$cat_id' ". ($package_cat_id==$cat_id ? 'selected': '') ." >$cat_title</option>";
               
				}
                
				?>
				
             </select>
             
             </td>
           </tr>
           
		   
		   <!--
		    <tr>
             <td align="right"> Package Category: </td>
             <td>
             
             <select name="p_cat_id" id="p_cat_id" required />
                <option>Select a Category</option>
             </select>
             
             </td>
           </tr>
           
				<script type="text/javascript">
						$(function() {	
							$( "#p_web_id" ).change(function() {
								var web_id= $(this).find("option:selected").val();
										
								$( "#p_cat_id" ).find("option").remove();
								 $("#p_cat_id").load("get_cat.php?web_id=" + web_id);
							});
						});
				</script>
			-->
			<tr>
				<td align="right"><b>Package Price:</b></td>
				<td><input type="text" name="p_price" size="60" value="<?php echo $package_price;?>"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>PO Charge:</b></td>
				<td><input type="text" name="p_pocharge" size="60" value="<?php echo $package_pocharge;?>"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>Package Shipping:</b></td>
				<td><input type="text" name="p_shipping" size="60" value="<?php echo $package_shipping;?>"/>
				</td>
			</tr>
			
			<tr>
				<td align="right"><b>Package Status</b></td>
				<td>
				   <input type="radio" name="p_status" value="1" <?php echo ($package_status==1 ? "checked":"");?> />ACTIVE<br>
				   <input type="radio" name="p_status" value="0" <?php echo ($package_status==0 ? "checked":"");?> />INACTIVE
				</td>
			</tr>
			
			
			<tr align="center">
				<td colspan="7"><input type="submit" name="update_package" value="Update Package details"/></td>
			</tr>
		
		</table>
	
	
	</form>

 </p>
</div>
</div>



<?php include 'template/footer.php';?>
	
 











