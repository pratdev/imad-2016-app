<?php 

include 'includes/db.php';
session_start(); 

if(!isset($_SESSION['user_email'])){
	
	echo "<script>window.open('signin.php?not_admin=You are not an Admin!','_self')</script>";
}
else {

?>
<?php
            include("includes/db.php");

	if (isset($_GET['delete_cat'])){
		
		$delete_id= $_GET['delete_cat'];
		
		$delete_pro = "delete from categories where cat_id='$delete_id'";
		
		$run_delete = mysqli_query($con, $delete_pro);
		
		if($run_delete){
			
			//echo "<script>alert('Selected Website Details has been deleted!')</script>";
			header("location:view_cat.php");
			
		}
	}

?>
<?php }?>