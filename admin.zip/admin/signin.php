<?php 
@session_start();
include("includes/db.php"); 
function generateOTP($length = 6, $chars = '1234567890')
{
	$chars_length = (strlen($chars) - 1);
	$string = $chars{rand(0, $chars_length)};
	for ($i = 1; $i < $length; $i = strlen($string))
	{
		$r = $chars{rand(0, $chars_length)};
		if ($r != $string{$i - 1}) $string .=  $r;
	}
	return $string;
}	
	if(isset($_POST['login'])){
		
		$email = mysqli_real_escape_string($con, $_POST['email']);
		$pass = mysqli_real_escape_string($con, $_POST['password']);
	
	//$sel_user = "select * from admin where user_email='$email' AND user_pass='$pass'";
	
		//$run_user = mysqli_query($con, $sel_user); 

	
	
	
	
	$sql = "select * from admin where user_loginname='$email' AND user_pass='$pass'";

	
	$result=$con->query($sql);
if(!$row=$result->fetch_assoc()){

		echo "<script>alert('Password or Email is wrong, try again!')</script>";

//echo"Your username or password is not correct!";
//header("Location:index.php");
}
else{
	if($email==$row['user_loginname']){
		@session_start();
		$check_user=mysqli_num_rows($result);
		if($check_user==1 && $row['user_status']==1){
			
			
			
			
			
		$_SESSION['userid']=$row['user_id'];
		$_SESSION['user_name'] =$row['user_loginname'];
		$_SESSION['user_mobile']= $row['user_mobile'] ;
		//$_SESSION['u_web_id']= $row['u_web_id'] ;

		
//echo"Welcome admin!"; 
//include 'orderlist.php';


	//$_SESSION['user_email']=$email; 
	if($_SESSION['userid']!=1){
	$username = 'youremail@address.com';
	$hash = 'Your API hash';
	$apiKey='7Fok6gPjqoA-vo8T36MkAVdib4COP7YTGyNoRG3IHf';
	// Message details
	$numbers = array($_SESSION['user_mobile']); 
	$sender = urlencode('DEGNYT');
	$date = new DateTime();
	$otp= generateOTP();
	
	//$message = rawurlencode("256856 is One Time Password for satya.This OTP is valid for 6 minutes. OTP generated on: 07-01-2016 10:20PM");
	$message = rawurlencode($otp.' is One Time Password for '.$email.'.This OTP is valid for 6 minutes. OTP generated on: '.date_format($date, 'd/m/Y H:i:s'));
    //echo "256856 is One Time Password for satya.This OTP is valid for 6 minutes. OTP generated on: 07-01-2016 10:20PM";
	//echo $otp.' is One Time Password for '.$email.'.This OTP is valid for 6 minutes. OTP generated on: '.date_format($date, 'd/m/Y H:i:s');
	$numbers = implode(',', $numbers);
 
	// Prepare data for POST request
	$data = array( 'apiKey' => $apiKey, 'numbers' => $numbers, test=>"false",  "sender" => $sender, "message" => $message);
   try{
	   
	// Send the POST request with cURL
	$ch = curl_init('http://api.textlocal.in/send/');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$response = curl_exec($ch);
	curl_close($ch);
	
	// Process your response here
	//echo $response;
	//echo "<script>window.open('index.php?logged_in=You have successfully Logged in!','_self')</script>";
	    $result = json_decode($response);
		if( $result->status =="success" )
		{
			$_SESSION['otp']=$otp; 
			$_SESSION['count']=1; 
			$_SESSION['loggedin_time']=time();
			header("location:sendotp.php");
		}else{
			$errormsg='';
			if (count($result->errors) > 0) {
				foreach ($result->errors as $error) {
					  $errormsg= $error->message;
					   break;
					}
			}
			echo  $errormsg;
		}
     }catch (Exception $ex)
	 {
		 echo "<script>alert('Server Error')</script>";
	 }


             
//header("location:index.php?logged_in=You have successfully Logged in!");//$_SESSION['id']=$row['id'];
		}
		else{
			$_SESSION['user_id']= $_SESSION['userid'];
			$_SESSION['userid'] ="";
			$_SESSION['count']=0; 
			$_SESSION['loggedin_time']=time();
header("location:index.php");
		}
	
	}

//echo $_SESSION['user_id'];
	}
	
	else{
		echo "<script>alert('Password or Email is wrong, try again!')</script>";

	}
}

	}

	/* $check_user = mysqli_num_rows($run_user); 
	
	if($check_user==1){
		if($row_user=mysqli_fetch_array($sel_user,$con)){
	
	$_SESSION['user_id']=$row_user['user_id']; 
		}
	
	echo $_SESSION['user_id'];
	//header("location:index.php?logged_in=You have successfully Logged in!");
	
	//echo "<script>window.open('index.php?logged_in=You have successfully Logged in!','_self')</script>";
	
	}
	else {
	
	echo "<script>alert('Password or Email is wrong, try again!')</script>";
	
	}
	
	
	}
*/	
?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Minimal an Admin Panel Category Flat Bootstrap Responsive Website Template | Signin :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<script src="js/jquery.min.js"> </script>
<script src="js/bootstrap.min.js"> </script>
</head>
<body>
	<div class="login">
		<h1><a href="index.php">Genius Import Export </a></h1>
		<div class="login-bottom">
		<h2 style="color:red; text-align:center;"><?php echo @$_GET['not_admin']; ?></h2>

		<h2 style="color:red; text-align:center;"><?php echo @$_GET['logged_out']; ?></h2>
			
			<h2 style="text-align:center;" >Web Master Login</h2>
	         <h3 style="text-align:center;">Admin Login</h3>
	         
			<form method="post" action="signin.php">
			<div class="col-md-6">
				<div class="login-mail">
					<input type="text" name="email" placeholder="Email" required="">
					<i class="fa fa-envelope"></i>
				</div>
				<div class="login-mail">
					<input type="password" name="password" placeholder="Password" required="">
					<i class="fa fa-lock"></i>
				</div>
				
			
			</div>
			<div class="col-md-6 login-do">
				<label class="hvr-shutter-in-horizontal login-sub">
					<input type="submit" name="login" value="Generate">
			  </label>
					
			</div>
			
			<div class="clearfix"> </div>
			</form>
		</div>
	</div>
		<!---->
		<?php include'template/footer.php'; ?>

