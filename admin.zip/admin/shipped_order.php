<?php 
include 'session.php';
include 'includes/db.php';
@session_start(); 



?>
<?php include 'template/header.php';
     
?>
	<title>View Order Details | Genius Admin Panel</title>
	  
  <!-- 
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
--> 
<link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel='stylesheet' type='text/css' />

 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">

<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>


	  <script>
				$(document).ready(function() {
					$('#example').DataTable();
				} );

			  $( function() {
				//$( "#datepicker" ).datepicker();
				$( "#datepicker" ).datepicker({changeMonth:true,changeYear:true,numberOfMonths:[1,1]});
				$( "#datepicker" ).datepicker("option", "dateFormat", "dd-mm-yy");
				
				  
				  });
			 
			 $( function() {
				$( "#datepicker2" ).datepicker();
			  } );
		

	  </script>
 	 
 	 
 	 <?php  include 'template/sidebar.php';?>
	  <?php
			if(isset($_POST['submit'])){
				
				
			}
			else{
					 $_POST['byorder']="";
					 $_POST['bypost']="";
					 $_POST['orderstatus']="";
					 $_POST['paymentmethod']="";
					 $_POST['startdate']="";
					 $_POST['enddate']="";
					 $_POST['couriercompany']="";
					 $_POST['webisiteid']="";
			}
   ?>
   
 	 
 	  <div id="page-wrapper" class="gray-bg dashbard-1">
	  
     <!--Search options starts here-->
	 <h2>Order Search Options</h2>
      <br>
	  <div id="form">
	  <form method="post" action="<?php $_SERVER['PHP_SELF']; ?>">
		
		<table  align="left" width="100%" border="1" bgcolor="#187eae" >

		
        <tr>
                <td>WEBSITENAME:</td>
                <td><select name="webisiteid" >
						
					<option value="" <?php echo($_POST['webisiteid']=="" ? "Selected": "");?>  >ALL</option>	
				         <?php
							$sql="SELECT * FROM websites ";
							$result=$con->query($sql);
							while($row=mysqli_fetch_array($result)){
							$web_id=$row['web_id'];
							$web_domain= $row['web_domain'];
							
							
							echo "<option value='$web_id' ".  ($web_id==$_POST['webisiteid'] ? "Selected": "")  ." >".$web_domain."</option>";
							}
                        ?>
						</select>
						</td>
            </tr>
			<tr>
                <td>PAYMENT METHOD:</td>
                <td>
				<select name="paymentmethod">
				            <option value=""  >SELECT</option>
							<option value="ONLINE" <?php echo ($_POST['paymentmethod']=="ONLINE" ? "Selected": "");?>   >ONLINE</option>
							<option value="COD" <?php echo ($_POST['paymentmethod']=="COD" ? "Selected": "");?>   >COD</option>
							
						</select>
				</td>
			  </tr>
		<!--<tr>
                <td>ACTION:</td>
                <td>
				<select name="orderstatus">
											<option value=""  >SELECT</option>

							<option value="PENDING"  <?php //echo ($_POST['orderstatus']=="PENDING" ? "Selected": "");?> >PENDING</option>
							<option value="AWAITINGSHIPPING" <?php //echo ($_POST['orderstatus']=="AWAITINGSHIPPING" ? "Selected": "");?>  >AWAITING SHIPPING</option>
						    <option value="PACKING" <?php //echo ($_POST['orderstatus']=="PACKING" ? "Selected": "");?>  >PACKING</option>
							<option value="CONFIRM" <?php //echo ($_POST['orderstatus']=="CONFIRM" ? "Selected": "");?>  >CONFIRM</option>
							<option value="CANCEL"  <?php //echo ($_POST['orderstatus']=="CANCEL" ? "Selected": "");?> >CANCEL</option>

					</select>
			</td>
            </tr> -->
		<tr align="center">
		  <td colspan="7">
			  <input type="submit" class="btn btn-success" name="submit" value="Search" />
		   </td>
		   
		</tr>

        </table>
	 </form>
	 </div>
 <br>
 
	 <div>
	 <div class="row">
	     <!--PRINT INVOICE--> 
<?php
/*
	 <div class="col-sm-2">
	 <input type="button" class="btn btn-success" id="btn_invoice" data-filename="invoice.php" value="PRINT INVOICE">
	 </div>
	 
	     <!--PRINT DELHIVERY--> 

     <div class="col-sm-2">
	 <input type="button" class="btn btn-success" data-filename="delhivery.php" id="btn_delhivery" value="PRINT DELHIVERY">
	 </div>
	       <!--PRINT BLUEDART--> 

	 <div class="col-sm-2">
	 <input type="button" class="btn btn-success" id="btn_bluedart" data-filename="bluedart.php" value="PRINT BLUEDART">
	 </div> 
	 	       <!--PRINT POSTOFFICE--> 

	 <div class="col-sm-2">
	 <input type="button" class="btn btn-success" id="btn_postoffice" data-filename="postoffice.php"  value="PRINT POSTOFFICE">
	 </div> 
	 	       <!--PRINT MONEYORDER--> 

	 <div class="col-sm-2">
	 <input type="button" class="btn btn-success" id="btn_moneyorder" data-filename="moneyorder.php" value="PRINT MONEYORDER">
	 </div> 
	 */
	 $_POST['date']="";
	 ?>
	<div class="col-sm-2">

	
	<select name="ddlprint" class="form-control" >
	<option  value="">Select Print</option>
	<option  value="invoice.php">PRINT INVOICE</option>
	<option  value="fedex.php">PRINT FEDEX</option>
	<option  value="delhivery.php">PRINT DELHIVERY</option>
	<option  value="bluedart.php">PRINT BLUEDART</option>
	<option  value="postoffice.php">PRINT POSTOFFICE</option>
	<option  value="moneyorder.php">PRINT MONEYORDER</option>

	</select>
	
	 </div>
	 <div class="col-sm-2">
       
	   <p>Select Date:<input type="text" id="datepicker"> </p>
	
	  </div>
	<div class="col-sm-2">
	<button type="button" id="btnprint" class="btn btn-success" value="submit">PRINT</submit>
	  </div>
	 
	 </div>
	 </div>
	 
	 
    <!--Search options ends here--> 

       <div class="content-main">

 	<div class="blank">
 	
					
 		

  <h2>View All Shipping Order Details</h2>
  <br>
 <div style="overflow-x:auto;">
  <table id="example" class="display" cellspacing="0" width="100%">
 	
 <thead>
	<tr>
	    <th><input type="checkbox" name="check_selectall"  >All Select Order</input></th>
	    <th>Serial No.</th>
	    <th>Order Id</th>
	    <th>Website Name</th>
		<th>Order Status</th>
	    <th>Pincode</th>
		<th>Courier Company</th>		
		<th>Tracking Code</th>
		<th>Name</th>
		<th>Mobile No.</th>
		<th>Email</th>
		<th>Address</th>
		<th>State</th>
		<th>City</th>
        <th>Locality</th>
		<th>Payment Mode</th>
		<th>Payment Status</th>
		<th>Destinaion Service Area</th>
		<th>Destinaion Location</th>
		<th>Package Name</th>
		<th>Package Price</th>
		<th>Shipping Price</th>
		<th>Order Date&Time</th>
		
			
		<!--<th>Admin Response</th>
		
	    <th class="select">Command</th>
		
	    <th class="select">Payment Status</th>-->

   </tr>   
</thead>
 		<tbody>
	     
		<?php 
	    include ("includes/db.php");
	   
	  
	  	 if($_SESSION['user_id']==1){

	 $get_pro = "select orderdetails.*,package.*,states.states from orderdetails LEFT JOIN  package ON orderdetails.packageid=package.p_id
                   LEFT JOIN states ON states.stateid = orderdetails.state where orderdetails.orderstatus='SHIPPEDORDER' ";
		 }
		 else{
			 $get_pro = "select orderdetails.*,package.*,states.states from orderdetails LEFT JOIN  package ON orderdetails.packageid=package.p_id
                   LEFT JOIN states ON states.stateid = orderdetails.state where orderdetails.orderstatus='SHIPPEDORDER' and orderdetails.web_id in (select web_user_id from user_web_permission where user_id='".$_SESSION['user_id']."' and web_page_status=1) "; 
			 
		 }
		 
		 
		 
		 if(isset($_POST['submit']))
		{
			$get_pro= $get_pro. " AND orderdetails.web_id LIKE '%" . $_POST['webisiteid'] . "%'
				   AND orderdetails.paymentmethod LIKE '%" . $_POST['paymentmethod'] . "%'" ;
				  
        }
	    $get_pro= $get_pro ." ORDER BY id DESC"	;
	       		
	  //help for above query
	 // select  package.*, websites.web_domain from package INNER JOIN websites ON package.p_web_id=websites.web_id where websites.web_domain='$web_domain' 
	  
	  $run_pro = mysqli_query($con, $get_pro);
	  
	  $i=0;
	  
	  while ($row_pro=mysqli_fetch_array($run_pro))
	  {
			
			$web_domain =  $row_pro['web_domain'];	
		    
			$id = $row_pro['id'];

			$prefix = $row_pro['prefix'];
			$order_id = $row_pro['id'];
			//echo ($orderstatus=="PENDING" || $orderstatus=="CANCEL" ? $orderstatus: "");
		 //if( $orderstatuss=="PENDING" || $orderstatus=="CANCEL")
		// {    
		 //    echo $orderstatus;
		// }
            $orderstatus = $row_pro['orderstatus'];
			
			$pincode = $row_pro['pin'];

			$name =  $row_pro['name'];
			$number = $row_pro['mobile'];
			$email = $row_pro['email'];
			$address = $row_pro['address'];
			$states =  $row_pro['states'];
			$cityname = $row_pro['city'];
			$SelLocation = $row_pro['locality'];
			$package = $row_pro['p_name'];
			$packagecost = $row_pro['pack_price'];
			$bypost = $row_pro['bypost'];
			$paymentmethod = $row_pro['paymentmethod']; 
			$shippingcharge=$row_pro['shippingcharge'];
			
			$trackingcode=$row_pro['trackingcode'];
			$DestinationServiceArea = $row_pro['DestinationServiceArea'];
		    $DestinationLocation = $row_pro['DestinationLocation'];
			$couriercompany = $row_pro['couriercompany'];

			

            $OrderDate = $row_pro['OrderDate'];
	

		  // $pcode = $row_pro['PostalCode'];--not here on form i.e run time only
		
			$bgcolor="";

			if( $orderstatus=="PENDING" || $orderstatus=="NONE")
		  {
				$bgcolor="#DAFF33";
          }else if($orderstatus=="SHIPPING")
		  {
			   $bgcolor="#5AE012"; 
		  }
		  else if($orderstatus=="CANCEL")
		  {
			  $bgcolor="#FF5833";
		  }

		  
		 // For Duplicate Order Code
           $duplicatevalue=0;
		   $sql="select name from orderdetails where pin='$pincode' and mobile='$number'";
		   $result=$con->query($sql);
		   while($row=mysqli_fetch_array($result)){
				$duplicatename=$row['name'];
				$duplicatevalue++;
			}		  
		   if($duplicatevalue>=2){
		   $bgcolor="Plum";
			}  
		  
		  
		  
		  
		  
	    $i++;
	?>
	
	 <tr style=" background-color:<?php echo $bgcolor;?>">
	    <td><input type="checkbox" name="check_orderid"  value="<?php echo $row_pro['id'];?>"></td>
	 	<td><?php echo $i?></td>
		<td><a href="ship_edit_order.php?id=<?php echo $row_pro['id'];?>" class="btn btn-primary"><?php echo $prefix."-".$bypost."-".$order_id;?></a></td>
		<td><?php echo $web_domain?></td>
		<td><?php echo $orderstatus?></td>
	 	<td><?php echo $pincode?></td>
	 	<td><?php echo $couriercompany?></td>
        <td><?php echo $trackingcode?></td>			
	 	<td><?php echo $name?></td>
	 	<td><?php echo $number?></td>
	 	<td><?php echo $email?></td>
	 	<td><?php echo $address?></td>
	 	<td><?php echo $states?></td>
		<td><?php echo $cityname?></td>
		<td><?php echo $SelLocation?></td>
		<td><?php echo $paymentmethod?></td>
	    <td><?php echo $row_pro['paymentstatus']?></td>
		<td><?php echo $DestinationServiceArea?></td>
		<td><?php echo $DestinationLocation?></td>
		<td><?php echo $package?></td>
        <td><?php echo $packagecost?></td>
		<td><?php echo $shippingcharge?></td>
	    <td><?php echo $OrderDate?></td>
	 	


	 	<!--<td><a href="edit_order.php?id=<?php// echo $row_pro['id'];?>">Edit</a></td>
		  <td><a href="chek.php?id=<?php// echo $id;?>"><?php //echo "EDIT";?></a></td>
	 	<td><a href="javascript:getConfirmation('<?php //echo $order_id;?>')">Delete</a></td>-->
	 
	 	 </tr>
	
	
		<?php }  ?>
	
	 </tbody> 
	 
   </table>
</div>
      </div>
     <script type="text/javascript">
    $(document).ready(function() {
		/*
        $("input[data-filename]").click(function(){
			
			var file= $(this).data("filename");
			
            var orderids = [];
            $.each($("input[name='check_orderid']:checked"), function(){            
                orderids.push($(this).val());
            });  

			if (orderids.length)
			{
			window.location=file + '?id='+ orderids.join(",");
			}else{
					alert("Pls Select Order");
			}
        });
		*/
		
		 $("#btnprint").click(function(){
			
			 if ($("select[name=ddlprint]").val()=="")
			 {
				 alert("Select Print");
				  return false;
			 }
			 else if($("#datepicker").val()=="")
			 {
				alert("Select Date");
				  return false; 
			 }
			 else{
				//var file= $(this).data("filename");
				var file= $("select[name=ddlprint]").val();
				var orderids = [];
				$.each($("input[name='check_orderid']:checked"), function(){            
					orderids.push($(this).val());
				});  

				if (orderids.length)
				{
				window.location=file + '?id='+ orderids.join(",") + '&prntdate=' + $("#datepicker").val();
				}else{
						alert("Pls Select Order");
				}
			 }
        });
		
		
		$("input[name='check_selectall']").change(function(){
			
			$this = $(this);
			$.each($("input[name='check_orderid']"), function(){            
                if ($this.prop("checked"))
				{
					$(this).prop("checked", true);
				}else{
					$(this).prop("checked", false);
				}
            });
			
		 });
		 });
/*
        $("#btn_invoice").click(function(){
            var orderids = [];
            $.each($("input[name='check_orderid']:checked"), function(){            
                orderids.push($(this).val());
            });           
			if (orderids.length)
			{
			window.location='invoice.php?id='+ orderids.join(",");
			}else{
					alert("Pls Select Order");
			}
        });

        $("#btn_bluedart").click(function(){
            var orderids = [];
            $.each($("input[name='check_orderid']:checked"), function(){            
                orderids.push($(this).val());
            });           
			if (orderids.length)
			{
			window.location='bluedart.php?id='+ orderids.join(",");
			}else{
					alert("Pls Select Order");
			}
        });

        $("#btn_postoffice").click(function(){
            var orderids = [];
            $.each($("input[name='check_orderid']:checked"), function(){            
                orderids.push($(this).val());
            });           
			if (orderids.length)
			{
			window.location='postoffice.php?id='+ orderids.join(",");
			}else{
					alert("Pls Select Order");
			}
        });
			
			
			$('#selectall').click(function() {
    $(this.form.elements).filter(':checkbox').prop('checked', this.checked);
});

			
			

        $("#btn_moneyorder").click(function(){
            var orderids = [];
            $.each($("input[name='check_orderid']:checked"), function(){            
                orderids.push($(this).val());
            });           
			if (orderids.length)
			{
			window.location='moneyorder.php?id='+ orderids.join(",");
			}else{
					alert("Pls Select Order");
			}
        });
    });
	*/

</script>


     
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>
