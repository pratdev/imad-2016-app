<?php 
include 'session.php';

include 'includes/db.php';





?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
      include 'includes/db.php';
?>

    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				
	        	<p>
<?php 


if(isset($_GET['cat_id'])){

	$get_id = $_GET['cat_id']; 
	
	$get_pro = "select * from categories where cat_id='$get_id'";
	
	$run_pro = mysqli_query($con, $get_pro); 
	
	$i = 0;
	
	$row_pro=mysqli_fetch_array($run_pro);
		
		$cat_id = $row_pro['cat_id'];
	  	
		$cat_title = $row_pro['cat_title'];
		
		$web_id1 = $row_pro['c_web_id'];
		
}

			if(isset($_POST['update_category'])){
			
				//getting the text data from the fields
			
				$update_id = $cat_id;
				
				
				$cat_title = $_POST['cat_title'];
				$web_id = $_POST['c_web_id'];
			
			
			
			
				$update_cat = "update categories set cat_title='$cat_title' where cat_id='$update_id'";
			
				$run_cat = mysqli_query($con, $update_cat);
			
				if($run_cat){
						
					echo "<script>alert('Category Details has been updated!')</script>";
						
					echo "<script>window.open('view_cat.php','_self')</script>";
						
				}
			
			}

?>

		<title>Update Website Details</title> 
		

	



	<form action="" method="post" enctype="multipart/form-data"> 
		
		<table align="center" width="795" border="2" bgcolor="#187eae">
			
			<tr align="center">
				<td colspan="7"><h2>Edit & Update Category Details</h2></td>
			</tr>
			
			<tr>
				<td align="right"><b>Category Title:</b></td>
				<td><input type="text" name="cat_title" size="60" value="<?php echo $cat_title;?>"/></td>
			</tr>
			
			
			
			 <tr>
             <td align="right"> Website Name: </td>
             <td>
             
             <select name="web_id" required />
             
             <?php
				 $get_cats = "select * from websites";
					
				$run_cats = mysqli_query($con,$get_cats);
					
				while ($row_cats=mysqli_fetch_array($run_cats))
				{
						
					$web_id = $row_cats['web_id'];
					$web_domain = $row_cats['web_domain'];
				
               echo "<option value='$web_id' ". ($web_id1==$web_id ? 'selected': '') ." >$web_domain</option>";
               
				}
                
				?>
				
				</select>
				</td>
			</tr>
			
			
			<tr align="center">
				<td colspan="7"><input type="submit" name="update_category" value="Update Category details"/></td>
			</tr>
		
		</table>
	
	</form>

</p>
</div>
</div>



<?php include 'template/footer.php';?>
	










