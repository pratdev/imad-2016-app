<?php 
 include ("includes/db.php");
 if(isset($_GET['id'])){
 		$id = mysqli_real_escape_string($con,$_GET['id']);

	$sql="";
		
		  
		 $orderstatus="AWAITINGSHIPPING";
			
			 $sql=  " update orderdetails set orderstatus='".$orderstatus."' where id in ( ".$id.")";		
	
		
		if ($sql!="")
		{
			$result= mysqli_multi_query($con, $sql);
			
		}	
	header("location:await_shipped_order.php");	
		
 }		
		
		
		
		
		
		
		
		
		
		
		
 

//echo $DestinationServiceArea;


?>