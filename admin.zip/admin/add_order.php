<?php 
include 'session.php';
include 'includes/db.php';


?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
      include 'includes/db.php';

		$prefix = "";
		$pincode = "";
		$name =  "";
		$number = "";
		$email = "";
		$address =  "";
		$states =  "";
		$stateid = "";
		$cityname = "";
		$SelLocation =  "";
		$package =  "";
		$p_price = "";
		$paymentmethod = "";
		$couriercompany='';
		$bypost='';
		$web_id='';

		if (isset($_POST['sub'])){
			
			//getting the text data from the fields
			
			
			$packageid = mysqli_real_escape_string($con,$_POST['packageid']);
			
			$web_id =  mysqli_real_escape_string($con,$_POST['web_id']);	
			
			$pincode = mysqli_real_escape_string($con,$_POST['pin']);
			$name = mysqli_real_escape_string($con,$_POST['name']);
			$number = mysqli_real_escape_string($con,$_POST['mobile']);
			$email = mysqli_real_escape_string($con,$_POST['email']);
			$address = mysqli_real_escape_string($con,$_POST['address']);
			$states = mysqli_real_escape_string($con,$_POST['state']);
			$cityname = mysqli_real_escape_string($con,$_POST['city']);
			$SelLocation = mysqli_real_escape_string($con,$_POST['locality']);
			$paymentmethod = mysqli_real_escape_string($con,$_POST['paymentmethod']);
			
			
			$userid=$_SESSION['user_id'];
			$byorder="MO";
	        $orderstatus="AWAITINGSHIPPING";
			  
			 /*$sql = "select  package.*, websites.* from package INNER JOIN websites ON package.p_web_id=websites.web_id 
									  where package.p_id='$packageid'";*/
						
			$sql = "select  package.*, websites.*,categories.* from package INNER JOIN websites ON package.p_web_id=websites.web_id 
				INNER JOIN categories ON categories.cat_id = package.p_cat_id 
			    where package.p_id='$packageid'";		
			
			
			
			$result=$con->query($sql);
			if(	$result)
			{
				
				$row=$result->fetch_assoc();
				
				 $cat_title=$row['cat_title'];
				 
				$prefix = $row['prefix'];
				
				$web_domain = $row['web_domain'];
				//$web_id = $row['p_web_id'];
				$p_cat_id = $row['p_cat_id'];
				$p_price = $row['p_price'];
				
				//$shippingcharge = $row['p_shipping'];
			
			$sellnum=$row['sellnum'];
			
				$shippingstaus=$row['web_shipping'];
				$web_discount=$row['web_discount'];
				
					if($paymentmethod=="ONLINE"){
						
					   $paymentstatus="PENDING";
					   
					   $web_discount=$web_discount*(.01);
					   $web_discount=(1-$web_discount);
					   $p_price=round($p_price*($web_discount));
					   
					   $shippingcharge = "0";
					   
					   
			
				}
				else{
					 $paymentstatus="NONE";
					 
					 $paymentmethod="COD";
					 $shippingcharge = $row['p_shipping'];
				 }
					

				
				$sql="SELECT * FROM tbl_postalcode WHERE PostalCode='$pincode'";
				$result2=$con->query($sql);
				
				
				if($result2->num_rows){
					
					while($row=$result2->fetch_assoc()){
						$bypost="CR";
						if(strcasecmp($row['couriercompany'], "fedex")==0){
							$couriercompany="fedex";	
							break;
						}
						elseif(strcasecmp($row['couriercompany'], "Delhivery")==0){
							$couriercompany="Delhivery";
							break;
						}
						elseif(strcasecmp($row['couriercompany'], "bluedart")==0){
							$couriercompany="bluedart";
							break;
						}
					}
				}
				else{
					
					$couriercompany="POSTOFFICE";	
					$bypost="PO";
					
				}
				
				 $insert_user = "insert into orderdetails (pin,p_cat_id,web_id,orderstatus,web_domain,name,mobile,email,address,state,city,locality,
				 packageid,pack_price,paymentmethod,couriercompany,bypost,byorder,shippingcharge,paymentstatus,user_id,prefix) values
				('$pincode','$p_cat_id','$web_id','$orderstatus','$web_domain','$name','$number','$email','$address','$states','$cityname','$SelLocation',
				'$packageid','$p_price','$paymentmethod','$couriercompany','$bypost','$byorder','$shippingcharge','$paymentstatus','$userid','$prefix')";

			 $insert_u = mysqli_query($con, $insert_user);
			 
			if($insert_u){
				
			$id=mysqli_insert_id($con);		
			$orderid=$prefix."-".$bypost."-".$id;
			$username = 'youremail@address.com';
			$hash = 'Your API hash';
			$apiKey='7Fok6gPjqoA-vo8T36MkAVdib4COP7YTGyNoRG3IHf';
			$numbers = array($number); 
			$sender = urlencode('GENIUS');
			$date = new DateTime();
			//$message = rawurlencode("Dear ". $name ." Your Order of ". $cat_title  ." has been placed successfully on ". date_format($date, 'd/m/Y H:i') ." and Your ORDER ID: ". $orderid  ." and for more information you can call on this ". $sellnum  .".");
			$message = rawurlencode("Dear ". $name ." Your Order of ". $cat_title  ." has been placed successfully and your ORDER ID: ". $orderid  ."." ." it is being processed and for more information you can call on this number ". $sellnum  .".");
			$numbers = implode(',', $numbers);
			$data = array( 'apiKey' => $apiKey, 'numbers' => $numbers, 'test'=>"false",  "sender" => $sender, "message" => $message);
		   try{
			   
			
			$ch = curl_init('http://api.textlocal.in/send/');
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$response = curl_exec($ch);
			curl_close($ch);
			
			$result = json_decode($response);
			
			
			
			 }catch (Exception $ex)
			 {
				 echo "<script>alert('Server Error')</script>";
			 }

				
				
				
				echo "<script>alert('Order Successful!')</script>";
				echo "<script>window.open('await_shipped_order.php','_self')</script>";
			  }   
			}else{
				echo "<script type='text/javascript'>alert('error');</script>";
			}
		}

?>	  


    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				
	        	<p>


       <title>Add New Order</title>
	   
	   
   <script type="text/javascript">
		$(document).ready(function() {	
			$( "#pincode" ).change(function() {
			
			 $('#SelLocation').find("option").remove();
						 
						 var option=$('<option></option>').text("--Location--").val(" ");
						   $('#SelLocation').append(option);						
						 
			   var user_pin = $(this).val();
			   
				//$( "#states" ).find("option");
				
				$.ajax({
						  url: "test.php?user_pin=" + user_pin,
						  type: "GET",
						  dataType : "json",
						  contentType: "application/json; charset=utf-8",
						  beforeSend: function( xhr ) {	},
						  success: function (data) {	 console.log( data );
						  console.log(data["state"]);
							$( "#states" ).val(data["state"]);
							
						  console.log(data["cityname"]);
							$( "#cityname" ).val(data["cityname"]);
							
						 // console.log(data["Location"]);
						 //   $( "#Location" ).val();
						 var location=data["0"];
						if(location)
						{
						$('#SelLocation').show();
						 for(var i=0;i<location.length;i++)
						{
							var option=$('<option></option>').text(location[i]['Location']);
						  $('#SelLocation').append(option);
						  

						}}else
						{
							$('#SelLocation').hide();
						}
						
						  },
						  error: function () { alert("server error");
						  },
						  complete: function () {	}
						});
						
						  
				
				 //$("#states").load("test.php?user_pin=" + user_pin);
			});
		});
         </script>
     
   <form action="add_order.php" method="post" enctype="multipart/form-data">

     <table align="center" width="795" height="600" border="2" bgcolor="#187eae">

           <tr align="center">
             <td colspan="7"><h2>Add New Order Here</h2></td>
           </tr>
			
			<tr>
             <td align="right"> Website Name: </td>
             <td>
             
             <select name="web_id" id="p_web_id" required>
                <option value="">Select Website</option>
                
                <?php 
                
                $get_cats = "select * from websites";
                
                $run_cats = mysqli_query($con,$get_cats);
                
                   while ($row_cats=mysqli_fetch_array($run_cats)) {
                	 
                	$web_id  = $row_cats['web_id'];
                	$web_domain = $row_cats['web_domain'];
                
                	echo "<option value='$web_id'>$web_domain</option>";
                
                	 
                }
                
                ?>
                
             </select>
             
             </td>
           </tr>
		   
		    <tr>
             <td align="right"> Select Package: </td>
             <td>
             
             <select name="packageid" id="packageid" required >
                <option value="">Select Package</option>
             </select>
             
             </td>
           </tr>
           
          
			<script type="text/javascript">
					$(function() {	
						$( "#p_web_id" ).change(function() {
							var web_id= $(this).find("option:selected").val();
									
							$( "#packageid" ).find("option").remove();
							 $("#packageid").load("get_pack.php?web_id=" + web_id);
						});
					});
			</script>
			
		 <tr>
		    <td align="right"> Pincode: </td>
             
		 <td>
			<input type="text" name="pin" maxlength="6" id="pincode" placeholder="Enter your pincode" value="<?php echo $pincode;?>" required/><br/>
		 </td>
      </tr>		
			
				<tr>
		         <td align="right"> Name: </td>
              <td>
				<input type="text" name="name" id="name" placeholder="Your name"  value="<?php echo $name;?>" required/><br/>
				</td>
				</tr>
				
				<tr>
		         <td align="right"> Mobile: </td>
              <td>
			    <input type="text" name="mobile" size="50" maxlength="10" id="number" placeholder="Mobile No/Without 0 or +91" value="<?php echo $number;?>" required/><br/>
				</td>
				</tr>
				
				<tr>
		         <td align="right"> Email: </td>
                <td>
                    <input type="email"  name="email" type="text" id="email" placeholder="E-mail"  value="<?php echo $email;?>"  /><br>
					 Order details would be sent to this email
				</td>
				</tr>
				
			  <tr>
		         <td align="right"> Address: </td>
              <td>
				
				<textarea name="address" rows="2" cols="20" id="address" placeholder="Type :- Delivery Address" style="height:70px;" required/><?php echo $address;?></textarea>
			  </td>
				</tr>
				
				
				
			<tr>
		         <td align="right"> State: </td>
              <td>	
               
			    <?php echo "<option value='$stateid'>$states</option>";	 ?>

			    <select name="state" id="states" required />

				<option value=" ">--Select--</option>
				<option value="1">Andaman and Nicobar Islands</option>
				<option value="2">Andhra Pradesh</option>
				<option value="3">Arunachal Pradesh</option>
				<option value="4">Assam</option>
				<option value="5">Bihar</option>
				<option value="6">Chandigarh</option>
				<option value="7">Chhattisgarh</option>
				<option value="8">Dadra and Nagar Haveli</option>
				<option value="9">Daman and Diu</option>
				<option value="10">Delhi</option>
				<option value="11">Goa</option>
				<option value="12">Gujarat</option>
				<option value="13">Haryana</option>
				<option value="14">Himachal Pradesh</option>
				<option value="15">Jammu and Kashmir</option>
				<option value="16">Jharkhand</option>
				<option value="17">Karnataka</option>
				<option value="18">Kerala</option>
				<option value="19">Lakshadweep</option>
				<option value="20">Madhya Pradesh</option>
				<option value="21">Maharashtra</option>
				<option value="22">Manipur</option>
				<option value="23">Meghalaya</option>
				<option value="24">Mizoram</option>
				<option value="25">Nagaland</option>
				<option value="26">Orissa</option>
				<option value="27">Puducherry</option>
				<option value="28">Punjab</option>
				<option value="29">Rajasthan</option>
				<option value="30">Sikkim</option>
				<option value="31">Tamil Nadu</option>
				<option value="32">Telangana</option>
				<option value="33">Tripura</option>
				<option value="34">Union Territory</option>
				<option value="35">Uttar Pradesh</option>
				<option value="36">Uttarakhand</option>
				<option value="37">West Bengal</option>
        </td>
	</select><br>
	</tr>
	
	 <tr>
		       <td align="right"> City: </td>
              <td>
	<input type="text" name="city" id="cityname" placeholder="Enter your cityname" value="<?php echo $cityname;?>" required/>
		<br>
		</td>
    </tr>
	
	 <tr>
		 <td align="right"> Location: </td>
          <td>	
	<select name="locality" id="SelLocation" required >
			<option value="">--Location--</option>
	</select>
      <br>	
	  </td>
	</tr>
			
            
		  <tr>
		    <td align="right"> Payment Method: </td>
             
		 <td>
		   <select name="paymentmethod" id="paymentmethod" required >
			     <option value="">Select Payment Type</option>
				   <option value="COD">Cash On Delivery</option>
		   </select>	   
		 </td>
		  </tr>		   
           
           <tr align="center">
             <td colspan="7"><input type="submit" name="sub" id="sub" value="Submit Order" /></td>
           </tr>
           
           
           
     </table> 

</form>


   </p>
	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>

