<?php 

include 'includes/db.php';
@session_start(); 

if(!isset($_SESSION['user_email'])){
	
	echo "<script>window.open('signin.php?not_admin=You are not an Admin!','_self')</script>";
}
else {

?>   
   <option>Select a Category</option>
                
				
				<?php 
                  include ('includes/db.php');
	  
	   if (isset($_GET['web_id'])){
		   
                $web_id = $_GET['web_id'];
				
				$web_id = mysqli_real_escape_string($con, $web_id);
               
			if (!is_null($web_id) and !empty($web_id)) {
               
				  //echo $web_id ;
                $get_cats = "SELECT * from package where p_id='$web_id'";
                         
                
                $run_cats = mysqli_query($con,$get_cats);
                
                   while ($row_cats=mysqli_fetch_array($run_cats)) {
                	 
                	 $packagename=$row_cats['p_name'];
					 $packageid= $row_cats['p_id'];
					 $packagecost=$row_cats['p_price'];
						
					 echo "<option value='$packageid'>$packagecost</option>";
					
                	 
                }
			  }
				  }
								
                ?>
                
                
                <?php }?>