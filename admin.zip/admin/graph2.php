<?php
$link=mysql_connect('localhost','root','');
$db_link=mysql_select_db('prateek',$link);

$query = "Select * from height where gender=1";
$qresult = mysql_query($query);


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
 <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
 <script type="text/javascript">
 google.charts.load('current', {'packages':['corechart','line']});
 google.charts.setOnLoadCallback(drawChart);
 function drawChart() {

   var data = google.visualization.arrayToDataTable([
         ['age','3_perc','5_perc','10_perc','25_perc','50_perc','75_perc','90_perc','95_perc','97_perc'],
         <?php while ($res = mysql_fetch_assoc($qresult)){?>
         ['<?php echo $res['age']?>',<?php echo $res['3_perc']?>,<?php echo $res['5_perc']?>,<?php echo $res['10_perc']?>,
        		 <?php echo $res['25_perc']?>,<?php echo $res['50_perc']?>,<?php echo $res['75_perc']?>,<?php echo $res['90_perc']?>,
        				 <?php echo $res['95_perc']?>,<?php echo $res['97_perc']?>],         
         <?php }?>
   ]);
   var options = {
     title: 'Height Statics',
	 
   };


   var logOptions = {

		   title: 'Height Statics',
	       
	        legend: 'true',	        
	         hAxis: {
	          title: 'AGE',
	        	  ticks: [<?php echo $res['age']?>]   
	        },
               vAxis: {
				   title: 'Labels',
               viewWindowMode: 'explicit',
           	    viewWindow: {
           	        max: 200,
           	        min: 60
           	    },
	    ticks: [60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 180, 190] // display labels every 20
	}
   };

   
   var chart = new google.visualization.LineChart(document.getElementById('chart_div'));

   chart.draw(data, logOptions);
 }

//Make the charts responsive
	 jQuery(document).ready(function(){
		 jQuery(window).resize(function(){
			 drawchart();
	 });
 }); 
 
  </script>


</head>

<body>

<div id="chart_div" style="width: 1500px; height: 800px;"></div>

</body>
</html>
