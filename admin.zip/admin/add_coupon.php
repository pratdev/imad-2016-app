<?php 
				
include 'session.php';
include 'includes/db.php';
if(isset($_POST['submit'])){
	$coup_name=mysqli_real_escape_string($con,$_POST['coup_name']);
	$coup_value=mysqli_real_escape_string($con,$_POST['coup_value']);
	$coup_type=mysqli_real_escape_string($con,$_POST['coup_type']);
	$coup_createdate=mysqli_real_escape_string($con,$_POST['coup_createdate']);
	$coup_expirydate=mysqli_real_escape_string($con,$_POST['coup_expirydate']);
	
	include 'includes/db.php';
	$sql="select * from coupondetails where coup_name='$coup_name'";
	//echo$sql;
	$result=$con->query($sql);
	
	if($row=$result->fetch_assoc()){
    echo "<script>alert('DUPLICATE COUPON NAME ALREADY EXISTS!')</script>";

	
	}
	else{
	$sql="insert into coupondetails (coup_name, coup_value, coup_type, coup_issue_date,coup_end_date) 
	values('$coup_name','$coup_value','$coup_type','$coup_createdate','$coup_expirydate')";	
	//echo $sql;
	$result=$con->query($sql);	
	echo "<script>alert('You have added coupon successfully!')</script>";
	
		
	}
	
	
	
	
	
	
     }
    else{
	
	$_POST['coup_name']="";
	$_POST['coup_value']="";
	$_POST['coup_type']="";
	$_POST['coup_createdate']="";	
	$_POST['coup_expirydate']="";
    }
	
   ?>   



<!DOCTYPE HTML>
<html>
  <head>
    <link href="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.2.2/css/bootstrap-combined.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" media="screen"
     href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
	     
  


	 

	 

	 
	 
	 
	 
	 
	 
	 
	 
	 
  </head>
<body>

<?php include 'template/header.php';
     
?>
	<title>View Order Details | Genius Admin Panel</title>
	  
  <!-- 
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
--> 
<link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel='stylesheet' type='text/css' />

 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">

<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
	    <script type="text/javascript"
     src="http://tarruda.github.com/bootstrap-datetimepicker/assets/js/bootstrap-datetimepicker.min.js">
    </script>
	  <script>
				$(document).ready(function() {
					$('#example').DataTable();
				} );


			  $( function() {
				$( "#datepicker" ).datepicker();
			  } );
			  
			  
			 $( function() {
				$( "#datepicker2" ).datepicker();
			  } );
		

	  </script>

	  <!--<script type="text/javascript">
			$(document).ready(function(){
		          $( "#target" ).click(function() {
						$("#myModal").modal('show');
					});});
	 </script>-->
 	 
 	 
 	 <?php 
	 include 'template/sidebar.php';
?>
	 <?php/*
	 if(isset($_POST['submit'])) {
        $sql = mysql_query("SELECT * FROM table WHERE name LIKE '%" . $_POST['name'] . "%'
                   OR address LIKE '%" . $_POST['address'] . "%'
                   OR city LIKE '%" . $_POST['city'] . "%'
                   OR state LIKE '%" . $_POST['state'] . "%'
                   OR zip LIKE '%" . $_POST['zip'] . "%'");
    }*/
?>



 	  <div id="page-wrapper" class="gray-bg dashbard-1">
	  
     <!--Search options starts here-->
	 <h1 style="color:green; font-family:arial;" ><b>ADD COUPON</b></h1>
      
	  <div id="form">
	 <form method="post" action="<?php $_SERVER['PHP_SELF']; ?>" >
		<table  align="left" width="100%" border="1" bgcolor="#187eae">
<tr>
                <td align="left"><b>COUPON NAME:</b></td>
			<td colspan="4"><input type="text" name="coup_name" size="60" value=""/></td>
								
								
								
								
								
            </tr>
           
            <tr>
			
			<td align="left"><b>COUPON VALUE:</b></td>
			<td><input type="text" name="coup_value" size="60" value=""/></td>	
			
			
                <td align="left"><b>COUPON TYPE:</b></td>
			<td>
			<select name="coup_type"  >
			<option value="percentage">Percentage(%)</option>
			<option value="FLAT">FLAT</option>		
			</select>
			</td>
			
				
				
				
            </tr>
           
		
			
			
			
			
			
			
			
			

			
			
			<tr>
           <td align="left"><b>COUPON CREATE DATE:</b></td>
                <td>
				    <div id="datetimepicker" class="input-append date">
      <input type="text" class="fc-calendar" name="coup_createdate" value=""  required /></input>
      <span class="add-on">
        <i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
      </span>
    </div>
				
				
				
				</td>
				 <td align="left"><b>COUPON EXPIRY DATE:</b></td>
                <td>
				
				<div id="1datetimepicker" class="input-append date">
      <input type="text" name="coup_expirydate" value="" required /  ></input>
      <span class="add-on">
        <i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
      </span>
    </div>
	 
				
				
				
				</td>
				
				
				
				
				
				
				 
				
				
				 
            </tr>
			
			
			
	
	
			
			
			
			
			<tr>
			<td colspan="4" align="center"><input type="submit" name="submit" value="Add Coupon" class="btn btn-success"/></td>
			
			</tr>
			
		
			
			
			
			<?php// echo $_POST['startdate']?>
						<?php// echo $_POST['enddate']?>

        </form>
    </table>
	 
	 </div>
	 
    <!--Search options ends here--> 

       <div class="content-main">

 	<div class="blank">
 	
					
 		

  <h3 style="color:green;font-family:arial">COUPONS ARE BELOW</h3>
  <br>
 <div style="overflow-x:auto;">
<table id="example" class="display" cellspacing="0" width="100%">
 	
 <thead>
	<tr>
	    <th>Serial No.</th>
	    <th>COUPON ID</th>
	    <th>COUPON NAME</th>
		<th>COUPON VALUE</th>
	    <th>COUPON TYPE</th>
		<th>COUPON CREATE DATE</th>
		<th>COUPON EXPIRY DATE</th>
		
		
			
		

   </tr>   
</thead>
 		<tbody>
	     
		<?php 
		
	    include ("includes/db.php");
		   // $user_id=29;
          
			
			// $n=0;
			
		
	    $get_pro= "select * from coupondetails order by coup_id desc";
	//echo$sql;
	  //help for above query
	 // select  package.*, websites.web_domain from package INNER JOIN websites ON package.p_web_id=websites.web_id where websites.web_domain='$web_domain' 
			 
	  $run_pro = mysqli_query($con, $get_pro);
			 	 
	  $i=0;
	  
	  while ($row_pro=mysqli_fetch_array($run_pro))
	  {
		$coup_id=$row_pro['coup_id'];	
		$coupn_name=$row_pro['coup_name'];	
		$coup_value=$row_pro['coup_value'];	
		$coup_type=$row_pro['coup_type'];	
		$coup_issue_date=$row_pro['coup_issue_date'];	
		$coup_end_date=$row_pro['coup_expiry_date'];	

	
	$i++;
	?>
	
	
	 <tr style=" background-color:<?php echo $bgcolor;?>">
	 	<td><?php echo $i?></td>
		<td><?php echo $coup_id;?></td>
		<td><?php echo $coupn_name?></td>
		<td><?php echo $coup_value?></td>
	 	<td><?php echo $coup_type?></td>
	 	<td><?php echo $coup_issue_date?></td>
	 	<td><?php echo $coup_end_date?></td>
	 	
	 	


	 	<!--<td><a href="edit_order.php?id=<?php// echo $row_pro['id'];?>">Edit</a></td>
		  <td><a href="chek.php?id=<?php// echo $id;?>"><?php //echo "EDIT";?></a></td>
	 	<td><a href="javascript:getConfirmation('<?php //echo $order_id;?>')">Delete</a></td>-->
	 
	 	 </tr>
	
	
			 <?php }  ?>
	
	 </tbody> 
	 
   </table>
</div>
       </div>
     
      
 
    <script type="text/javascript">
      $('#datetimepicker').datetimepicker({
        format: 'yyyy-MM-dd hh:mm:ss',
       
      });
    </script>
	
	
	 
	
    
    <script type="text/javascript">
      $('#1datetimepicker').datetimepicker({
        format: 'yyyy-MM-dd hh:mm:ss',
		
       
      });
    </script>
	  
	  
	  
	  
     
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>
<?php ?> 
</body>
</html>	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 