<?php

require_once 'includes/db.php';
session_start();



if(!isset($_SESSION['userid'])){	
	if($_SESSION['userid']=="")
	{
		header("location:logout.php");
	}
}


 $errmsg ="";
	if(isset($_POST['resend'])){
		
	//$_SESSION['user_id']=$_SESSION['userid']
	
	$username = 'youremail@address.com';
	$hash = 'Your API hash';
	$apiKey='7Fok6gPjqoA-vo8T36MkAVdib4COP7YTGyNoRG3IHf';
	// Message details
	$numbers = array($_SESSION['user_mobile']); 
	$sender = urlencode('DEGNYT');
	$date = new DateTime();

	
	
	$message = rawurlencode($_SESSION['otp'].' is One Time Password for '.$_SESSION['user_name'].'.This OTP is valid for 6 minutes. OTP generated on: '.date_format($date, 'd/m/Y H:i:s'));

	$numbers = implode(',', $numbers);
 
	// Prepare data for POST request
	$data = array( 'apiKey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
 
	// Send the POST request with cURL
	$ch = curl_init('http://api.textlocal.in/send/');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$response = curl_exec($ch);
	curl_close($ch);
	

	$result = json_decode($response);
	/*
		if( $result->status =="success" ){
			
			$_SESSION['count']=2; 
			$_SESSION['loggedin_time']=$date;
		}else{
			$errormsg='';
			if (count($result->errors) > 0) {
				foreach ($result->errors as $error) {
					  $errormsg= $error->message;
					   break;
					}
			}
			//echo  $errormsg;
		}
		*/
	}
	
	if(isset($_POST['login'])){
		
		if ($_SESSION['otp'] ==$_POST['otp'])
		{
			
			$_SESSION['user_id']= $_SESSION['userid'];
			$_SESSION['userid'] ="";
			$_SESSION['count']=0; 
			$_SESSION['loggedin_time']=time();
			header("location:index.php");
		}else{
			
			$errmsg ="Invalid OTP";
		}
		
	}

?>


<!DOCTYPE HTML>
<html>
<head>
<title>Minimal an Admin Panel Category Flat Bootstrap Responsive Website Template | Signin :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<script src="js/jquery.min.js"> </script>
<script src="js/bootstrap.min.js"> </script>
</head>
<body>
	<div class="login">
		<h1><a href="index.php">Genius Import Export </a></h1>
		<div class="login-bottom">	         
			
			<div class="row">
			<form method="post" action="sendotp.php">
			<div class="col-md-12">
				<div class="login-mail">
					<input type="text" name="otp" placeholder="OTP" required="">
					<i class="fa fa-lock"></i>
				</div>						
			</div>
			</div>
		    <div class="row">
				<div class="col-md-6 login-do">
				<label class="hvr-shutter-in-horizontal login-sub">
					<input type="submit" name="login" value="Submit">
			  </label>
				</div>
				</form>
				<div class="col-md-6 login-do">
				<form method="post" action="sendotp.php">
				<label class="hvr-shutter-in-horizontal login-sub">				
				<?php if($_SESSION['count']<2) { ?>
					<input type="submit" name="resend" value="Resend OTP">
					<?php }?>
			  </label>
			  </form>
				</div>
			</div>			
			<div class="clearfix"> </div>
			
		</div>
	</div>
	
<?php include'template/footer.php'; ?>