<?php 
include 'session.php';

include 'includes/db.php';

$get_id ="";
$user_id ="";
if(isset($_GET['user_id'])){

	$get_id = $_GET['user_id']; 
	
	$get_pro = "select * from admin where user_id='$get_id'";
	
	//$get_pro="select admin.*,user_web_permission.* from admin 
	//left join user_web_permission on admin.user_id=user_web_permission.web_user_id where admin.user_id='$get_id'";
	
	$run_pro = mysqli_query($con, $get_pro); 
	
	$i = 0;
	
	$row_pro=mysqli_fetch_array($run_pro);
		
		$user_id = $row_pro['user_id'];
	  	
	  	$user_lname = $row_pro['user_loginname'];
	  	$user_fname = $row_pro['user_fullname'];
	  	$user_pass = $row_pro['user_pass'];
	  	$user_email = $row_pro['user_email'];
	  	$user_mob = $row_pro['user_mobile'];
	  	$user_add = $row_pro['user_address'];
	  	$user_status = $row_pro['user_status'];
		
		
}


	if(isset($_POST['update_user'])){
	
		//getting the text data from the fields
		$update_id = $user_id;
		
		$user_lname = mysqli_real_escape_string($con,$_POST['u_lname']);
		$user_fname = mysqli_real_escape_string($con,$_POST['u_fname']);
		$user_pass = mysqli_real_escape_string($con,$_POST['u_pass']);
		$user_email = mysqli_real_escape_string($con,$_POST['u_email']);
		$user_mob = mysqli_real_escape_string($con,$_POST['u_mob']);
		$user_add = mysqli_real_escape_string($con,$_POST['u_add']);
		$user_status = mysqli_real_escape_string($con,$_POST['u_status']);
		
		
		
		
	
		 $update_user = "update admin set user_fullname='$user_fname',user_pass='$user_pass',user_email='$user_email',user_mobile='$user_mob',
		 user_address='$user_add', user_status='$user_status' where user_id='$update_id'";
		 
		 $run_user = mysqli_query($con, $update_user);
		 
		if($run_user){
	    $arraypage = $_POST['test'];
// echo var_dump($arraypage);
			 

		$sql="";	 
		$webarraypage = $_POST['testu'];
		foreach($webarraypage as $key2 => $value2)
		{  

		$web_id= $key2;
		$webstatus=0;
		$webtype="";


		foreach($value2 as $key3 => $value3)
		{			
		$webstatus= $value3 ;
		$webtype=$key3;
		}
		if ($webtype=="ol")
		{
		$sql= $sql ." update user_web_permission set web_page_status='$webstatus' where user_id='$update_id' and web_user_id='$web_id' ;";		

		}else
		{
		$sql = $sql ." insert into user_web_permission(web_user_id,user_id,web_page_status) values('$web_id','$update_id','$webstatus') ; ";	

		}
		}
			 
			 
			 
			 
			 

		foreach($arraypage as $key => $value)
		{  
		// // echo 'page id -'. $key . '<br />';
		// // echo 'page id -'. $key . '<br />';
		$page_id= $key;
		$status=0;
		$type="";


		foreach($value as $key1 => $value1)
		{			
		$status= $value1 ;
		$type=$key1;
		}
		if ($type=="old")
		{
		$sql= $sql ." update tbl_page_permission set status='$status' where user_id='$update_id' and page_id='$page_id' ;";		

		}else
		{
		$sql = $sql ." insert into tbl_page_permission(page_id,user_id,status) values('$page_id','$update_id','$status') ; ";	

		}
		}
		//echo "</br>". $sql;
		if ($sql!="")
		{
			$result= mysqli_multi_query($con, $sql);
			//$result=$con->query($sql);
		}
			 
			 
			 
		 
	 echo "<script>alert('User Details has been updated!')</script>";
		 
		 echo "<script>window.location= window.location.href;</script>";
		 
		 }
		
	}

include 'template/header.php';
include 'template/sidebar.php';

?>

    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				
	        	<p>


		<title>Update User Details</title> 
		

	
	



	<form action="" method="post" enctype="multipart/form-data"> 
		
		<table align="center" width="795" border="2" bgcolor="#187eae">
			
			<tr align="center">
				<td colspan="7"><h2>Edit & Update User Details</h2></td>
			</tr>
			
			<tr>
				<td align="right"><b>User Login Name:</b></td>
				<td><input type="text" name="u_lname" readonly size="60" value="<?php echo $user_lname;?>"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>User Full Name:</b></td>
				<td><input type="text" name="u_fname" size="60" value="<?php echo $user_fname;?>"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>User Password:</b></td>
				<td><input type="text" name="u_pass" size="60" value="<?php echo $user_pass;?>"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>User Email:</b></td>
				<td><input type="text" name="u_email" size="60" value="<?php echo $user_email;?>"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>User Mobile No.:</b></td>
				<td><input type="text" name="u_mob" size="60" value="<?php echo $user_mob;?>"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>User Address:</b></td>
				<td><input type="text" name="u_add" size="60" value="<?php echo $user_add;?>"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>User Status:</b></td>
				<td><input type="radio" name="u_status" value="1" <?php echo ($user_status==1 ? "checked":"");?> />Active<br>
				    <input type="radio" name="u_status" value="0" <?php echo ($user_status==0 ? "checked":"");?> />Inactive</td>
			</tr>
			
			
			  <tr align="center">
				<td colspan="7"><strong> User Website Permission</strong></td>
			</tr>
		   </tr>
		   <?php
		 //  $sql="select * from websites";
		   $sql="select user_web_permission.*,websites.* from user_web_permission 
	left join websites on user_web_permission.web_user_id=websites.web_id where user_web_permission.user_id='$get_id'";
		 //  $result=$con->query($sql);
		 $result= mysqli_query($con, $sql);
		 if (mysqli_num_rows($result)>0){
           while($row=mysqli_fetch_array($result)){
		   $web_name =$row['web_name'];
           $web_id =$row['web_id'];
           $web_page_status=$row['web_page_status'];
           
		   
		   ?>
		   
		   
		   
		   
		   <tr>
        <td align="left"><?php echo $web_name; ?>: </td>
        <td>
        <input type="radio" name="testu[<?php echo$web_id; ?>][ol]" value="1" <?php echo ($web_page_status==1 ? "checked":""); ?> required/>Active<br>
  		<input type="radio" name="testu[<?php echo$web_id; ?>][ol]" value="0" <?php echo ($web_page_status==0 ? "checked":""); ?> required/>Inactive<br>
        </td>
    </tr>
		   
		 <?php  }  } 
		 
		 
		 
		 $sql="select  * from websites  
		    WHERE  websites.web_id not in (select user_web_permission.web_user_id from user_web_permission where user_web_permission.user_id= '".$_GET['user_id'] ."' )
			order by websites.web_id ; ";
		  
		  $result=$con->query($sql);
		  if (!$result)
		  {
			  echo $con->error;
		  }
		  ?>
		  	</tr>
		<tr align="center">
		<td colspan="7">New User Website Permission</td>
	</tr>
<?php 		  
if (mysqli_num_rows($result)>0){
while($row=mysqli_fetch_array($result)){ 
	$web_name=$row['web_name'];
	//$filename=$row['file_name'];
	$web_id=$row['web_id'];
	
		  
		  ?>		
			<tr>
        <td align="left"><?php echo $web_name; ?>: </td>
        <td>
        <input type="radio" name="testu[<?php echo$web_id; ?>][ne]" value="1" checked required/>Active<br>
  		<input type="radio" name="testu[<?php echo$web_id; ?>][ne]" value="0"   required/>Inactive<br>
        </td>
    </tr>
	 
<?php   } }?>
			
			
			
				<tr align="center">
				<td colspan="7"><strong> Page permission</strong></td>
			</tr>
			<?php    
	
		 $sql="select main_menu_master.menu_name ,tbl_page_permission.status,tbl_page_master.* from tbl_page_master  
		 inner JOIN tbl_page_permission   ON tbl_page_permission.page_id=tbl_page_master.id
		 inner JOIN main_menu_master   ON main_menu_master.menu_id=tbl_page_master.menu_id
		 WHERE   tbl_page_permission.user_id= '".$_GET['user_id'] ."'  order by tbl_page_master.menu_id  ;";
 
	$result=$con->query($sql);
	$menu_id ='';
	$oldmenu_id='';
if (mysqli_num_rows($result)>0){
while($row=mysqli_fetch_array($result)){ 
	$pagename=$row['page_name'];
	//$filename=$row['file_name'];
	$id=$row['id'];
	$menu_id =$row['menu_id'];	
	
	$pagestatus = $row['status'];	 
	if ($menu_id!=$oldmenu_id)
	{
		 $oldmenu_id =$row['menu_id'];
	?>
	</tr>
		<tr align="center">
		<td colspan="7"><?php echo $row['menu_name']; ?></td>
	</tr>
	<?php }
		if ($oldmenu_id=='')
		{
			 $oldmenu_id =$row['menu_id'];
		}
	?>
	
	
	<tr>
        <td align="left"><?php echo $pagename; ?>: </td>
        <td>
        <input type="radio" name="test[<?php echo$id; ?>][old]" value="1"  <?php echo ($pagestatus==1 ? "checked":""); ?> required/>Active<br>
  		<input type="radio" name="test[<?php echo$id; ?>][old]" value="0"  <?php echo ($pagestatus==0 ? "checked":""); ?> required/>Inactive<br>
        </td>
    </tr>
	 
<?php   }  }

			$sql="select  * from tbl_page_master  
		    WHERE  tbl_page_master.id not in (select tbl_page_permission.page_id from tbl_page_permission where tbl_page_permission.user_id= '".$_GET['user_id'] ."' )
			order by tbl_page_master.menu_id ; ";
		  
		  $result=$con->query($sql);
		  if (!$result)
		  {
			  echo $con->error;
		  }
		  ?>
		  	</tr>
		<tr align="center">
		<td colspan="7">New Page Permission</td>
	</tr>
<?php 		  
if (mysqli_num_rows($result)>0){
while($row=mysqli_fetch_array($result)){ 
	$pagename=$row['page_name'];
	//$filename=$row['file_name'];
	$id=$row['id'];
	
		  
		  ?>		
			<tr>
        <td align="left"><?php echo $pagename; ?>: </td>
        <td>
        <input type="radio" name="test[<?php echo$id; ?>][new]" value="1"   required/>Active<br>
  		<input type="radio" name="test[<?php echo$id; ?>][new]" value="0"  checked required/>Inactive<br>
        </td>
    </tr>
	 
<?php   } }?>
			
			<tr align="center">
				<td colspan="7"><input type="submit" name="update_user" value="Update User Details"/></td>
			</tr>
		
		</table>
	
	
	</form>
</p>
</div>
</div>



<?php include 'template/footer.php';?>










