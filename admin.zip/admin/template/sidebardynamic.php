<?php
	
	/*
	
	
//$sql="select orderdetails.*,package.*,states.states from orderdetails INNER JOIN  package ON orderdetails.packageid=package.p_id
                //   INNER JOIN states ON states.stateid = orderdetails.state WHERE orderdetails.id= '".$id."'";

$sql="select tbl_page_permission.*,tbl_page_master.* from tbl_page_permission INNER JOIN  tbl_page_master ON tbl_page_permission.id=tbl_page_master.id WHERE tbl_page_permission.user_id= '".$_SESSION['user_id']."' AND tbl_page_permission.status=1";
	
	
//class="form-control"
//$sql="SELECT * FROM user_page_permission where user_id='".$_SESSION['user_id']."'";
$result=$con->query($sql);

while($row=mysqli_fetch_array($result)){
	
//$user_id=$row['user_id'];
//$user_loginname= $row['user_loginname'];


    $main_id=$row['main_id'];
    $page_id=$row['page_id'];
	$user_id=$row['user_id'];
	//$status=$row['status'];
	$page_name=$row['page_name'];
	$file_name=$row['file_name'];
	
}




*/
?>





<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
				
                <ul class="nav" id="side-menu">
				
                 <!--    <li>
                        <a href="index.html" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboards</span> </a>
                    </li>
                   
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-indent nav_icon"></i> <span class="nav-label">Menu Levels</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="graphs.html" class=" hvr-bounce-to-right"> <i class="fa fa-area-chart nav_icon"></i>Graphs</a></li>
                            
                            <li><a href="maps.html" class=" hvr-bounce-to-right"><i class="fa fa-map-marker nav_icon"></i>Maps</a></li>
			
						<li><a href="typography.html" class=" hvr-bounce-to-right"><i class="fa fa-file-text-o nav_icon"></i>Typography</a></li>

					   </ul>
                    </li>
					 <li>
                        <a href="inbox.html" class=" hvr-bounce-to-right"><i class="fa fa-inbox nav_icon"></i> <span class="nav-label">Inbox</span> </a>
                    </li>
                    
                    <li>
                        <a href="gallery.html" class=" hvr-bounce-to-right"><i class="fa fa-picture-o nav_icon"></i> <span class="nav-label">Gallery</span> </a>
                    </li> -->
					<?php 
					$sql="SELECT * FROM main_menu_master";
                    $result=$con->query($sql);
                    while($row=mysqli_fetch_array($result)){
	                $menu_id=$row['menu_id'];
					$menu_name=$row['menu_name'];
					?>
                     <li>
    <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label"><?php echo $menu_name; ?></span><span class="fa arrow"></span></a>
     <ul class="nav nav-second-level">
          <?php                  
          $sql="select tbl_page_permission.*,tbl_page_master.* from tbl_page_permission INNER JOIN  tbl_page_master ON tbl_page_permission.page_id=tbl_page_master.id
          WHERE tbl_page_permission.user_id= '".$_SESSION['user_id']."' AND tbl_page_permission.status=1";
	      $result=$con->query($sql);
          while($row=mysqli_fetch_array($result)){		
			if($row['menu_id']=$menu_id){
		  ?>			  		  
              <li><a href="<?php echo $row['file_name'];?>" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i><?php echo $row['page_name']; ?></a></li>
		  
			<?php }}  ?>  
					   
					   </ul>
                    </li>
                    
					<?php  } ?>
					
					
									

                    
                    <!-- 
                     <li>
                        <a href="layout.html" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Grid Layouts</span> </a>
                    </li>
                   
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-list nav_icon"></i> <span class="nav-label">Forms</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="forms.html" class=" hvr-bounce-to-right"><i class="fa fa-align-left nav_icon"></i>Basic forms</a></li>
                            <li><a href="validation.html" class=" hvr-bounce-to-right"><i class="fa fa-check-square-o nav_icon"></i>Validation</a></li>
                        </ul>
                    </li>
                        -->
                        
                   <li>
                        <a href="logout.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Sign Out</span> </a>
                   </li>
                    
                </ul>
            </div>
			</div>
		
        </nav>