<?php
    if($_SESSION["loggedIn"] == "yes") { 
    ?>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li><a href="retailers.php">Stores</a></li>
      <li><a href="coupons.php">Coupons</a></li>
      <li><a href="featured.php">Featured Offers</a></li>
      <li><a href="howitworks.php">How It Works</a></li>
      <li><a href="help.php">Help</a></li>
    </ul>

    <?php } else { ?>
        <ul class="nav navbar-nav">
          <li class="active"><a href="#">Home</a></li>
          <li><a href="retailers.php">Stores</a></li>
          <li><a href="coupons.php">Coupons</a></li>
          <li><a href="myaccount.php">My Account</a></li>//logged in item
          <li><a href="featured.php">Featured Offers</a></li>
          <li><a href="howitworks.php">How It Works</a></li>
          <li><a href="help.php">Help</a></li>
          <li><a href="myfavorites.php">My Favorite Stores</a></li>//logged in item
        </ul>
    <?php
    }
?>