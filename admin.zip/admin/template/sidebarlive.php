<?php
    if($_SESSION['user_id'] == "1") { 
    ?>
<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
				
                <ul class="nav" id="side-menu">
				
                 <!--    <li>
                        <a href="index.html" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboards</span> </a>
                    </li>
                   
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-indent nav_icon"></i> <span class="nav-label">Menu Levels</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="graphs.html" class=" hvr-bounce-to-right"> <i class="fa fa-area-chart nav_icon"></i>Graphs</a></li>
                            
                            <li><a href="maps.html" class=" hvr-bounce-to-right"><i class="fa fa-map-marker nav_icon"></i>Maps</a></li>
			
						<li><a href="typography.html" class=" hvr-bounce-to-right"><i class="fa fa-file-text-o nav_icon"></i>Typography</a></li>

					   </ul>
                    </li>
					 <li>
                        <a href="inbox.html" class=" hvr-bounce-to-right"><i class="fa fa-inbox nav_icon"></i> <span class="nav-label">Inbox</span> </a>
                    </li>
                    
                    <li>
                        <a href="gallery.html" class=" hvr-bounce-to-right"><i class="fa fa-picture-o nav_icon"></i> <span class="nav-label">Gallery</span> </a>
                    </li> -->
					
                     <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">User</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            <li><a href="view_user.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>View User</a></li>
                            <li><a href="add_user.php" class=" hvr-bounce-to-right"><i class="fa fa-file-o nav_icon"></i>Add User</a></li>
                       </ul>
                    </li>
                    
					
					
					
					<li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">USER RIGHTS</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            <li><a href="assign_permission.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>ASSIGN RIGHTS</a></li>
                            <li><a href="insertnewpage.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>INSERT NEWPAGE</a></li>

                       </ul>
                    </li>
					
					
					
					
					
					
					
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">Websites</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            <li class="inactive"><a href="view_web.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>View Websites</a></li>
                            <li class="inactive"><a href="add_web.php" class=" hvr-bounce-to-right"><i class="fa fa-file-o nav_icon"></i>Add Website</a></li>
                       </ul>
                    </li>
                    
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">Categories</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            <li><a href="view_cat.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>View Categories</a></li>
                            <li><a href="add_cat.php" class=" hvr-bounce-to-right"><i class="fa fa-file-o nav_icon"></i>Add Categories</a></li>
                       </ul>
                    </li>
                    
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">Packages</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            <li><a href="view_package.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>View Packages</a></li>
                            <li><a href="add_package.php" class=" hvr-bounce-to-right"><i class="fa fa-file-o nav_icon"></i>Add Package</a></li>
                       </ul>
                    </li>
                    <li>
					<a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">Add Order</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
					
					
                        <a href="add_order.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Add Order(Mobile)</span> </a>
						</ul>
                    </li>
					
                  
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">Orders</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                           <li><a href="view_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Pending Orders</a></li>
						   <li><a href="await_shipped_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Awaiting Shipping</a></li>
                           <li><a href="shipped_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Shipped Order</a></li>
						   <li><a href="confirm_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Confirm Orders</a></li>
						   <li><a href="cancel_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Cancel Orders</a></li>
                       </ul>
                    </li>
					
					
					<li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">Reporting</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            <li><a href="report.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>View Report</a></li>
                            <li><a href="search_order.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Search</span> </a></li>

                       </ul>
                    </li>
					
					
                    
                    <!-- 
                     <li>
                        <a href="layout.html" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Grid Layouts</span> </a>
                    </li>
                   
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-list nav_icon"></i> <span class="nav-label">Forms</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="forms.html" class=" hvr-bounce-to-right"><i class="fa fa-align-left nav_icon"></i>Basic forms</a></li>
                            <li><a href="validation.html" class=" hvr-bounce-to-right"><i class="fa fa-check-square-o nav_icon"></i>Validation</a></li>
                        </ul>
                    </li>
                        -->
                        
                   <li>
                        <a href="logout.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Sign Out</span> </a>
                   </li>
                    
                </ul>
            </div>
			</div>
        </nav>
		
		
		
		<?php } elseif($_SESSION['user_id'] == "5") { ?>
		
<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
				
                <ul class="nav" id="side-menu">
				
                 <!--    <li>
                        <a href="index.html" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboards</span> </a>
                    </li>
                   
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-indent nav_icon"></i> <span class="nav-label">Menu Levels</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="graphs.html" class=" hvr-bounce-to-right"> <i class="fa fa-area-chart nav_icon"></i>Graphs</a></li>
                            
                            <li><a href="maps.html" class=" hvr-bounce-to-right"><i class="fa fa-map-marker nav_icon"></i>Maps</a></li>
			
						<li><a href="typography.html" class=" hvr-bounce-to-right"><i class="fa fa-file-text-o nav_icon"></i>Typography</a></li>

					   </ul>
                    </li>
					 <li>
                        <a href="inbox.html" class=" hvr-bounce-to-right"><i class="fa fa-inbox nav_icon"></i> <span class="nav-label">Inbox</span> </a>
                    </li>
                    
                    <li>
                        <a href="gallery.html" class=" hvr-bounce-to-right"><i class="fa fa-picture-o nav_icon"></i> <span class="nav-label">Gallery</span> </a>
                    </li> -->
                  
                
                    <li>
                        <a href="add_order.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Add Order(Mobile)</span> </a>
                    </li>
					<li>
                        <a href="search_order.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Search</span> </a>
                    </li>
					

					
					
					
					
					
					
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">Orders</span><span class="fa arrow"></span></a>
						
                        <ul class="nav nav-second-level">
                          
						   <li><a href="await_shipped_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Awaiting Shipping</a></li>
                           <li><a href="shipped_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Shipped Order</a></li>
						   <li><a href="confirm_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Confirm Orders</a></li>
						   <li><a href="cancel_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Cancel Orders</a></li>

                       </ul>
					  
                    </li>
					
	
	
	
	
	
	
					
					
					
					<li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">Reporting</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            <li><a href="report.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>View Report</a></li>
                            
                       </ul>
                    </li>
					
					
                    
                    <!-- 
                     <li>
                        <a href="layout.html" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Grid Layouts</span> </a>
                    </li>
                   
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-list nav_icon"></i> <span class="nav-label">Forms</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="forms.html" class=" hvr-bounce-to-right"><i class="fa fa-align-left nav_icon"></i>Basic forms</a></li>
                            <li><a href="validation.html" class=" hvr-bounce-to-right"><i class="fa fa-check-square-o nav_icon"></i>Validation</a></li>
                        </ul>
                    </li>
                        -->
                        
                   <li>
                        <a href="logout.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Sign Out</span> </a>
                   </li>
                    
                </ul>
				
            </div>
			</div>
        </nav>
	
		
		
		
		
		
		
		
		<?php } elseif($_SESSION['user_id'] == "4" || ($_SESSION['user_id'] == "3")) { ?>
		
<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
				
                <ul class="nav" id="side-menu">
				
                 <!--    <li>
                        <a href="index.html" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboards</span> </a>
                    </li>
                   
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-indent nav_icon"></i> <span class="nav-label">Menu Levels</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="graphs.html" class=" hvr-bounce-to-right"> <i class="fa fa-area-chart nav_icon"></i>Graphs</a></li>
                            
                            <li><a href="maps.html" class=" hvr-bounce-to-right"><i class="fa fa-map-marker nav_icon"></i>Maps</a></li>
			
						<li><a href="typography.html" class=" hvr-bounce-to-right"><i class="fa fa-file-text-o nav_icon"></i>Typography</a></li>

					   </ul>
                    </li>
					 <li>
                        <a href="inbox.html" class=" hvr-bounce-to-right"><i class="fa fa-inbox nav_icon"></i> <span class="nav-label">Inbox</span> </a>
                    </li>
                    
                    <li>
                        <a href="gallery.html" class=" hvr-bounce-to-right"><i class="fa fa-picture-o nav_icon"></i> <span class="nav-label">Gallery</span> </a>
                    </li> -->
                  
                
                    <li>
                        <a href="add_order.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Add Order(Mobile)</span> </a>
                    </li>
					<li>
                        <a href="search_order.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Search</span> </a>
                    </li>
					

					
					
					
					
					
					
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">Orders</span><span class="fa arrow"></span></a>
						
                        <ul class="nav nav-second-level">
                        <li><a href="view_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Pending Orders</a></li>
					    <li><a href="await_shipped_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Awaiting Shipping</a></li>
                        <li><a href="cancel_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Cancel Orders</a></li>

						  
                       </ul>
					  
                    </li>
					
	
	
	
	
	
	
					
					
					
					<li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">Reporting</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            <li><a href="report.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>View Report</a></li>
                            
                       </ul>
                    </li>
					
					
                    
                    <!-- 
                     <li>
                        <a href="layout.html" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Grid Layouts</span> </a>
                    </li>
                   
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-list nav_icon"></i> <span class="nav-label">Forms</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="forms.html" class=" hvr-bounce-to-right"><i class="fa fa-align-left nav_icon"></i>Basic forms</a></li>
                            <li><a href="validation.html" class=" hvr-bounce-to-right"><i class="fa fa-check-square-o nav_icon"></i>Validation</a></li>
                        </ul>
                    </li>
                        -->
                        
                   <li>
                        <a href="logout.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Sign Out</span> </a>
                   </li>
                    
                </ul>
				
            </div>
			</div>
        </nav>
	
				<?php }  ?>	

		
		
		
		
		
		
		
	 
	 
	 
	 
	 
	 
		
		

	 
	 
	 
	 
	 
       
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
     
       