<div class="copy">
            <p> &copy; 2016 Genius Import Export. All Rights Reserved | Design by <a href="#" target="_blank">Genius Import Export</a> </p>	    </div>
		</div>
		</div>
		<div class="clearfix"> </div>
       </div>
     <!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
<!---->

</body>
</html>



