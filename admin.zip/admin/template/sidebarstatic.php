<?php
	

//class="form-control"
$sql="SELECT * FROM user_page_permission where user_id='".$_SESSION['user_id']."'";
$result=$con->query($sql);

if($row=mysqli_fetch_array($result)){
	
//$user_id=$row['user_id'];
//$user_loginname= $row['user_loginname'];



$user_page_status = $row['user_page_status'];
	$web_page_status = $row['web_page_status'];
	$categories_page_status = $row['categories_page_status'];
	$package_page_status = $row['package_page_status'];
	$add_order_page_status = $row['add_order_page_status'];
	$search_page_status = $row['search_page_status'];
	$orders_page_status = $row['orders_page_status'];
	$report_page_status = $row['report_page_status'];
  
}?>





<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
				
                <ul class="nav" id="side-menu">
				
                 <!--    <li>
                        <a href="index.html" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboards</span> </a>
                    </li>
                   
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-indent nav_icon"></i> <span class="nav-label">Menu Levels</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="graphs.html" class=" hvr-bounce-to-right"> <i class="fa fa-area-chart nav_icon"></i>Graphs</a></li>
                            
                            <li><a href="maps.html" class=" hvr-bounce-to-right"><i class="fa fa-map-marker nav_icon"></i>Maps</a></li>
			
						<li><a href="typography.html" class=" hvr-bounce-to-right"><i class="fa fa-file-text-o nav_icon"></i>Typography</a></li>

					   </ul>
                    </li>
					 <li>
                        <a href="inbox.html" class=" hvr-bounce-to-right"><i class="fa fa-inbox nav_icon"></i> <span class="nav-label">Inbox</span> </a>
                    </li>
                    
                    <li>
                        <a href="gallery.html" class=" hvr-bounce-to-right"><i class="fa fa-picture-o nav_icon"></i> <span class="nav-label">Gallery</span> </a>
                    </li> -->
					<?php if($user_page_status=="1"){  ?>
                     <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">User</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            <li><a href="view_user.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>View User</a></li>
                            <li><a href="add_user.php" class=" hvr-bounce-to-right"><i class="fa fa-file-o nav_icon"></i>Add User</a></li>
                       </ul>
                    </li>
                    
					<?php  } ?>
					
					
										<?php if($user_page_status=="1"){  ?>

					<li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">USER RIGHTS</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            <li><a href="assign_rights.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>ASSIGN RIGHTS</a></li>
                            
                       </ul>
                    </li>
					
										<?php  } ?>

					
					
					
					
										<?php if($web_page_status=="1"){  ?>

                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">Websites</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            <li class="inactive"><a href="view_web.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>View Websites</a></li>
                            <li class="inactive"><a href="add_web.php" class=" hvr-bounce-to-right"><i class="fa fa-file-o nav_icon"></i>Add Website</a></li>
                       </ul>
                    </li>
                    					<?php  } ?>

					
					
					
										<?php if($categories_page_status=="1"){  ?>

                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">Categories</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            <li><a href="view_cat.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>View Categories</a></li>
                            <li><a href="add_cat.php" class=" hvr-bounce-to-right"><i class="fa fa-file-o nav_icon"></i>Add Categories</a></li>
                       </ul>
                    </li>
                    					<?php  } ?>

					
										<?php if($package_page_status=="1"){  ?>

                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">Packages</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            <li><a href="view_package.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>View Packages</a></li>
                            <li><a href="add_package.php" class=" hvr-bounce-to-right"><i class="fa fa-file-o nav_icon"></i>Add Package</a></li>
                       </ul>
                    </li>
										<?php  } ?>

					
										<?php if($add_order_page_status=="1"){  ?>

                    <li>
                        <a href="add_order.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Add Order(Mobile)</span> </a>
                    </li>
										<?php  } ?>

					
										<?php if($search_page_status=="1"){  ?>

					<li>
                        <a href="search_order.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Search</span> </a>
                    </li>
                  
				  					<?php  } ?>

				  
				  					<?php if($orders_page_status=="1"){  ?>

                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">Orders</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                           <li><a href="view_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Pending Orders</a></li>
						   <li><a href="await_shipped_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Awaiting Shipping</a></li>
                           <li><a href="shipped_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Shipped Order</a></li>
						   <li><a href="confirm_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Confirm Orders</a></li>
						   <li><a href="cancel_order.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>Cancel Orders</a></li>
                       </ul>
                    </li>
										<?php  } ?>

					
										<?php if($report_page_status=="1"){  ?>

					<li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-desktop nav_icon"></i> <span class="nav-label">Reporting</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            <li><a href="report.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon"></i>View Report</a></li>
                            
                       </ul>
                    </li>
					
										<?php  } ?>

                    
                    <!-- 
                     <li>
                        <a href="layout.html" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Grid Layouts</span> </a>
                    </li>
                   
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-list nav_icon"></i> <span class="nav-label">Forms</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="forms.html" class=" hvr-bounce-to-right"><i class="fa fa-align-left nav_icon"></i>Basic forms</a></li>
                            <li><a href="validation.html" class=" hvr-bounce-to-right"><i class="fa fa-check-square-o nav_icon"></i>Validation</a></li>
                        </ul>
                    </li>
                        -->
                        
                   <li>
                        <a href="logout.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Sign Out</span> </a>
                   </li>
                    
                </ul>
            </div>
			</div>
        </nav>
		