

<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
				
                <ul class="nav" id="side-menu">
				<?php 
					include 'includes/db.php';
					$sql="SELECT * FROM main_menu_master order by menu_id";
                    $result=$con->query($sql);
                  while($row=mysqli_fetch_array($result)){
	                $menu_id=$row['menu_id'];
					$menu_name=$row['menu_name'];
					$menu_icon=$row['menu_icon'];
					$sql="";
					 if ($_SESSION['user_id']=="1")
					 {
						 $sql="select * from tbl_page_master WHERE  tbl_page_master.menu_id='". $row['menu_id']  ."' AND  show_in_menu='1' ORDER BY MENU_ID";
					
					 }else
					 {
						 $sql="select tbl_page_permission.*,tbl_page_master.* from tbl_page_master  left JOIN tbl_page_permission   ON tbl_page_permission.page_id=tbl_page_master.id
						 WHERE  tbl_page_master.menu_id='". $row['menu_id']  ."' and show_in_menu='1' ";
						 $sql= $sql . " and tbl_page_permission.user_id= '".$_SESSION['user_id']."'  AND tbl_page_permission.status=1"; 
					 }
					 
					 $rsmenu=$con->query($sql);
					
					if(mysqli_num_rows($rsmenu)>0)
					{
					
								?>
					<li>					 
				<a href="#" class=" hvr-bounce-to-right"><i class="<?php echo $menu_icon;?> nav_icon"></i> <span class="nav-label"><?php echo $menu_name; ?></span><span class="fa arrow"></span></a>    
				 <ul class="nav nav-second-level">
			<?php  while($rowpage=mysqli_fetch_array($rsmenu)){	
					  ?>			  
						  <li><a href="<?php echo $rowpage['file_name'];?>" class=" hvr-bounce-to-right"><i class="<?php echo $rowpage['page_icon'];?> nav_icon"></i><?php echo $rowpage['page_name']; ?></a></li>
					   <?php  }  ?>    
				 </ul>
				 </li>	
			<?php  }  } ?>   
                   
         
                   <li>
                        <a href="logout.php" class=" hvr-bounce-to-right"><i class="fa fa-sign-out nav_icon"></i> <span class="nav-label">Sign Out</span> </a>
                   </li>
                    
                </ul>
            </div>
			</div>
		
        </nav>