<?php 
include 'session.php';

include 'includes/db.php';


?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
      include 'includes/db.php';
	  
?>

    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				
	        	<p>
<?php
$oldpaymentmethod="";
$oldpackageid="";

if(isset($_GET['id'])){


	$id = $_GET['id']; 
	
	
	//$get_pro = "select * from orderdetails where id='$id'";
	
	 
	// $get_pro = "select orderdetails.*,states.states from orderdetails INNER JOIN  states ON  orderdetails.state=states.stateid where id='$get_id'";
                //   INNER JOIN states ON states.stateid = orderdetails.state ORDER BY id DESC";
	 
	 // $get_pro = "select orderdetails.*,package.*,states.states from orderdetails INNER JOIN  package ON orderdetails.packageid=package.p_id
                //   INNER JOIN states ON states.stateid = orderdetails.state ORDER BY id DESC";
	//$sql="SELECT * FROM orderdetails where id=$id";
	$sql="SELECT orderdetails.*,categories.cat_title,websites.sellnum FROM orderdetails INNER JOIN categories ON categories.cat_id = orderdetails.p_cat_id 
	INNER JOIN websites ON websites.web_id = orderdetails.web_id  where id=$id";
$result=$con->query($sql);
if($row=mysqli_fetch_array($result)){
	
	
//	$run_pro = mysqli_query($con, $get_pro);
	
	$i = 0;
	
	//if($row_pro=mysqli_fetch_array($run_pro)){
		//$id=$get_id;
	//$id=$row_pro['packageid'];
	        $cat_title=$row['cat_title'];
			$sellnum=$row['sellnum'];
            $oldpackageid=$row['packageid'];
		    $prefix = $row['prefix'];
			$orderstatus = $row['orderstatus'];
			$pincode = $row['pin'];
			$name =  $row['name'];
			$number = $row['mobile'];
			$email = $row['email'];
			$address = $row['address'];
			$states =  $row['state'];
			$cityname = $row['city'];
			$SelLocation = $row['locality'];
			$paymentmethod=$row['paymentmethod'];
			$oldpaymentmethod=$row['paymentmethod'];
	  	    $web_id=$row['web_id'];
	  	    $web_domain=$row['web_domain'];
			$oldpackageprice=$row['pack_price'];
			$shippingcharge=$row['shippingcharge'];
		    $paymentstatus=$row['paymentstatus'];
			$trackingcode =$row['trackingcode'];
			$bypost=$row['bypost'];
			$DestinationServiceArea = $row['DestinationServiceArea'];
			$DestinationLocation = $row['DestinationLocation'];
			$couriercompany = $row['couriercompany'];
			$OrderDate = $row['OrderDate'];
			$statename=$row['state'];
			$pinc = $row['pin'];
			$oldshippingcharge=$row['shippingcharge'];

	}		
	
		
		
}
?>
<?php 

	if(isset($_POST['update_admin'])){
	
		//getting the text data from the fields

		$update_id = $id;
		
		$orderstatus = mysqli_real_escape_string($con,$_POST['orderstatus']);
		
		$pincode = mysqli_real_escape_string($con,$_POST['pin']);
		$name = mysqli_real_escape_string($con,$_POST['name']);
		$number = mysqli_real_escape_string($con,$_POST['mobile']);
		$email = mysqli_real_escape_string($con,$_POST['email']);
		$address = mysqli_real_escape_string($con,$_POST['address']);
		$states = mysqli_real_escape_string($con,$_POST['stateid']);
		$locality = mysqli_real_escape_string($con,$_POST['locality']);
		if(strtolower($couriercompany)!=strtolower("fedex")){
		$trackingcode = mysqli_real_escape_string($con,$_POST['trackingcode']);	
	    $DestinationServiceArea = mysqli_real_escape_string($con,$_POST['DestinationServiceArea']);
		$DestinationLocation = mysqli_real_escape_string($con,$_POST['DestinationLocation']);
		}
		//$bypost = mysqli_real_escape_string($con,$_POST['bypost']);
		
		//$packageid = mysqli_real_escape_string($con,$_POST['packageid']);
       // $web_domain=mysqli_real_escape_string($con,$_POST['web_domain']);
	   // $newpaymentmethod=mysqli_real_escape_string($con,$_POST['oldpaymentmethod']);
	    $city=mysqli_real_escape_string($con,$_POST['city']);
		
		//	$sql="select states from states from where stateid='$states'";			
		//	$result=mysqli_query($sql,con);
		//	while($row=mysqli_fetch_array($result)){
         //       $statename=$row['states'];

		//	}
			
				$sql="SELECT * FROM tbl_postalcode WHERE PostalCode='$pincode'";
				
				$result2=$con->query($sql);


				if($result2->num_rows){

				$row=$result2->fetch_assoc();
				$bypost="CR";
				$statename=$row['State'];
				if(strcasecmp($row['couriercompany'], "fedex")==0){
				$couriercompany="fedex";	
				
				}
				elseif(strcasecmp($row['couriercompany'], "Delhivery")==0){
				$couriercompany="Delhivery";
				
				}
				elseif(strcasecmp($row['couriercompany'], "bluedart")==0){
				$couriercompany="bluedart";
				
				}
				}
				
				else{

				$couriercompany="POSTOFFICE";	
				$bypost="PO";
				}
				

				
		
		
		
		

			if($paymentmethod=="COD"){
		$packageid = mysqli_real_escape_string($con,$_POST['packageid']);
		}
	/*if ($paymentmethod!="COD")
		{
			
			if($oldpackageid!=$packageid )
			{
				exit();
			}
		}*/
		
        if(strtolower($paymentmethod)==strtolower("ONLINE")){
		if(strtolower($orderstatus)==strtolower("CANCEL") && strtolower($paymentstatus)==strtolower("DONE")){
		?>
		<script type="text/javascript">
		alert("You can not CANCEL order because paymentstatus is DONE");
		location="";
		</script>
		<?php
		exit();		   
		}		
		} 	
		
		
		
		
		
		if($paymentmethod=="COD"){
		if($packageid!=$oldpackageid){

		$sql="SELECT * FROM package where p_id=$packageid";
		$result=$con->query($sql);

		if($row=mysqli_fetch_array($result)){
		$packagecost=$row['p_price'];
		$shippingcharge=$row['p_shipping'];
        $tot_fed_price=$packagecost+$shippingcharge;

		}

		}
		else{
		$packageid=$oldpackageid;
		$packagecost=$oldpackageprice;
        $shippingcharge=$oldshippingcharge;
        $tot_fed_price=$packagecost+$shippingcharge;
		}	
		}
		
		if(strtolower($paymentmethod)==strtolower("ONLINE") && strtolower($paymentstatus)==strtolower("DONE")){
			$packagecost=$oldpackageprice;
			$shippingcharge=$oldshippingcharge;
            $tot_fed_price=$packagecost+$shippingcharge;
		}
		
		
		
		
		// fedex api trackingcode
if(strtolower($couriercompany)==strtolower("fedex")){				
if(strtolower($orderstatus)==strtolower("SHIPPEDORDER")){		
$orderid=$prefix."-".$bypost."-".$id;	
//echo $number;


function addShipper(){
	$shipper = array(
		'Contact' => array(
			'PersonName' => 'Anupam Saxena',
			'CompanyName' => 'GENIUSIMPORTEXPORT',
			'PhoneNumber' => '9536948375'
		),
		'Address' => array(
			'StreetLines' => 'H-53 Triveni Nagar, Rangoli Colony, NH-2, Sikandra, Agra, UP - 282007',
			'City' => 'Agra',
			'StateOrProvinceCode' => 'UP',
			'PostalCode' => '282007',
			'CountryCode' => 'IN',
			'CountryName' => 'INDIA'
		)
	);
	return $shipper;
}
function addRecipient($number,$pincode,$name,$address,$city,$statename){
	//$n=$number;
	$recipient = array(
		'Contact' => array(
			'PersonName' => "$name",
			'CompanyName' => '',
			'PhoneNumber' =>"$number"
			
		),
		'Address' => array(
			'StreetLines' => "$address",
			'City' => "$city",
			'StateOrProvinceCode' => "$statename",
			'PostalCode' => "$pincode",
			'CountryCode' => 'IN',
			'CountryName' => 'INDIA',
			'Residential' => true
		)
	);
	return $recipient;	
}
function addShippingChargesPayment(){
	$shippingChargesPayment = array(
		'PaymentType' => 'SENDER',
        'Payor' => array(
			'ResponsibleParty' => array(
				'AccountNumber' => getProperty('billaccount'),
				'Contact' => null,
				'Address' => array('CountryCode' => 'IN')
			)
		)
	);
	return $shippingChargesPayment;
}
function addLabelSpecification(){
	$labelSpecification = array(
		'LabelFormatType' => 'COMMON2D', // valid values COMMON2D, LABEL_DATA_ONLY
		'ImageType' => 'PDF',  // valid values DPL, EPL2, PDF, ZPLII and PNG
		'LabelStockType' => 'PAPER_8.5X11_TOP_HALF_LABEL'
	);
	return $labelSpecification;
}

//if(strtolower("ONLINE")==strtolower("COD")){

function addSpecialServices1($tot_fed_price,$paymentmethod){
	if(strtolower($paymentmethod)==strtolower("COD")){
	$specialServices = array(
		'SpecialServiceTypes' => 'COD',
		'CodDetail' => array(
			'CodCollectionAmount' => array(
				'Currency' => 'INR', 
				'Amount' => "$tot_fed_price"
			),
			'CollectionType' => 'CASH',// ANY, GUARANTEED_FUNDS
			'FinancialInstitutionContactAndAddress' => array(
				'Contact' => array(
					'PersonName' => 'Anupam Saxena',
					'CompanyName' => 'GENIUSIMPORTEXPORT',
					'PhoneNumber' => '9536948375'
				),
				'Address' => array(
					'StreetLines' => 'H-53 Triveni Nagar, Rangoli Colony, NH-2, Sikandra, Agra, UP - 282007',
					'City' => 'Agra',
					'StateOrProvinceCode' => 'UP',
					'PostalCode' => '282007',
					'CountryCode' => 'IN',
					'CountryName' => 'INDIA'
				)
			),
			'RemitToName' => 'Remitter'
		)
	);
	return $specialServices; 
}
}
function addCustomClearanceDetail($tot_fed_price){
	$customerClearanceDetail = array(
		'DutiesPayment' => array(
			'PaymentType' => 'SENDER', // valid values RECIPIENT, SENDER and THIRD_PARTY
			'Payor' => array(
				'ResponsibleParty' => array(
					'AccountNumber' => getProperty('dutyaccount'),
					'Contact' => null,
					'Address' => array(
						'CountryCode' => 'IN'
					)
				)
			)
		),
		'DocumentContent' => 'NON_DOCUMENTS',                                                                                            
		'CustomsValue' => array(
			'Currency' => 'INR', 
			'Amount' => "$tot_fed_price"
		),
		'CommercialInvoice' => array(
			'Purpose' => 'SOLD',
			'CustomerReferences' => array(
				'CustomerReferenceType' => 'CUSTOMER_REFERENCE',
				'Value' => '1234'
			)
		),
		'Commodities' => array(
			'NumberOfPieces' => 1,
			'Description' => 'Healthcare',
			'CountryOfManufacture' => 'IN',
			'Weight' => array(
				'Units' => 'KG', 
				'Value' => .4
			),
			'Quantity' => 1,
			'QuantityUnits' => 'EA',
			'UnitPrice' => array(
				'Currency' => 'INR', 
				'Amount' => "$tot_fed_price"
			),
			'CustomsValue' => array(
				'Currency' => 'INR', 
				'Amount' => "$tot_fed_price"
			)
		)
	);
	return $customerClearanceDetail;
}
function addPackageLineItem1($tot_fed_price,$orderid){
	$packageLineItem = array(
		'SequenceNumber'=>1,
		'GroupPackageCount'=>1,
		'InsuredValue' => array(
			'Amount' => "$tot_fed_price", 
			'Currency' => 'INR'
		),
		'Weight' => array(
			'Value' => .4,
			'Units' => 'KG'
		),
		'Dimensions' => array(
			'Length' => 20,
			'Width' => 10,
			'Height' => 10,
			'Units' => 'CM'
		),
		'CustomerReferences' => array(
			'CustomerReferenceType' => 'INVOICE_NUMBER', // valid values CUSTOMER_REFERENCE, INVOICE_NUMBER, P_O_NUMBER and SHIPMENT_INTEGRITY
			'Value' => "$orderid"
		)
	);
	return $packageLineItem;
}






// Copyright 2009, FedEx Corporation. All rights reserved.
// Version 12.0.0

require_once('fedex-common.php');

//The WSDL is not included with the sample code.
//Please include and reference in $path_to_wsdl variable.
$path_to_wsdl = "ShipService_v19.wsdl";

// PDF label files. Change to file-extension .png for creating a PNG label (e.g. shiplabel.png)
//define('SHIP_LABEL', 'shiplabel.pdf');  
//define('COD_LABEL', 'codlabel.pdf'); 
//echo $number;

ini_set("soap.wsdl_cache_enabled", "0");

$client = new SoapClient($path_to_wsdl, array('trace' => 1)); // Refer to http://us3.php.net/manual/en/ref.soap.php for more information

$request['WebAuthenticationDetail'] = array(
	'ParentCredential' => array(
		'Key' => 'L86FN4SUobDERrdX', 
		'Password' => 'cIVsShQvtDDdSFSLJ7Z4RxSTj'
	),
	'UserCredential' => array(
		'Key' => 'L86FN4SUobDERrdX', 
		'Password' => 'cIVsShQvtDDdSFSLJ7Z4RxSTj'
	)
);

$request['ClientDetail'] = array(
	'AccountNumber' => getProperty('shipaccount'), 
	'MeterNumber' => getProperty('meter')
);
$request['TransactionDetail'] = array('CustomerTransactionId' => '$orderid');
$request['Version'] = array(
	'ServiceId' => 'ship', 
	'Major' => '19', 
	'Intermediate' => '0', 
	'Minor' => '0'
);
$request['RequestedShipment'] = array(
	'ShipTimestamp' => date('c'),
	'DropoffType' => 'REGULAR_PICKUP', // valid values REGULAR_PICKUP, REQUEST_COURIER, DROP_BOX, BUSINESS_SERVICE_CENTER and STATION
	'ServiceType' => 'STANDARD_OVERNIGHT', // valid values STANDARD_OVERNIGHT, PRIORITY_OVERNIGHT, FEDEX_EXPRESS_SAVER
	'PackagingType' => 'YOUR_PACKAGING', // valid values FEDEX_BOX, FEDEX_PAK, FEDEX_TUBE, YOUR_PACKAGING, ...
	'Shipper' => addShipper(),
	'Recipient' => addRecipient($number,$pincode,$name,$address,$city,$statename),
	'ShippingChargesPayment' => addShippingChargesPayment(),	
	'SpecialServicesRequested' => addSpecialServices1($tot_fed_price,$paymentmethod),	//Used for Intra-India shipping - cannot use with PRIORITY_OVERNIGHT
	'CustomsClearanceDetail' => addCustomClearanceDetail($tot_fed_price),                                                                                                      
	'LabelSpecification' => addLabelSpecification(),
	'CustomerSpecifiedDetail' => array('MaskedData'=> '604501202'), 
	'PackageCount' => 1,                                       
	'RequestedPackageLineItems' => array(
		'0' => addPackageLineItem1($tot_fed_price,$orderid)
	)
);



try{
	if(setEndpoint('changeEndpoint')){
		$newLocation = $client->__setLocation(setEndpoint('endpoint'));
	}
	
	$response = $client->processShipment($request); // FedEx web service invocation

    if ($response->HighestSeverity != 'FAILURE' && $response->HighestSeverity != 'ERROR'){
        printSuccess($client, $response);

        // Create PNG or PDF labels
        // Set LabelSpecification.ImageType to 'PNG' for generating a PNG labels
		/*
        $fp = fopen(SHIP_LABEL, 'wb');   
        fwrite($fp, ($response->CompletedShipmentDetail->CompletedPackageDetails->Label->Parts->Image));
        fclose($fp);
        echo 'Label <a href="./'.SHIP_LABEL.'">'.SHIP_LABEL.'</a> was generated.';           
        
        $fp = fopen(COD_LABEL, 'wb');   
        fwrite($fp, ($response->CompletedShipmentDetail->AssociatedShipments->Label->Parts->Image));
        fclose($fp);
       echo 'Label <a href="./'.COD_LABEL.'">'.COD_LABEL.'</a> was generated.';   
	   */
    }else{
        printError($client, $response);
    }
	
	
	writeToLog($client);    // Write to log file
} catch (SoapFault $exception) {
   printFault($exception, $client);
}




//echo "fed";

}
}		
	//	 delhivery api trackingcode
	
		if(strtolower($couriercompany)!=strtolower("fedex")){
		if(strtolower($orderstatus)==strtolower("SHIPPEDORDER") && $trackingcode==""){	
		?>
		<script type="text/javascript">
		alert("You can not proceed order because trackingcode is empty");
		location="";
		</script>
		<?php
		exit();
		
		}
		}
		
		
	if(strtolower($paymentmethod)==strtolower("COD")){	
		
		if(strtolower($couriercompany)==strtolower("fedex")){
			
			$sql = "update orderdetails set orderstatus='$orderstatus',pin='$pincode',name='$name',mobile='$number',email='$email',address='$address',city='$city'
		    ,state='$states',locality='$locality',packageid='$packageid',pack_price='$packagecost',shippingcharge='$shippingcharge'
		,couriercompany='$couriercompany',bypost='$bypost' where id='$update_id'";
			
		}
		else{
			
			$sql = "update orderdetails set orderstatus='$orderstatus',pin='$pincode',name='$name',mobile='$number',email='$email',address='$address',city='$city'
		    ,state='$states',DestinationServiceArea='$DestinationServiceArea',
			 DestinationLocation='$DestinationLocation',locality='$locality',packageid='$packageid',pack_price='$packagecost',shippingcharge='$shippingcharge'
		,couriercompany='$couriercompany',bypost='$bypost',trackingcode='$trackingcode' where id='$update_id'";
			
		}
	
   $result=$con->query($sql);

}
		
	
   else{
	   
	   
	  if(strtolower($couriercompany)==strtolower("fedex")){
			 $sql = "update orderdetails set orderstatus='$orderstatus',pin='$pincode',name='$name',mobile='$number',email='$email',address='$address',city='$city'
		                    ,state='$states',locality='$locality' 
			 ,couriercompany='$couriercompany',bypost='$bypost' where id='$update_id'";
			
		}
		else{
			
			 $sql = "update orderdetails set orderstatus='$orderstatus',pin='$pincode',name='$name',mobile='$number',email='$email',address='$address',city='$city'
		                    ,DestinationServiceArea='$DestinationServiceArea',
			 DestinationLocation='$DestinationLocation' ,state='$states',locality='$locality' 
			 ,couriercompany='$couriercompany',bypost='$bypost',trackingcode='$trackingcode' where id='$update_id'";
			
			
		} 
	  
//$sql = "update orderdetails set orderstatus='$orderstatus',pin='$pincode',name='$name',mobile='$number',email='$email',address='$address',city='$city'
		               //      ,state='$states',locality='$locality', where id='$update_id'";   
	$result=$con->query($sql);

   }

	//$update="update orderdetails set orderstatus='$orderstatus',pin='$pincode',name='$name',mobile='$number',email='$email',address='address',state='$states'";

	//$update_user = "update orderdetails set orderstatus='$orderstatus',pin='$pincode',name='$name',mobile='$number',email='$email',address='$address',city='$city'
		                 //    ,state='$states',locality='$locality',packageid='$oldpackageid',p_price='$packagecost' where id='$update_id'";
		 
		// $run_user = mysqli_query($con, $update_user);
		 
		 if($result){
		    if(strtolower($orderstatus)==strtolower("CANCEL")){
            $package_sms_price=($packagecost + $shippingcharge);
			$orderid=$prefix."-".$bypost."-".$id;
			$username = 'youremail@address.com';
			$hash = 'Your API hash';
			$apiKey='7Fok6gPjqoA-vo8T36MkAVdib4COP7YTGyNoRG3IHf';
			$numbers = array($number); 
			$sender = urlencode('GENIUS');
			$date = new DateTime();
			//$message = rawurlencode("Dear ". $name ." Your Order of ". $cat_title  ." has been dispatched by ". $couriercompany  ." and Your TRACKING No: ". $trackingno  ." and for more information you can call on this ". $sellnum  .".");
			$message = rawurlencode("Your order no. "  . $orderid ." of ". $cat_title ." Rs ". $package_sms_price ." has been canceled. if you want to order again call ". $sellnum  .".");
			$numbers = implode(',', $numbers);
			$data = array( 'apiKey' => $apiKey, 'numbers' => $numbers, 'test'=>false,  'sender' => $sender, 'message' => $message);
		   try{
			   
			
			$ch = curl_init('http://api.textlocal.in/send/');
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$response = curl_exec($ch);
			curl_close($ch);
			//echo$response;
			$result = json_decode($response);
			
			
			 }catch (Exception $ex)
			 {
				 echo "<script>alert('Server Error')</script>";
			 }
			}	 
		 
		 echo "<script>alert('Admin Response has been updated!')</script>";
		 
		 echo "<script>window.open('await_shipped_order.php','_self')</script>";
		 // header("Location:view_order.php");
		 }
		
	}


?>

		<title>Update Admin Response Details</title> 
		

	
	



	<form action="" method="post" enctype="multipart/form-data"> 
		
		<table align="center" width="795" border="2" bgcolor="#187eae">
			
			<tr align="center">
				<td colspan="7"><h2>Edit & Update Admin Response</h2></td>
			</tr>
			
			<tr>
			    <td align="right"><b><h4>OrderID:</h4></b></td>
				<td><h4><?php echo $prefix."-".$bypost."-".$id; ?></h4></td>

			</tr>
			
				
			<tr>
				<td align="right"><b>WEBSITE NAME:</b></td>
				<td><h4><?php echo $web_domain;?></h4></td>
			</tr>
			
			
			
			<tr>
				<td align="right"><b>CUSTOMER NAME:</b></td>
				<td><input type="text" name="name" size="60" value="<?php echo $name;?>"/></td>
			</tr>

            <tr>
				<td align="right"><b>PHONE NUMBER:</b></td>
				<td><input type="text" name="mobile" size="60" value="<?php echo $number;?>"/></td>
			</tr>

			<tr>
				<td align="right"><b>E-Mail ID:</b></td>
				<td><input type="text" name="email" size="60" value="<?php echo $email;?>"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>ADDRESS:</b></td>
				<td><textarea name="address" rows="2" cols="20"><?php echo $address;?></textarea></td>
			</tr>
			
			<tr>
				<td align="right"><b>PINCODE:</b></td>
				<td><input type="text" name="pin" size="60" value="<?php echo $pincode;?>"/></td>
			</tr>

			<tr>
				<td align="right"><b>STATE:</b></td>
				<td>
				
				
				
				<select name="stateid">
<?php
 
$sql="SELECT * FROM states";
$result=$con->query($sql);
while($row=mysqli_fetch_array($result)){
$statename=$row['states'];
$stateid=$row['stateid'];
echo "<option value='".$stateid."' ".  ($stateid==$states ? "Selected": "")  ."  >".$statename."</option>";
}
?>

</select>			
</td>
</tr>
			
			<tr>
				<td align="right"><b>CITY:</b></td>
				<td><input type="text" name="city" size="60" value="<?php echo $cityname;?>"/></td>
			</tr>

			<tr>
				<td align="right"><b>LOCATION:</b></td>
				<td><input type="text" name="locality" size="60" value="<?php echo $SelLocation;?>"/></td>
			</tr>

			
			<tr>
				<td align="right"><b> PAYMENT METHOD:</b></td>
				<td><?php echo $oldpaymentmethod;?></td>
			</tr>
			<tr>
				<td align="right"><b> PAYMENT STATUS:</b></td>
				<td><?php echo $paymentstatus;?></td>
			</tr>

			
			
			
			
				<tr>
				<td align="right"><b>PACKAGE NAME</b></td>
				<td>
				
				<select name="packageid" <?php echo ($oldpaymentmethod=="ONLINE"? "disabled" : ""); ?> >
						<?php
						 
						$sql="SELECT * FROM package where p_status=1 and p_web_id='$web_id'";
						$result=$con->query($sql);
						while($row=mysqli_fetch_array($result)){
						$packagename=$row['p_name'];
						$packageid= $row['p_id'];
						$packagecost=$row['p_price'];
						$shippingcharge=$row['p_shipping'];
						echo "<option data-price=".$row['p_price']." data-shipping=".$row['p_shipping']." value=  '".$packageid."' ".  ($packageid==$oldpackageid ? "Selected": "")  ." >".$packagename."</option>";
						}
						?>

	  
				</select>	
				
				</td>
			</tr>		
				<tr>
				<td align="right"><b> PACKAGE PRICE:</b></td>
				<td name="newprice"><h4 data-newprice="" name="newprice"><?php echo $oldpackageprice;?></h4></td>
			</tr>
			
			<tr>
				<td align="right"><b>SHIIPPING CHARGE:</b></td>
				<td><h4 data-shipping=""><?php echo $shippingcharge;?></h4></td>
			</tr>
			<tr>
				<td align="right"><b>TOTAL PRICE:</b></td>
				<td><h4 data-total=""><?php echo ($oldpackageprice+$shippingcharge);?></h4></td>
			</tr>
			
			<tr>
				<td align="right"><b>COURIER COMPANY:</b></td>
				<td><h4 ><?php echo $couriercompany;?></h4></td>
			</tr>
			
			
			<tr>
				<td align="right"><b>Tracking Code:</b></td>
				<td><input type="text" name="trackingcode" size="60" value="<?php echo $trackingcode;?>" <?php echo (strtolower($couriercompany)==strtolower("fedex") ? "disabled": "")?>></td>
			</tr>
			
			<tr>
				<td align="right"><b>Destinaion Service Area:</b></td>
				<td><input type="text" name="DestinationServiceArea" size="60" value="<?php echo $DestinationServiceArea;?>" <?php echo (strtolower($couriercompany)==strtolower("fedex") ? "disabled": "")?>/></td>
			</tr>
			
			<tr>
				<td align="right"><b>Destinaion Location:</b></td>
				<td><input type="text" name="DestinationLocation" size="60" value="<?php echo $DestinationLocation;?>" <?php echo (strtolower($couriercompany)==strtolower("fedex") ? "disabled": "")?>/></td>
			</tr>
			
			<tr>
				<td align="right"><b>ORDER STATUS:</b></td>
				<td>
					
					  <input type="hidden" name="id" value="<?php echo $_GET["id"]; ?>">
						<select name="orderstatus" >
												

							
							<option value="AWAITINGSHIPPING" <?php echo ($orderstatus=="AWAITINGSHIPPING" ? "Selected": "");?>>AWAITING SHIPPING</option>
							<option value="SHIPPEDORDER" <?php echo ($orderstatus=="SHIPPEDORDER" ? "Selected": "");?> >SHIPPED ORDER</option>
							<option value="CANCEL" <?php echo ($orderstatus=="CANCEL" ? "Selected": "");?>>CANCEL</option>
						
						
						
						</select>

				</td>
			</tr>
			
			
			<tr align="center">
			    
			    <td colspan="7"><a href="await_shipped_order.php" class="btn btn-primary">BACK</a>
				    <input type="submit" name="update_admin" class="btn btn-success" value="Update Admin Details"/></td>
			</tr>
		
		</table>
	
	
	</form>
	
</p>
</div>
</div>

<script type="text/javascript">
$(document).ready(function(){
$('select[name=packageid]').change(function(){
var price=$(this).find("option:selected").data("price");	
var shipping=$(this).find("option:selected").data("shipping");
$('h4[name=newprice]').val(price);
$('h4[data-newprice]').text(price);
$('h4[data-shipping]').text(shipping);
$('h4[data-total]').text(Number(price)+Number(shipping));
});	
	
});



</script>






<?php include 'template/footer.php';
?>
<?php ?>










 