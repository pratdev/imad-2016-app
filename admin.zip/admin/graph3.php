<?php 
include 'session.php';
include 'includes/db.php';

?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
	  
	  $query = "Select * from orderdetails ";
      $qresult = mysqli_query($con, $query);

?>
	  
		 <title>View Graph Genius Admin Panel</title>
		 
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
     
	    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	    
		 <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
		
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>



	  <script>
				

			  $( function() {
				//$( "#datepicker" ).datepicker();
				$( "#datepicker" ).datepicker({changeMonth:true,changeYear:true,numberOfMonths:[1,1]});
				$( "#datepicker" ).datepicker("option", "dateFormat", "yy-mm-dd");
				  });
			 
			 $( function() {
				//$( "#datepicker2" ).datepicker();
				$( "#datepicker2" ).datepicker({changeMonth:true,changeYear:true,numberOfMonths:[1,1]});
				$( "#datepicker2" ).datepicker("option", "dateFormat", "yy-mm-dd");
			      });
		

	  </script>
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	
   <div class="blank-page">
   
<?php 
include ('includes/db.php');
  
  $_POST['fromdate'] ="";
  $_POST['todate'] ="";
  
  $query = "Select * from orderdetails where orderdetails.rtnrcvdate BETWEEN '". $_POST['fromdate'] ."' AND '". $_POST['todate']. "'";
  $qresult = mysqli_query($con, $query);
 
?>
 
		
		

         <script>  
		      
			  google.load('current', {'packages':['corechart']});
			  google.setOnLoadCallback(drawChart);

			  function drawChart() {
				// Some raw data (not necessarily accurate)
				var data = google.visualization.arrayToDataTable([
				 //['Date', 'Total', 'Received', 'Return', 'No Status'],
				  ['rtnrcvdate','Orders','Received','Return','NoStatus'],
				 <?php 
				 
				 if(isset($_POST['submit']))
				 {
					 
				  $_POST['fromdate'] ="";
				  $_POST['todate'] ="";
				  
				  $query = "SELECT count(OrderDate) AS count,COUNT(CASE WHEN rtnrcv='Received' THEN 1 ELSE NULL END) AS Received,COUNT(CASE WHEN rtnrcv='Return' THEN 1 ELSE NULL END) AS 'Return',
	      COUNT(CASE WHEN rtnrcv= '' then 1 ELSE NULL END) as NoStatus,rtnrcvdate FROM orderdetails where rtnrcvdate  BETWEEN '2017-03-22' AND '2017-03-24' GROUP BY orderdetails.rtnrcvdate";
				  
				  
				  //SELECT count(id) AS count,COUNT(CASE WHEN rtnrcv='Received' THEN 1 ELSE NULL END) AS Received,rtnrcvdate FROM 
				        //    orderdetails GROUP BY rtnrcvdate";
				  
				    //SELECT count(id) AS count,count(rtnrcv) as Received,rtnrcvdate FROM orderdetails GROUP BY rtnrcvdate";
						// (IF(salary>5000,1,NULL)
				  //Select * from orderdetails where orderdetails.rtnrcvdate BETWEEN '". $_POST['fromdate'] ."' AND '". $_POST['todate']. "'";
			  
			  
			  
				  $qresult = mysqli_query($con, $query); 
				  
				  
				   $checkrows=mysqli_num_rows($qresult);
							
					if($checkrows>0) 
							{
							
								 while($row = mysqli_fetch_array($qresult))
								 {   
								   if ($row["rtnrcv"]=='Received')
											
										{
								          echo "['".$row['rtnrcvdate']."',".$row['count'].",".$row['Received'].",".$row['Return'].",".$row['NoStatus']."],";
										}
								 }
						    }
					 }
				 ?>
				
			  ]);

			var options = {
			  title : 'Record of all couriers',
			  vAxis: {title: 'Number'},
			  hAxis: {title: 'Time Interval'},
			  seriesType: 'line',
			  series: {0: {type: 'bars'}}
			};

			var chart = new google.visualization.ComboChart(document.getElementById('chart_div'));
			chart.draw(data, options);
		  }
			
       </script>
	        <form method="post" action="<?php $_SERVER['PHP_SELF']; ?>" >
				From: <input type="text" name="fromdate" id="datepicker" value="<?php echo $_POST['fromdate']?>" required /  >
				To: <input type="text" name="todate" id="datepicker2" value="<?php echo $_POST['todate']?>" required /  >
			           <input type="submit" class="btn btn-success" name="submit" value="VIEW" />
			 
			  <div id="chart_div"  style='width: 900px; height: 500px;'></div>
			 
			 </form>
			<!--From: <input type="text" id="datepicker"> 
			To: <input type="text" id="datepicker2">
			<input type="submit" class="btn btn-success" name="submit" value="VIEW" />-->
			
	  
       


	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>
<?php ?>