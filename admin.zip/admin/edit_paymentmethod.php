<?php
  
   if(isset($_GET['id'])){
   include ('includes/db.php');
   $id = $_GET['id']; 
   $sql="SELECT * FROM orderdetails where id=$id and paymentmethod='ONLINE' and paymentstatus<>'DONE' ";
   $result=$con->query($sql);
   if($row=mysqli_fetch_array($result))
  {
	  $packageid=$row['packageid'];
	  $web_id=$row['web_id'];
	  $orderstatus=$row['orderstatus'];
    $sql="SELECT * FROM package where p_id='$packageid' and p_web_id='$web_id'";
    $result=$con->query($sql);
	if($row=mysqli_fetch_array($result))
  { 
    $p_price=round($row['p_price']);
	$p_shipping=$row['p_shipping'];
	
	
 
	$sql="update orderdetails set paymentmethod='COD', paymentstatus='NONE', pack_price='$p_price', shippingcharge='$p_shipping'  where id='".$id."'";
	$result=$con->query($sql);
  }
	
	if(strtolower($orderstatus)==strtolower("CANCEL")){
	
	
	
	?>
	<script type="text/javascript">
    alert("You have successfully convert to COD");
    location="cancel_edit_order.php?id=<?php echo $id;?>";
    </script>
    <?php
	exit()
	?>
	
	<?php
    }else {	?>
	<script type="text/javascript">
    alert("You have successfully convert to COD");
    location="pending_edit_order.php?id=<?php echo $id;?>";
    </script>
    <?php
	exit();	
	}
  }
    else
{
	?>
	<script type="text/javascript">
    alert("You can not change paymentmethod");
    location="pending_edit_order.php?id=<?php echo $id;?>";
    </script>
    <?php
}
	
  }

?>