<?php 
@session_start();
$helper = array_keys($_SESSION);
    foreach ($helper as $key){
        unset($_SESSION[$key]);
    }
session_unset();
session_destroy();


	header("location:signin.php?not_admin=You are not an Admin!");



?> 

