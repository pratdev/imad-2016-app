<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Billing - Genius Import Export</title>

<!-- Bootstrap -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/mycss2.css" rel="stylesheet">
 <link rel="stylesheet" type="text/css" href="css/print.css" media="print" />
<!--
<script src="http://www.ittutorials.in/js/demo/numtoword.js" type="text/javascript"></script>-->

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
   
</head>

<body>
<input type="button" class="no-print btn-success" value="Print This Page" onClick="window.print()" />

<?php 
 include ("includes/db.php");
 include ("includes/word.php");
 		$id = mysqli_real_escape_string($con,$_GET['id']);

  $get_pro = "select orderdetails.*,package.*,states.states from orderdetails INNER JOIN  package ON orderdetails.packageid=package.p_id
                   INNER JOIN states ON states.stateid = orderdetails.state WHERE orderdetails.id in ( ".$id.") AND paymentmethod!='".strtolower("ONLINE")."'";

	  $run_pro = mysqli_query($con, $get_pro);
  while($row_pro=mysqli_fetch_array($run_pro))
	  {
	  $orderid=$row_pro['id'];	
      $prefix=$row_pro['prefix'];
      $OrderDate=$row_pro['OrderDate'];
      $bypost=$row_pro['bypost'];
      $prefix=$row_pro['prefix'];
      $name=$row_pro['name'];
	  $address=$row_pro['address'];
	  $city=$row_pro['city'];
	  $state=$row_pro['states'];
	  $pin=$row_pro['pin'];
      $mobile=$row_pro['mobile'];
      $packagename=$row_pro['p_name'];
      $packageprice=$row_pro['pack_price'];
	  
	  $packagepocharge=$row_pro['p_pocharge'];
	  
	  $trackingcode=$row_pro['trackingcode'];
	  $locality=$row_pro['locality'];
	  $paymentmethod=$row_pro['paymentmethod'];
	  $DestinationServiceArea=$row_pro['DestinationServiceArea'];
	  $DestinationLocation=$row_pro['DestinationLocation'];
      $packagename=$row_pro['p_name'];
	


//echo $DestinationServiceArea;


?>





<div class="container">
<div class="page">
<div class="subpage">

<div class="blank-space"></div>
<div class="row">
<div  class="col-xs-5">

</div>
<div  class="col-xs-7">
<div class="right-portion">
<div class="address-text-bill1" type="text"><?php 
											if($bypost=="PO"){
														echo $packageprice+$packagepocharge;
													}else{
														echo $packageprice;
													}
								?> /- only</div>

		
    <div class="currency-text"><?php 
												if($bypost=="PO"){
														echo convert_number_to_words($packageprice+$packagepocharge);
													}else{
														echo convert_number_to_words($packageprice);
													}
		
	?>
</div>
<!--<div class="currency-text">Two Thousand only</div>-->

<div class="address-text-bill">Genius Import Export
Kailash Turn, Sikandra, Agra(INDIA)</div>
<div class="padding-barcode"></div>
<div>
<span class="top-details-invoice-padding"><img  width="250" height="75" alt="<?php echo $trackingcode;?>" src="barcode.php?size=45&text=<?php echo $trackingcode;?>&print=false" /></span>
<h4> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $trackingcode;?></b></h4>
</div>
<div class="padding-div"></div>
<div>
<span class="top-details-invoice-padding"><img  width="250" height="75" alt="<?php echo $prefix."-".$bypost."-".$orderid;?>" src="barcode.php?size=45&text=<?php echo $prefix."-".$bypost."-".$orderid;?>&print=false" /></span>
<h4> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $prefix."-".$bypost."-".$orderid;?></b></h4>
</div>
<div class="padding-div1"></div>
<div align="right" class="address-text-bill1"><?php echo  $_GET['prntdate'];?></div>

<div class="address-text-bill1"><?php echo $name;?></div>
<div class="address-text-bill1"><?php echo $address;?></div>
<div class="address-text-bill1">Landmark - <?php echo $locality;?>, <?php echo $city;?>,<?php echo $state;?></div>
<div class="padding-div"></div>
<div class="pin-bill"><span>Pin- <?php echo $pin;?></span><span class="phone-bill"> Ph- <?php echo $mobile;?></span> </div>
</div>
</div>
</div>



<div align="center"></div>
</div>
</div>
</div>

<?php  } ?>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.2.min.js"></script>

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.js"></script>
</body>
</html>
