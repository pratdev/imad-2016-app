<?php 
include 'session.php';

include 'includes/db.php';


?>
<?php include 'template/header.php';
      include 'template/sidebar.php';
?>
	  
		    
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				
	        	<p>

<?php 

include ('includes/db.php');

?>


       <title>Add New Package</title>
      
 <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script> -->
       
	





<form action="add_package.php" method="post" enctype="multipart/form-data">

     <table align="center" width="795" height="600" border="2" bgcolor="#187eae">

           <tr align="center">
             <td colspan="7"><h2>Add New Package Here</h2></td>
           </tr>

           <tr>
             <td align="right">Package Name:</td>
             <td><input type="text" name="p_name" size="60" required/></td>
           </tr>
           
           
           
            <tr>
             <td align="right"> Website Name: </td>
             <td>
             
             <select name="p_web_id" id="p_web_id" required />
                <option>Select Website</option>
                
                <?php 
                
                $get_cats = "select * from websites";
                
                $run_cats = mysqli_query($con,$get_cats);
                
                   while ($row_cats=mysqli_fetch_array($run_cats)) {
                	 
                	$web_id  = $row_cats['web_id'];
                	$web_domain = $row_cats['web_domain'];
                
                	echo "<option value='$web_id'>$web_domain</option>";
                                           
                }
                
                ?>
                
             </select>
             
             </td>
           </tr>
          
           
           <tr>
             <td align="right"> Package Category: </td>
             <td>
             
             <select name="p_cat_id" id="p_cat_id" required />
                <option>Select a Category</option>
             </select>
             
             </td>
           </tr>
           
			<script type="text/javascript">
					$(function() {	
						$( "#p_web_id" ).change(function() {
							var web_id= $(this).find("option:selected").val();
									
							$( "#p_cat_id" ).find("option").remove();
							 $("#p_cat_id").load("get_cat.php?web_id=" + web_id);
						});
					});
			</script>
           
           
           <tr>
             <td align="right"> Package Price: </td>
             <td><input type="text" name="p_price" required /></td>
           </tr>
           
		   <tr>
             <td align="right"> PO Charge: </td>
             <td><input type="text" name="p_pocharge" required /></td>
           </tr>
		   
		   <tr>
             <td align="right"> PO Shipping: </td>
             <td><input type="text" name="p_poshipping" required /></td>
           </tr>
		   
           <tr>
             <td align="right"> Shipping: </td>
             <td><input type="text" name="p_shipping" size="60" required/></td>
           </tr>
           
           <tr>
             <td align="right"> Package Status: </td>
             <td>
              <input type="radio" name="p_status" value="1" >Active<br>
  		     <input type="radio" name="p_status" value="0" >Inactive<br>
             </td>
           </tr>
           
           <tr align="center">
             <td colspan="7"><input type="submit" name="add_package" value="Insert Package Now" /></td>
           </tr>
           
           
           
     </table> 

</form>



<?php 

if (isset($_POST['add_package'])){
	
	//getting the text data from the fields
	$package_name = $_POST['p_name'];
	$package_web_id = $_POST['p_web_id'];
	$package_cat_id = $_POST['p_cat_id'];
	$package_price = $_POST['p_price'];
	$package_pocharge = $_POST['p_pocharge'];
	$package_shipping = $_POST['p_shipping'];
	$package_status = $_POST['p_status'];
	
	
	$insert_package = "insert into package (p_name,p_web_id,p_cat_id,p_price,p_pocharge,p_shipping,p_status)values
	('$package_name','$package_web_id','$package_cat_id','$package_price','$package_pocharge','$package_shipping','$package_status')";
	
	$insert_pack = mysqli_query($con, $insert_package);
	
	if($insert_pack){
		echo "<script>alert('Package has been inserted!')</script>";
		echo "<script>window.open('view_package.php','_self')</script>";
	}
	
}


?>

   </p>
	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
<?php include 'template/footer.php';?>

