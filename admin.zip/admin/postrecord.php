<?php 
				
//include 'session.php';
include 'includes/db.php';

   ?>   


<!DOCTYPE HTML>
<html>
  <head>
    <input type="button" class="no-print btn-success" value="Print This Page" onClick="window.print()" />
  </head>
<body>

	<title>View PostOffice Order Details | Genius Admin Panel</title>
<link href="css/print.css" rel="stylesheet">	
<link href="css/datatable.css" rel="stylesheet" type='text/css'>	  
<link href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" rel='stylesheet' type='text/css' />
<script src="http://code.jquery.com/jquery-1.12.4.js"></script>	
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
	
	
	
	  
	  <div id="page-wrapper" class="gray-bg dashbard-1">
	  
     <!--Search options starts here-->

	 
	 </div>
	 
    <!--Search options ends here--> 

	
	
	
       <div class="content-main">

 	<div class="blank">
 	
  <script>
		$(document).ready(function() {
				$('#example').DataTable();
		} );
   </script>			
 <table>
      <tr>
         <td><h3 style="color:green;">Manifest sheet For:  GENIUS IMPORT EXPORT</h3></td>
		 <td><h3 style="color:green;">Date: <?php 
		   $fromdate = $_GET['fromdate'];
			$todate = $_GET['todate'];
		   echo $todate;?></h3></td>
		 <td><h3 style="color:green;">Courier : POST OFFICE</h3></td>
     </tr> 
 </table>
  <br>
 <div>
  <table id="example" class="display" cellspacing="0" width="100%">
 	
 <thead>
	<tr>
	    <th>Serial No.</th>
	    <th>Airwaybill</th>
	    <th>Reference No.</th>
		<th>C/NEE Name</th>
	    <th>City/State</th>
		<th>Weight(kg)</th>
		<th>Barcode - Airwaybill No</th>
		<th>Pickup Address</th>
		
				
			
		<!--<th>Admin Response</th>
		
	    <th class="select">Command</th>
		
	    <th class="select">Payment Status</th>-->

   </tr>   
</thead>
<br><br>
 		<tbody>
	     
		<?php 
	    //include ("includes/db.php");
		 $fromdate = $_GET['fromdate'];
		 $todate = $_GET['todate'];
		  
	  $get_pro = "select orderdetails.*,states.* from orderdetails LEFT JOIN states ON states.stateid = orderdetails.state	
	               WHERE orderdetails.couriercompany='POSTOFFICE' 
	               AND orderdetails.orderstatus='CONFIRM'
	               AND orderdetails.cnfmcncldate BETWEEN '". $fromdate ."' AND '". $todate. "'";
	         
	  
	 /* select orderdetails.* from orderdetails WHERE orderdetails.couriercompany='fedex' AND orderdetails.orderstatus='CONFIRM'
		   AND orderdetails.OrderDate BETWEEN '". $_POST['startdate'] ."' AND '". $_POST['enddate']. "'*/
	
	  $run_pro = mysqli_query($con, $get_pro);
	 
	  $i=0;
   // $num_rows = mysqli_num_rows($run_pro);
 
  //echo "<b>"."No. of Orders=$num_rows \n"."</b>";

	  while ($row_pro=mysqli_fetch_array($run_pro))
	  {
			
			$web_domain =  $row_pro['web_domain'];	
		    
			$id = $row_pro['id'];

			$prefix = $row_pro['prefix'];
			$order_id = $row_pro['id'];
			$bypost = $row_pro['bypost'];
			
            $orderstatus = $row_pro['orderstatus'];
			
			$pincode = $row_pro['pin'];
			$trackingcode = $row_pro['trackingcode'];
			$name =  $row_pro['name'];
			$number = $row_pro['mobile'];
			$email = $row_pro['email'];
			$address = $row_pro['address'];
			
			$states =  $row_pro['states'];
			$stateid=$row_pro['stateid'];
			
			$cityname = $row_pro['city'];
			
			$ProvinceCode = $row_pro['ProvinceCode'];
			
			$DestinationServiceArea = $row_pro['DestinationServiceArea'];
			
			$DestinationLocation = $row_pro['DestinationLocation'];
			
			
			/*
			if($paymentmethod=="ONLINE")
		  {
			  $packagecost=round($packagecost*.95);
		  }
		  else{
			 $packagecost=$packagecost;
		  }*/

            $OrderDate = $row_pro['OrderDate'];
	

		  // $pcode = $row_pro['PostalCode'];--not here on form i.e run time only
		
			


/*
			$bgcolor="";

			if( $orderstatus=="PENDING" || $orderstatus=="NONE")
		  {
				$bgcolor="#DAFF33";
          }else if($orderstatus=="CONFIRM")
		  {
			   $bgcolor="#5AE012"; 
		  }
		  else if($orderstatus=="CANCEL")
		  {
			  $bgcolor="#FF5833";
		  }
*/
	    $i++;
	?>
	
	 <tr>
	    
	 	<td><?php echo $i?></td>
		<td><?php echo $trackingcode;?></td>
		<td><?php echo $prefix."-".$bypost."-".$order_id?></td>
		<td><?php echo $name?></td>
	 	<td><?php echo $cityname.",".$states?></td>
	 	<td><?php echo "0.40"?></td>
	 	<td><img width="240" height="55" src="barcode.php?text=<?php echo $trackingcode; ?>&print=false" ></td>
	 	<td><?php echo "H-43, Laxmi Nagar, Sikandra, Agra"?></td>
	 	
	 	


	 	<!--<td><a href="edit_order.php?id=<?php// echo $row_pro['id'];?>">Edit</a></td>
		  <td><a href="chek.php?id=<?php// echo $id;?>"><?php //echo "EDIT";?></a></td>
	 	<td><a href="javascript:getConfirmation('<?php //echo $order_id;?>')">Delete</a></td>-->
	 
	 </tr>
	
	
	 <?php } 
	  ?>
	
	 </tbody> 
	 
   </table>
   
   
   
</div>
       </div>
     
</body>
</html>	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 